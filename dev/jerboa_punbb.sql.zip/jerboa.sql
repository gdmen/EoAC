-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 50.63.239.19
-- Generation Time: Jan 16, 2013 at 11:03 PM
-- Server version: 5.0.96
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jerboa`
--

-- --------------------------------------------------------

--
-- Table structure for table `def_mastermodes`
--

DROP TABLE IF EXISTS `def_mastermodes`;
CREATE TABLE IF NOT EXISTS `def_mastermodes` (
  `mastermode_id` int(4) NOT NULL,
  `long_name` varchar(16) character set utf8 collate utf8_bin NOT NULL,
  PRIMARY KEY  (`mastermode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `def_mastermodes`
--

INSERT INTO `def_mastermodes` VALUES(0, 'public');
INSERT INTO `def_mastermodes` VALUES(1, 'private');
INSERT INTO `def_mastermodes` VALUES(2, 'match');

-- --------------------------------------------------------

--
-- Table structure for table `def_modes`
--

DROP TABLE IF EXISTS `def_modes`;
CREATE TABLE IF NOT EXISTS `def_modes` (
  `mode_id` int(4) NOT NULL,
  `long_name` varchar(32) character set utf8 collate utf8_bin NOT NULL,
  `short_name` varchar(16) character set utf8 collate utf8_bin NOT NULL,
  `team_mode` tinyint(1) NOT NULL,
  `flag_mode` tinyint(1) NOT NULL,
  PRIMARY KEY  (`mode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `def_modes`
--

INSERT INTO `def_modes` VALUES(0, 'team deathmatch', 'tdm', 1, 0);
INSERT INTO `def_modes` VALUES(1, 'co-op edit', 'edit', 0, 0);
INSERT INTO `def_modes` VALUES(2, 'deathmatch', 'dm', 0, 0);
INSERT INTO `def_modes` VALUES(3, 'survivor', 'surv', 0, 0);
INSERT INTO `def_modes` VALUES(4, 'team survivor', 'tsurv', 1, 0);
INSERT INTO `def_modes` VALUES(5, 'capture the flag', 'ctf', 1, 1);
INSERT INTO `def_modes` VALUES(6, 'pistol frenzy', 'pf', 0, 0);
INSERT INTO `def_modes` VALUES(7, 'bot team deathmatch', 'btdm', 1, 0);
INSERT INTO `def_modes` VALUES(8, 'bot deathmatch', 'bdm', 0, 0);
INSERT INTO `def_modes` VALUES(9, 'last swiss standing', 'lss', 0, 0);
INSERT INTO `def_modes` VALUES(10, 'one shot, one kill', 'osok', 0, 0);
INSERT INTO `def_modes` VALUES(11, 'team one shot, one kill', 'tosok', 1, 0);
INSERT INTO `def_modes` VALUES(12, 'bot one show, one  kill', 'bosok', 0, 0);
INSERT INTO `def_modes` VALUES(13, 'hunt the flag', 'htf', 1, 1);
INSERT INTO `def_modes` VALUES(14, 'team keep the flag', 'tktf', 1, 1);
INSERT INTO `def_modes` VALUES(15, 'keep the flag', 'ktf', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `def_teams`
--

DROP TABLE IF EXISTS `def_teams`;
CREATE TABLE IF NOT EXISTS `def_teams` (
  `team_id` int(4) NOT NULL,
  `long_name` varchar(32) character set utf8 collate utf8_bin NOT NULL,
  `short_name` varchar(5) character set utf8 collate utf8_bin NOT NULL,
  PRIMARY KEY  (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `def_teams`
--

INSERT INTO `def_teams` VALUES(0, 'cuber liberation army', 'cla');
INSERT INTO `def_teams` VALUES(1, 'rabid viper strike force', 'rvsf');
INSERT INTO `def_teams` VALUES(2, 'cla spectate', 'spect');
INSERT INTO `def_teams` VALUES(3, 'rvsf spectate', 'spect');
INSERT INTO `def_teams` VALUES(4, 'spectate', 'spect');

-- --------------------------------------------------------

--
-- Table structure for table `ss`
--

DROP TABLE IF EXISTS `ss`;
CREATE TABLE IF NOT EXISTS `ss` (
  `ss_id` int(16) NOT NULL auto_increment COMMENT 'Unique screenshot id.',
  `user_id` int(10) NOT NULL COMMENT 'User id.',
  `imgur_hash` varchar(32) collate utf8_bin NOT NULL,
  `imgur_delete_hash` varchar(32) collate utf8_bin NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `title` varchar(64) collate utf8_bin NOT NULL,
  `caption` varchar(128) collate utf8_bin NOT NULL,
  `local_file_path` varchar(256) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`ss_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=559 ;

--
-- Dumping data for table `ss`
--

INSERT INTO `ss` VALUES(186, 20, 'xZsSN', 'r44tnlgYYv5CfHz', '2012-08-29 10:00:51', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120829_16.59.38_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(188, 20, '3GPm0', 'KbtSswgZYhX91CT', '2012-08-29 10:00:55', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120829_17.00.28_ac_complex_DM.jpg');
INSERT INTO `ss` VALUES(189, 20, 'tsmnc', 'v4oBZd5KIrbchM2', '2012-08-29 10:01:36', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120829_17.00.51_ac_outpost_TDM.jpg');
INSERT INTO `ss` VALUES(192, 20, 'HStZf', 'ETYX4xPd0GcANjO', '2012-08-29 10:01:41', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120829_17.01.09_ac_aqueous_BTDM.jpg');
INSERT INTO `ss` VALUES(195, 20, 'h09oq', 'cQnMuuLGfHKjZXY', '2012-08-29 12:12:09', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120829_19.11.08_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(197, 20, 'dwdNl', 'fz7UXVJWgpKGt24', '2012-08-29 12:13:00', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120829_19.12.14_ac_douze_KTF.jpg');
INSERT INTO `ss` VALUES(203, 31, 'K1n3n', 'faljuGo2SSzl38x', '2012-09-01 09:56:21', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120901_16.55.40_ac_douze_CTF.jpg');
INSERT INTO `ss` VALUES(204, 31, 'iMVMQ', '414lflLP7XQ4ONY', '2012-09-01 10:04:31', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120901_17.04.44_ac_douze_CTF.jpg');
INSERT INTO `ss` VALUES(205, 31, 'iurl9', 'wFZAPszL9BPpOXa', '2012-09-01 10:57:25', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120901_17.55.30_ac_snow_OSOK.jpg');
INSERT INTO `ss` VALUES(206, 31, 'Gyzho', 'sLBfA1SlHiESu9f', '2012-09-01 11:16:21', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120901_18.15.12_ac_lainio_CTF.jpg');
INSERT INTO `ss` VALUES(207, 31, 'UXa7G', 'JfGj76R9wBDGiA0', '2012-09-01 12:03:58', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120901_19.03.30_ac_ingress_HTF.jpg');
INSERT INTO `ss` VALUES(208, 31, 'WViZr', 'i57yBf8Es2pQ26z', '2012-09-01 12:21:26', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120901_19.19.30_ac_desert3_HTF.jpg');
INSERT INTO `ss` VALUES(209, 31, 'dgQJ2', '36bW3OYlgmiE6Nr', '2012-09-01 12:58:42', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120901_19.59.06_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(210, 31, 'wHtD6', 'KR97TC54xRuUsq9', '2012-09-02 17:28:44', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_00.25.14_ac_arabian_CTF.jpg');
INSERT INTO `ss` VALUES(211, 31, 'YJZEr', 'jhaZzMwGRsnzpfu', '2012-09-02 17:34:53', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_00.35.23_ac_komplex_CTF.jpg');
INSERT INTO `ss` VALUES(212, 31, 'PDqSG', 'zSzE2DdgzLLrk1x', '2012-09-02 17:38:55', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_00.37.16_ac_shortway_TSURV.jpg');
INSERT INTO `ss` VALUES(213, 31, 'rWTWS', 'meU6MSfggKIDhfu', '2012-09-02 17:53:36', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_00.52.26_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(214, 31, 'x1Vlq', 'YVa6KvVwJryhqVb', '2012-09-02 18:06:16', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_01.06.36_apollo_castle_CTF.jpg');
INSERT INTO `ss` VALUES(215, 20, 'p8nGF', '8SHdVA96ppcaOZe', '2012-09-02 21:05:21', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_04.00.19_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(216, 20, 'UEJEQ', 'CKnDap5CSxZA4OF', '2012-09-02 21:15:39', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_04.15.29_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(217, 20, 'cIU4o', 'cdtzezDZ5Q337dg', '2012-09-02 21:37:55', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_04.31.37_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(218, 20, 'iRykU', 'S2TjpFxBMajMF89', '2012-09-03 10:53:31', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_17.51.55_ac_desert_TDM.jpg');
INSERT INTO `ss` VALUES(219, 20, '8F6OB', 'nWBUbQMzpWQwoPy', '2012-09-03 10:55:16', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_17.53.32_ac_desert_TDM.jpg');
INSERT INTO `ss` VALUES(220, 20, 'gpsbv', 'kfiFhTTMLM5H8gS', '2012-09-03 14:43:02', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_21.39.02_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(221, 20, 'Zs1T9', '1N1FAaLqKkIGSkh', '2012-09-03 14:43:03', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_21.42.51_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(222, 20, 'pnSkN', 'xC2wjiVO4lcPA0j', '2012-09-03 14:59:43', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120903_21.58.36_ac_depot_CTF.jpg');
INSERT INTO `ss` VALUES(223, 20, 'XdW4U', 'O5saJFAMVpvk08V', '2012-09-03 17:16:00', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20120904_00.15.48_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(224, 31, 'Jkoaw', 'j8xWwD6PnsszD2r', '2012-09-03 22:29:55', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120904_05.30.18_ac_douze_OSOK.jpg');
INSERT INTO `ss` VALUES(225, 31, '3OHD2', 'c9Nu9qaJ0HKhQlC', '2012-09-03 22:31:58', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120904_05.31.55_ac_depot_CTF.jpg');
INSERT INTO `ss` VALUES(226, 31, '9ae3S', 'FO3U50dd58RUZXT', '2012-09-03 22:49:48', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120904_05.47.26_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(227, 31, '4ps9k', 'StQ38ZsfyZc0tMD', '2012-09-04 19:25:16', 'title', 'caption', 'C:\\Users\\Michael\\Documents\\AssaultCube_v1.1\\screenshots\\20120905_02.25.09_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(228, 20, 'lwf2t', 'Vox2MI1652DpLTM', '2013-01-11 18:16:30', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_01.16.17_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(229, 20, 'TlrZ0', 'PiU8gjZWRniYJls', '2013-01-11 18:16:33', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_01.16.38_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(230, 20, '5BfCW', 'bn3XB7UrxAWdGGL', '2013-01-11 18:36:53', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_01.36.48_ac_desert_TOSOK.jpg');
INSERT INTO `ss` VALUES(231, 20, 'xS9BL', 'OpfvUcuA2E8GuU1', '2013-01-11 18:37:51', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_01.37.52_ac_desert_TOSOK.jpg');
INSERT INTO `ss` VALUES(232, 20, '6h6qE', '9B2BRuwMf3QC1cz', '2013-01-11 18:48:45', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_01.48.48_ac_elevation_TDM.jpg');
INSERT INTO `ss` VALUES(233, 20, 'F7ccm', 'SkTNrY6egmwgVar', '2013-01-11 18:51:32', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_01.51.38_ac_shine_TDM.jpg');
INSERT INTO `ss` VALUES(234, 20, 'YAHeZ', 'UbHr7uYrJJzbRNj', '2013-01-11 19:09:05', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_02.09.09_ac_zanka_CTF.jpg');
INSERT INTO `ss` VALUES(235, 20, 'k0TIB', 'cyN9XwVEOyaHoFj', '2013-01-11 19:13:13', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_02.13.19_ac_gothic_TDM.jpg');
INSERT INTO `ss` VALUES(236, 20, '9kpKb', '94L39U3jU3T9WMZ', '2013-01-11 19:16:10', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_02.16.15_ac_desert2_TDM.jpg');
INSERT INTO `ss` VALUES(237, 20, 'NSP2v', 'Mwl1FOCHqHWPBts', '2013-01-11 19:22:55', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_02.23.01_ac_shine_TDM.jpg');
INSERT INTO `ss` VALUES(238, 20, 'shYNI', '4Pw8uKMO7RodUhA', '2013-01-11 21:13:44', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_04.13.36_ac_nuuk_CTF.jpg');
INSERT INTO `ss` VALUES(239, 20, '2AeR2', 'RBfq4LRcmmxYxT3', '2013-01-11 21:13:56', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_04.13.52_ac_nuuk_CTF.jpg');
INSERT INTO `ss` VALUES(240, 20, 'dcDRw', 'IE7alcrYvcpGVy3', '2013-01-11 21:13:57', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130112_04.13.58_ac_nuuk_CTF.jpg');
INSERT INTO `ss` VALUES(241, 20, 'lnQu9', 'KvcZCEyJYXyjE1k', '2013-01-12 09:45:59', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_16.45.57_ac_mines_TDM.jpg');
INSERT INTO `ss` VALUES(242, 20, 'ygazf', 'WtGc2RinvESvYmk', '2013-01-12 09:49:50', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_16.49.27_ac_desert3_HTF.jpg');
INSERT INTO `ss` VALUES(243, 20, 'xIFNo', '3XIhsM5dHkiBv99', '2013-01-12 09:51:56', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_16.49.51_ac_desert3_HTF.jpg');
INSERT INTO `ss` VALUES(244, 20, 'de19v', '1fJzMzYUkeCJYF3', '2013-01-12 09:53:16', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_16.52.54_ac_desert3_HTF.jpg');
INSERT INTO `ss` VALUES(245, 20, 'QwaKf', '0WZRrC1oWyTFcsS', '2013-01-12 09:54:12', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_16.53.56_ac_desert3_HTF.jpg');
INSERT INTO `ss` VALUES(246, 20, 'oqR6C', 'kzybHmx0GZktOUZ', '2013-01-12 09:55:19', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_16.54.22_ac_desert3_HTF.jpg');
INSERT INTO `ss` VALUES(247, 20, 'D63wZ', '8lHwyk1FQvd2b32', '2013-01-12 09:56:46', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_16.56.29_ac_desert3_HTF.jpg');
INSERT INTO `ss` VALUES(248, 20, 'EMM4C', 'PaKuxISd7xxbKK9', '2013-01-12 09:56:49', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_16.56.47_ac_desert3_HTF.jpg');
INSERT INTO `ss` VALUES(249, 20, 'RBFyT', 'gkn5lfbNZKdcbBY', '2013-01-12 09:56:50', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_16.56.48_ac_desert3_HTF.jpg');
INSERT INTO `ss` VALUES(250, 20, '5fdTu', 'HOnkrFpW8SCCgz9', '2013-01-12 10:15:12', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.14.06_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(251, 20, 'oUjBf', 'USroHr0lK6ErEYO', '2013-01-12 10:15:14', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.14.18_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(252, 20, 'i9tl2', 'XQ5YVCZs6zjn6Sg', '2013-01-12 10:15:17', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.15.13_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(253, 20, 'Y6iZo', 'GNAkmLn5YSjWPw1', '2013-01-12 10:15:18', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.15.15_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(254, 20, 'Lt2F4', 'mFKMCevQrXIjxVX', '2013-01-12 10:20:54', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.19.04_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(255, 20, 'rGX6J', '2uy9rvx5ooIDcF5', '2013-01-12 10:20:55', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.20.55_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(256, 20, 'fXgHH', 'XFgpnoJJQiOLDly', '2013-01-12 10:20:57', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.20.56_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(257, 20, 'QTKj9', 'xh31Xc0sMuRjwPN', '2013-01-12 10:28:37', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.28.27_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(258, 20, '4PFB9', 'Uv1CHz71j4wn4z7', '2013-01-12 10:31:00', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.30.59_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(259, 20, '9Hnun', 'RcKCYsbFYujypp7', '2013-01-12 10:32:15', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.31.02_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(260, 20, 'Zb4Zn', 'KtGyZqWHtoud3ud', '2013-01-12 10:32:41', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.32.41_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(261, 20, '7NxsM', '1bqqbNfk4pPUOuc', '2013-01-12 10:32:43', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.32.42_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(262, 20, 'cT6Vy', 'offJR2P7Mmxgwlu', '2013-01-12 10:32:45', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.32.43_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(263, 20, '7GsOe', 'WTIn46sFBS6yAWB', '2013-01-12 10:54:14', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_17.54.14_ac_desert2_TDM.jpg');
INSERT INTO `ss` VALUES(264, 20, 'yK9WD', 'wWF9pAVN5qo67D6', '2013-01-12 11:06:33', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.06.33_ac_elevation_TDM.jpg');
INSERT INTO `ss` VALUES(265, 20, '2vHxb', 'she68IPIzleyhCo', '2013-01-12 11:13:04', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.13.01_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(266, 20, '5jDns', 'hOc5QlCVNdv4o0B', '2013-01-12 11:13:05', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.13.03_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(267, 20, 'WR012', 'sWfGG6eYDifGqtN', '2013-01-12 11:23:54', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.20.48_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(268, 20, 'Bh6Iy', '9q5Oo1UzkQQTq16', '2013-01-12 11:23:55', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.22.31_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(269, 20, 'qZKjd', 'L7XXvJ90FymHBKY', '2013-01-12 11:27:05', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.24.33_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(270, 20, 'hHy7J', '5VQTmIYBZq5qV2N', '2013-01-12 11:30:07', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.29.07_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(271, 20, 'KMQTk', 'I0IqbLujZfoBZx5', '2013-01-12 11:33:03', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.32.58_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(272, 20, '4TyjJ', 'eyuZm7Hsnn1RWvh', '2013-01-12 11:33:04', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.33.00_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(273, 20, 'lRXxr', 'Qv7OOScKjX5PO7B', '2013-01-12 11:34:38', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.34.33_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(274, 20, 'FhJwG', 'OPJMUxSrt531GXu', '2013-01-12 11:42:12', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.38.29_ac_douze_TDM.jpg');
INSERT INTO `ss` VALUES(275, 20, 'aTUpJ', 'fjkJlFsaaLvc2hk', '2013-01-12 11:42:14', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.38.32_ac_douze_TDM.jpg');
INSERT INTO `ss` VALUES(276, 20, 'maRMN', 'x2vmAIEmGzah7fl', '2013-01-12 11:42:15', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.40.12_ac_arid_CTF.jpg');
INSERT INTO `ss` VALUES(277, 20, 'rmzpl', 'XvWuNSrRAo8Dpzn', '2013-01-12 11:42:16', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.40.49_ac_arid_CTF.jpg');
INSERT INTO `ss` VALUES(278, 20, 'P2Jpe', 'IEeXTMl5TPd7GTZ', '2013-01-12 11:46:09', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.42.29_ac_arid_CTF.jpg');
INSERT INTO `ss` VALUES(279, 20, '5GraF', 'IidV0d8OF57uUGW', '2013-01-12 12:01:02', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.57.40_ac_gothic_CTF.jpg');
INSERT INTO `ss` VALUES(280, 20, 'fq6fe', 'xuptcnEIxzhwK94', '2013-01-12 12:01:03', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_18.57.42_ac_gothic_CTF.jpg');
INSERT INTO `ss` VALUES(281, 20, 'XmFBf', 'GcaME01eF4eOmvZ', '2013-01-12 12:13:52', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.13.53_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(282, 20, 'np1fP', 'uFAeDYPk48XXToq', '2013-01-12 12:19:46', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.19.43_ac_outpost_TDM.jpg');
INSERT INTO `ss` VALUES(283, 20, 'IDk6m', '8HnwJ0j24xzGx2h', '2013-01-12 12:24:09', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.24.09_ac_desert_TDM.jpg');
INSERT INTO `ss` VALUES(284, 20, '2m9uh', 'gxRHmn89PULGFrj', '2013-01-12 12:24:56', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.24.53_ac_desert_TOSOK.jpg');
INSERT INTO `ss` VALUES(285, 20, 'WqLIk', 'k42UjTvr77RjKkm', '2013-01-12 12:25:08', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.24.57_ac_desert_TOSOK.jpg');
INSERT INTO `ss` VALUES(286, 20, 'LTUXY', '3c4oYNPjKEfj7i6', '2013-01-12 12:25:10', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.25.00_ac_desert_TOSOK.jpg');
INSERT INTO `ss` VALUES(287, 20, 'XOPmM', 'XqUvEKIJ8aJBvzJ', '2013-01-12 12:25:12', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.25.06_ac_desert_TOSOK.jpg');
INSERT INTO `ss` VALUES(288, 20, 'HQtLv', 'IGuXQ6GO1T4CWC9', '2013-01-12 12:25:43', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.25.42_ac_elevation_TDM.jpg');
INSERT INTO `ss` VALUES(289, 20, 'LuhnX', 'ttXWUDP5yvNks23', '2013-01-12 12:27:18', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.27.02_ac_depot_TDM.jpg');
INSERT INTO `ss` VALUES(290, 20, 'JaFaX', 'cNTcvvY8UGbI7Kv', '2013-01-12 12:27:22', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.27.18_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(291, 20, 'vEL11', 'dgIj1uBOlTtlwRT', '2013-01-12 12:51:23', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.51.21_ac_desert3_TDM.jpg');
INSERT INTO `ss` VALUES(292, 20, 'l45lb', 'f1xMcVOrZXsDMU4', '2013-01-12 12:53:47', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.53.46_ac_arid_TDM.jpg');
INSERT INTO `ss` VALUES(293, 20, '8dxzl', 'JbqniAbVnfPVnvo', '2013-01-12 12:54:15', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.54.13_ac_power_TDM.jpg');
INSERT INTO `ss` VALUES(294, 20, 'bB0sq', 'Cic8izUsp8UsWWM', '2013-01-12 12:56:05', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.56.03_ac_mines_TDM.jpg');
INSERT INTO `ss` VALUES(295, 20, 'nIsLp', 'QsZANmLKpwYp02p', '2013-01-12 12:56:51', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.56.48_ac_desert_TDM.jpg');
INSERT INTO `ss` VALUES(296, 20, 'VdxX0', 'DByg9TCZYABk12H', '2013-01-12 12:58:08', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.58.01_ac_mines_TDM.jpg');
INSERT INTO `ss` VALUES(297, 20, 'Q0Apl', '8nipOG14LlsCC3n', '2013-01-12 12:58:35', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.58.32_ac_complex_TDM.jpg');
INSERT INTO `ss` VALUES(298, 20, 'QjPP0', 'QVbW7RiVpOfAMAL', '2013-01-12 12:59:38', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_19.59.38_ac_keller_TDM.jpg');
INSERT INTO `ss` VALUES(299, 20, '1yP1U', 'tJ5k7O2CG4K40Zo', '2013-01-12 13:07:37', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.07.36_ac_scaffold_TDM.jpg');
INSERT INTO `ss` VALUES(300, 20, 'ByI0G', 'M0tPJwFtFecdWll', '2013-01-12 13:08:15', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.08.15_ac_werk_TDM.jpg');
INSERT INTO `ss` VALUES(301, 20, 'jwYFq', 'HDabZvAvUmJyLUW', '2013-01-12 13:08:53', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.08.51_ac_outpost_TDM.jpg');
INSERT INTO `ss` VALUES(302, 20, 'EOXLF', '0ZuxofYNEcYX4mi', '2013-01-12 13:15:16', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.15.16_ac_keller_TDM.jpg');
INSERT INTO `ss` VALUES(303, 20, 'QhWT9', '9wZFuoXjckrbZTc', '2013-01-12 13:45:49', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.45.06_ac_shine_TDM.jpg');
INSERT INTO `ss` VALUES(304, 20, '1CLY8', 'm9h7oAb7qnSNodn', '2013-01-12 13:45:51', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.45.09_ac_shine_TDM.jpg');
INSERT INTO `ss` VALUES(305, 20, 'Alzt9', '9Fd2OxMTFwl6Wrz', '2013-01-12 13:45:52', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.45.15_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(306, 20, 'ZtkZj', 'cEA7Gh3ydQwAWfl', '2013-01-12 13:46:41', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.46.01_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(307, 20, 'pEENF', 'k865bgzCTULZLJD', '2013-01-12 13:46:42', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.46.33_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(308, 20, 'DuV82', 'O5y6v4XeVP88K2M', '2013-01-12 13:48:09', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.47.42_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(309, 20, 'yC16U', 'fZYC9FqzouW2NDo', '2013-01-12 13:48:45', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.48.10_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(310, 20, 'qz4M9', 'CzrwKH3E5v14V36', '2013-01-12 13:48:47', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.48.44_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(311, 20, 'iY3wm', 'sIvjMOjVYhsWirY', '2013-01-12 13:48:49', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.48.46_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(312, 20, 'yu5gv', 'sVgvXvMkFJOAuWB', '2013-01-12 13:50:36', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.50.24_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(313, 20, 'ErFzi', '1rlQtg7aZiezjAB', '2013-01-12 13:50:49', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.50.37_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(314, 20, 'VILG6', 'zbomBin05Hn2HYq', '2013-01-12 13:50:51', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.50.45_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(315, 20, 'j1QnF', 'lLavLuRy0OK9wlV', '2013-01-12 13:50:52', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.50.47_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(316, 20, 'iE6S9', '07L6EHFKVRZBi1e', '2013-01-12 13:51:25', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.50.50_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(317, 20, 'gc62g', 'syA0y90nboD5bGk', '2013-01-12 13:51:26', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.51.23_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(318, 20, 'AU6su', 'xkRceEe5rE5GPn4', '2013-01-12 13:52:22', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.51.26_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(319, 20, 'Tn0LX', 'kYF6LmfbVQIl0e4', '2013-01-12 13:52:24', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.21_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(320, 20, 'exf7g', 'gL94XVrhMRniPCM', '2013-01-12 13:52:31', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.24_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(321, 20, 'XQAWJ', 'gtJJzrWzrzTmRRj', '2013-01-12 13:52:32', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.30_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(322, 20, 'ZGvLO', 'mQXl79WEfpAUBDf', '2013-01-12 13:52:33', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.31_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(323, 20, 'X6c1C', 'uo0g8TGHGmq2AGg', '2013-01-12 13:52:34', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.32_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(324, 20, 'lrVN0', 'V1I2cG6Sfw4wr4O', '2013-01-12 13:52:36', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.33_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(325, 20, 'GsCgW', 'BDdBzchaVQIr9uy', '2013-01-12 13:52:37', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.34_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(326, 20, '6EnEL', 'WOidFtVPbxjrRvy', '2013-01-12 13:52:38', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.35_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(327, 20, 'EWOAV', 'GKXYFYi2MMTuiWG', '2013-01-12 13:52:39', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.36_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(328, 20, 'P2pYz', 'YqxueITKOQzgxll', '2013-01-12 13:52:41', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.37_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(329, 20, 'Awjpu', 'jhrRFN682bMGPgs', '2013-01-12 13:52:42', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.38_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(330, 20, 'mBgvx', 'ERoWE2llXA1wQRQ', '2013-01-12 13:52:43', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.39_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(331, 20, 'tqNec', 'lrh2FJgaDaZhind', '2013-01-12 13:52:44', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.52.40_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(332, 20, 'y9LGQ', 'u4PVcyJMQvKYgv7', '2013-01-12 13:53:10', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_20.53.08_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(333, 20, '83X9q', '9c92V90ErRt2snq', '2013-01-12 14:13:19', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_21.13.16_ac_ingress_TDM.jpg');
INSERT INTO `ss` VALUES(334, 20, 'GsHeI', 'QikaB8QqADahSTG', '2013-01-12 14:16:32', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_21.16.31_ac_depot_TDM.jpg');
INSERT INTO `ss` VALUES(335, 20, 'lRjNG', 'cFWVtFyv9wg1dhL', '2013-01-12 14:56:23', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_21.56.21_ac_shine_TDM.jpg');
INSERT INTO `ss` VALUES(336, 20, 'PmGxV', '2rny5dPhaNx3nu6', '2013-01-12 14:56:49', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_21.56.41_ac_arabian_TDM.jpg');
INSERT INTO `ss` VALUES(337, 20, 'n5oOR', 'HXRQVa77J9KV629', '2013-01-12 14:56:50', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_21.56.43_ac_arabian_TDM.jpg');
INSERT INTO `ss` VALUES(338, 20, 'd59KV', 'BrgAK4LXzSFf3Wq', '2013-01-12 14:56:51', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_21.56.44_ac_arabian_TDM.jpg');
INSERT INTO `ss` VALUES(339, 20, '5k7lW', 'mk4WKsCAhXcjhbL', '2013-01-12 14:56:52', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_21.56.45_ac_arabian_TDM.jpg');
INSERT INTO `ss` VALUES(340, 20, 'yBooZ', 'JpUmsXjyaBphLB5', '2013-01-12 14:56:54', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_21.56.50_ac_depot_CTF.jpg');
INSERT INTO `ss` VALUES(341, 20, 'z9kc9', 'XBN1fOnMXhldI1J', '2013-01-12 14:56:57', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_21.56.55_ac_depot_CTF.jpg');
INSERT INTO `ss` VALUES(342, 20, 'FCrhx', 'dOIPBdbZH48o2PO', '2013-01-12 14:56:58', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_21.56.57_ac_depot_CTF.jpg');
INSERT INTO `ss` VALUES(343, 20, 'Wxxcv', 'J2RWJizVDauN1YS', '2013-01-12 14:56:59', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_21.56.58_ac_depot_CTF.jpg');
INSERT INTO `ss` VALUES(344, 20, 'q554t', 'NL6OGTBFv7yrnn5', '2013-01-12 15:11:34', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_22.10.26_ac_depot_CTF.jpg');
INSERT INTO `ss` VALUES(345, 20, 'X4yPC', 'kgIWN4tsyk2YLJB', '2013-01-12 15:12:16', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_22.11.35_ac_depot_CTF.jpg');
INSERT INTO `ss` VALUES(346, 20, 'YacLR', '9FVNiZDA9oV0Siu', '2013-01-12 15:20:16', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_22.18.28_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(347, 20, 'gKZh3', 'lSl3PDKgTmtxGVd', '2013-01-12 15:22:57', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130112_22.22.50_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(348, 20, '05gMo', '2uhs3R5lBnsXLsz', '2013-01-12 17:12:45', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_00.12.16_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(349, 20, 'PPHFX', '0gc1sTrnRYrhwXU', '2013-01-12 17:12:47', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_00.12.45_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(350, 20, 'jkD3B', '4p6VT9qxYHrFqTQ', '2013-01-12 17:17:14', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_00.17.07_ac_arabian_CTF.jpg');
INSERT INTO `ss` VALUES(351, 20, 'D5XZD', 'aJFFChDqvF9pvMl', '2013-01-12 17:18:56', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_00.17.16_ac_arabian_CTF.jpg');
INSERT INTO `ss` VALUES(352, 20, 'vFrW7', 'HYR8ZKCWHDGlozJ', '2013-01-12 17:18:57', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_00.18.20_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(353, 20, '35Uvv', 'XvPCXq3Dl2hBsJd', '2013-01-12 17:19:10', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_00.18.57_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(354, 20, '1omD5', 'TRt7fAsQSrQir4O', '2013-01-12 17:19:12', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_00.19.03_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(355, 20, 'tXji9', 's8PewVoKgZFoNBj', '2013-01-12 17:19:13', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_00.19.11_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(356, 20, 'vSjQo', 'PjFYePHMzrN7YT7', '2013-01-12 17:24:20', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_00.24.11_ac_toxic_TDM.jpg');
INSERT INTO `ss` VALUES(357, 20, 'GRk3u', 'ybcCqqW81vFMIYQ', '2013-01-12 17:24:21', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_00.24.20_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(358, 20, 'EXWRy', 'v8RI4Knt3SAHQnF', '2013-01-12 22:55:30', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_05.55.31_ac_douze_TDM.jpg');
INSERT INTO `ss` VALUES(359, 20, '7unhH', 'QiVqIGHwRU3YPQe', '2013-01-12 22:59:17', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_05.57.42_ac_village2_CTF.jpg');
INSERT INTO `ss` VALUES(360, 20, 'ml58g', 'yRFnuUQ34ZCJgzh', '2013-01-12 22:59:20', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_05.59.19_ac_douze_TOSOK.jpg');
INSERT INTO `ss` VALUES(361, 20, 'uNTnr', 'hgRP7Ft9gbHd98F', '2013-01-12 23:03:09', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.02.46_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(362, 20, '7DZ1W', 'H00bD1nbxfvhDaL', '2013-01-12 23:14:50', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.13.03_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(363, 20, 'W0Ae5', 'quutyBN0omToUhV', '2013-01-12 23:14:51', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.13.05_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(364, 20, 'U4H7t', '4p3XRvJ7hWdBESe', '2013-01-12 23:14:52', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.14.52_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(365, 20, 'LlAOu', '3bRxSDKEWbFVbGe', '2013-01-12 23:23:24', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.23.12_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(366, 20, 'dAV9e', 'zbi1TXIEYnM8OVw', '2013-01-12 23:23:46', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.23.26_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(367, 20, 'yQY1b', 'hGwjlBoFg8b2kye', '2013-01-12 23:23:47', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.23.46_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(368, 20, 'kVofD', '0Orh5U2UU8K1v5r', '2013-01-12 23:27:34', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.27.22_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(369, 20, 'IH6HX', 'Ij6wn9I7Hw3vy8p', '2013-01-12 23:27:35', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.27.30_ac_werk_CTF.jpg');
INSERT INTO `ss` VALUES(370, 20, 'tYEfp', 'n0z7GS5v8Pibv12', '2013-01-12 23:28:02', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.28.03_ac_werk_CTF.jpg');
INSERT INTO `ss` VALUES(371, 20, 'G035k', 'ia5rSaLkuaBKWUS', '2013-01-12 23:29:01', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.29.01_ac_desert_TDM.jpg');
INSERT INTO `ss` VALUES(372, 20, 'lwL4e', 'ze5VnlIbaR8dmPl', '2013-01-12 23:29:02', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.29.02_ac_desert_TDM.jpg');
INSERT INTO `ss` VALUES(373, 20, 'gGxtJ', 'Ivbz5MNGO3GklhE', '2013-01-12 23:30:42', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.29.31_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(374, 20, 'kYlik', '8F76vfV4ffjPRqT', '2013-01-12 23:30:44', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.30.16_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(375, 20, 'QcEGN', 'vBRFeFCOC6JSOcP', '2013-01-12 23:31:04', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_06.31.05_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(376, 20, 'XO2rE', 'SVV5HRWSR3L5fHV', '2013-01-13 01:05:48', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_08.04.36_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(377, 20, 'uPZLC', '0uy33ExrKxcbP2G', '2013-01-13 01:05:54', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_08.05.07_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(378, 20, '3XtjA', 'pAu07AsyxfZBFT6', '2013-01-13 01:05:55', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_08.05.50_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(379, 20, 'HoNin', 'gkO5NTApA9ricMw', '2013-01-13 01:05:57', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_08.05.52_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(380, 20, 'RLJXK', '650AXseZT4IJFGl', '2013-01-13 01:05:58', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_08.05.53_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(381, 20, '026gh', 'WwOHSOB0s2Miwfx', '2013-01-13 10:03:41', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130113_17.02.34_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(382, 20, 'DYD3w', 'xIjvMGKf9wE1EW5', '2013-01-13 10:06:21', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130113_17.03.39_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(383, 20, 'hXOfG', 'jdGSsrCiPX8FWev', '2013-01-13 10:06:23', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130113_17.05.08_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(384, 20, 'mrT1c', '4KhxWtJU9b9Ngzj', '2013-01-13 10:08:32', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130113_17.07.57_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(385, 20, 'm2c2h', 'HeG0GXHoAm6CT45', '2013-01-13 10:13:07', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130113_17.10.55_ac_ingress_TDM.jpg');
INSERT INTO `ss` VALUES(386, 20, 'Zzx2j', 'uSA78Q4PtnCjskJ', '2013-01-13 10:14:37', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130113_17.13.07_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(387, 20, 'A2Yj4', 'FPmYGT0M31witEN', '2013-01-13 10:16:31', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130113_17.14.36_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(388, 20, 'pEfio', 'fSwIP0CXHR5dea0', '2013-01-13 10:16:32', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130113_17.15.13_Gema-10-by-Phoenix.94_CTF.jpg');
INSERT INTO `ss` VALUES(389, 20, 'rrLQH', 'CQzJLCBnzy3zb0l', '2013-01-13 10:19:37', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130113_17.16.29_ac_aqueous_TDM.jpg');
INSERT INTO `ss` VALUES(390, 20, 'F7rLo', '0nZWjFInOT3yrVA', '2013-01-13 10:28:57', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_17.25.01_ac_aqueous_TDM.jpg');
INSERT INTO `ss` VALUES(391, 20, 'qpjpS', '5fZRngl8pdmFZ5d', '2013-01-13 10:32:37', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_17.28.58_ac_aqueous_TDM.jpg');
INSERT INTO `ss` VALUES(392, 20, 'VLqr5', 'NOtdSsWAfUhvOg1', '2013-01-13 10:47:14', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_17.44.08_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(393, 20, '7e1kV', 'ToouJ2tqZELDIKm', '2013-01-13 10:56:48', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_17.54.44_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(394, 20, '62o03', 'iFlxFpAHXgqLagj', '2013-01-13 11:07:41', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_18.04.46_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(395, 20, 'PU4w0', 'xLOwLwyEQf75o7H', '2013-01-13 11:09:58', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_18.08.32_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(396, 20, 'yHvcO', '6HLCJzbcCKNs3df', '2013-01-13 11:09:59', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_18.09.46_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(397, 20, 'Wh4ZB', 'Pj2HjlOKN0lKKeD', '2013-01-13 11:10:00', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_18.09.55_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(398, 20, 'kfnoh', 'tDoXeOlOu4c9WcU', '2013-01-13 11:15:34', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_18.09.57_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(399, 20, 'zLENf', 'nxJ44jESEXIslnx', '2013-01-13 11:27:22', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_18.26.42_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(400, 20, 'ZO3z8', '8phqMg9pbol7KAJ', '2013-01-13 11:36:06', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_18.35.42_ac_gothic_CTF.jpg');
INSERT INTO `ss` VALUES(401, 20, 'h34nB', 'sTUh3HG23IySxkv', '2013-01-13 11:36:08', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_18.36.06_ac_gothic_CTF.jpg');
INSERT INTO `ss` VALUES(402, 20, 'Q6IhG', 'CcWLpnNP17qp2wR', '2013-01-13 11:42:42', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_18.42.40_ac_depot_classic_CTF.jpg');
INSERT INTO `ss` VALUES(403, 20, 'PdxaM', 'zgsV8k9eRItaVb2', '2013-01-13 12:03:35', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_19.02.57_ac_desert2_HTF.jpg');
INSERT INTO `ss` VALUES(404, 20, 'nqypm', 'nJz300KuqI0BYti', '2013-01-13 12:05:25', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_19.03.35_ac_desert2_HTF.jpg');
INSERT INTO `ss` VALUES(405, 20, '150nU', 'tXl1c4Brid4J7sX', '2013-01-13 12:05:27', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_19.05.15_ac_desert2_HTF.jpg');
INSERT INTO `ss` VALUES(406, 20, 'CIB0m', 'omVxlTpLu3ZMnUR', '2013-01-13 12:09:16', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_19.07.33_ac_desert2_HTF.jpg');
INSERT INTO `ss` VALUES(407, 20, 'rIOVn', '1xJLTtnrIQuue2s', '2013-01-13 12:11:22', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_19.11.08_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(408, 20, 'JlOB6', 'uzdicIEDWVf9iYg', '2013-01-13 12:25:28', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_19.24.49_ac_gothic_CTF.jpg');
INSERT INTO `ss` VALUES(409, 20, 'pv4KQ', 'DwrtO6kgsooyA69', '2013-01-13 12:34:00', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_19.33.49_ac_gothic_CTF.jpg');
INSERT INTO `ss` VALUES(410, 20, 'Za4Kv', 'PVSE7TiKuULLFXL', '2013-01-13 15:37:27', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_22.35.18_ac_gothic_CTF.jpg');
INSERT INTO `ss` VALUES(431, 20, 'QD0wf', 'EO1CAMgGlPCaNga', '2013-01-13 16:31:32', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.30.35_ac_rattrap_TDM.jpg');
INSERT INTO `ss` VALUES(432, 20, 'cTjGE', 'tbOVTlwVi5NhDzG', '2013-01-13 16:31:33', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.31.05_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(433, 20, '4pV1a', 'o4XwZEBj1ABtUCH', '2013-01-13 16:33:56', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.31.32_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(434, 20, '4JcPZ', 'ywFgTAOWC6TY5mI', '2013-01-13 16:33:57', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.33.26_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(435, 20, 'gxFGe', 'rATeALRXrI7TRBK', '2013-01-13 16:35:51', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.33.56_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(436, 20, 'IQ4do', 'XgBLPukpv3Hr9i2', '2013-01-13 16:36:42', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.35.51_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(437, 20, 'fMb42', 'AV0vS7nlJ0wU6V5', '2013-01-13 16:36:43', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.36.36_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(438, 20, 'SRN1S', 'eAp5Gn6t3LZtz9u', '2013-01-13 16:38:13', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.38.12_ac_scaffold_TDM.jpg');
INSERT INTO `ss` VALUES(439, 20, 'lrkSf', 'uSGNYm7u0324eh2', '2013-01-13 16:43:38', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.43.09_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(440, 20, 'XNRmu', 'QdNsnTsjCAM2ZZ1', '2013-01-13 16:44:13', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.43.50_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(441, 20, '5Xfye', 'mRhk9MTodIT6Q1M', '2013-01-13 16:44:15', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.44.11_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(442, 20, 'iDKRi', 'GVIxX4iqhjosFZ1', '2013-01-13 16:49:23', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.47.50_ac_desert2_HTF.jpg');
INSERT INTO `ss` VALUES(443, 20, 'HyLvn', 'RdsUhJe3HKe9fhs', '2013-01-13 16:52:53', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.51.18_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(444, 20, '6AqTp', 'SFpDxN9N3EWVhyL', '2013-01-13 16:52:54', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.52.08_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(445, 20, 'lGsHe', 'wzTGgW1jrNG8EBl', '2013-01-13 16:53:51', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130113_23.52.53_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(446, 20, '1AQup', 'aw2qUlaurPPjIrT', '2013-01-13 17:44:29', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.43.38_apollo_abbey_CTF.jpg');
INSERT INTO `ss` VALUES(447, 20, 'AXyB5', 'me74qptSGUpaiga', '2013-01-13 17:44:36', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.44.09_apollo_abbey_CTF.jpg');
INSERT INTO `ss` VALUES(448, 20, 'A9LZa', 'NXlqQgwVZV8w1h5', '2013-01-13 17:44:37', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.44.21_apollo_abbey_CTF.jpg');
INSERT INTO `ss` VALUES(449, 20, 'jrXjr', 'eZwepFp9m04a8pi', '2013-01-13 17:46:46', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.45.15_apollo_abbey_CTF.jpg');
INSERT INTO `ss` VALUES(450, 20, '6zHZM', 'Bf3cn6Gw5hTJvKu', '2013-01-13 17:49:36', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.46.46_apollo_abbey_CTF.jpg');
INSERT INTO `ss` VALUES(451, 20, '5MUsw', 'j06s5zjgoZjshwX', '2013-01-13 17:50:21', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.49.45_apollo_abbey_CTF.jpg');
INSERT INTO `ss` VALUES(452, 20, 'EpdEI', 'jt1nQOa6KZK2vgp', '2013-01-13 17:50:22', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.50.03_apollo_abbey_CTF.jpg');
INSERT INTO `ss` VALUES(453, 20, 'uS33P', 'W5bsnHcMHqD37A9', '2013-01-13 17:51:15', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.51.11_ac_arabian_TDM.jpg');
INSERT INTO `ss` VALUES(454, 20, 'qNPkv', 'JqHj5KPxeXiGEkP', '2013-01-13 17:52:04', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.52.02_ac_depot_TDM.jpg');
INSERT INTO `ss` VALUES(455, 20, 'EWQnU', 'ik7GPijdoxURUj7', '2013-01-13 17:52:34', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.52.33_ac_werk_TDM.jpg');
INSERT INTO `ss` VALUES(456, 20, 'wSmfQ', 'r9cEGoUQ8sIam2M', '2013-01-13 17:54:07', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.54.05_ac_scaffold_TDM.jpg');
INSERT INTO `ss` VALUES(457, 20, 'UOY72', 'y94gHKIchz3dH44', '2013-01-13 17:54:21', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.54.20_ac_mines_TDM.jpg');
INSERT INTO `ss` VALUES(458, 20, 'tZeMu', 'UuUIi2QtRUxinDR', '2013-01-13 17:58:22', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.58.21_ac_complex_TDM.jpg');
INSERT INTO `ss` VALUES(459, 20, 'eslze', 'X4qHAKJdeZDKjyN', '2013-01-13 17:59:58', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_00.59.54_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(460, 20, '4fXnb', 'VwTVEVnOLWLxBk6', '2013-01-13 18:00:21', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_01.00.20_ac_keller_TDM.jpg');
INSERT INTO `ss` VALUES(461, 20, 'BXRe6', 'AgJHQkfhnVvtMqI', '2013-01-13 18:03:16', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_01.02.10_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(462, 20, 'HKqfS', '6EflaOWRWX4OWgF', '2013-01-13 18:04:59', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_01.03.16_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(463, 20, 'xdpPO', '1kJqh3g0HSl5F6o', '2013-01-13 18:05:01', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_01.04.01_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(464, 20, 'HGPAN', '4ODGlXLaJkbXKTs', '2013-01-13 18:05:19', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_01.05.18_ac_power_CTF.jpg');
INSERT INTO `ss` VALUES(465, 20, 'x30sJ', 'EAQBfIkCaw0BIRN', '2013-01-13 20:48:28', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_03.48.24_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(466, 20, '0fwPq', 'ahJwavQcdWVUbJQ', '2013-01-13 20:49:54', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_03.49.54_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(467, 20, 'VmJ2y', 'AgJQvq1qKnfQ7gs', '2013-01-13 20:51:20', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_03.51.06_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(468, 20, '0FJxR', '2GBBJp6oRmQu0Ey', '2013-01-13 20:52:52', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_03.51.44_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(469, 20, 'YvzAX', 'oIOYGXimvF62fRj', '2013-01-13 20:53:42', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_03.52.56_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(470, 20, 'iI7Jt', '54d1XEjBx2uiEBr', '2013-01-13 20:53:44', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_03.53.42_ac_mines_CTF.jpg');
INSERT INTO `ss` VALUES(471, 20, '5sdea', 'lAB9bRzuaxi9dT6', '2013-01-13 20:56:09', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_03.56.08_ac_scaffold_TDM.jpg');
INSERT INTO `ss` VALUES(472, 20, 'jMmlk', 'hBYPCVtLUV7OaGn', '2013-01-13 22:03:15', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_05.02.10_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(473, 20, 'ox1GK', 'ZSBdJFwW5XPue1L', '2013-01-13 22:03:36', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_05.03.16_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(474, 20, 'F0RvB', 'lyU6pxhEOwKmCrC', '2013-01-13 22:03:38', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_05.03.35_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(475, 20, '57T7K', 'LqTlJMpNn7hM52S', '2013-01-13 22:06:49', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_05.06.47_ac_iceroad_TDM.jpg');
INSERT INTO `ss` VALUES(476, 35, 'xwKHI', 'nnCZyrha0jEJt46', '2013-01-14 02:38:22', 'title', 'caption', 'screenshots\\20130114_09.38.31_ac_power_TDM.jpg');
INSERT INTO `ss` VALUES(477, 35, '', '', '2013-01-14 02:38:23', 'title', 'caption', 'screenshots\\20130114_09.38.38_ac_power_TDM.jpg');
INSERT INTO `ss` VALUES(478, 20, '4nkOL', 'h53fGiie0CwmlQF', '2013-01-14 15:13:56', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.13.00_ac_ingress_TDM.jpg');
INSERT INTO `ss` VALUES(479, 20, 'yLjDc', 'd50fVqGXcxlxEvy', '2013-01-14 15:13:57', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.13.07_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(480, 20, 'JdVwd', 'Fbom6FLaQEwHB9i', '2013-01-14 15:14:21', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.14.06_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(481, 20, 'Mu7kz', 'brqgmcdR3y1VkwP', '2013-01-14 15:20:53', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.20.54_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(482, 20, 'yWHxi', 'fDI3gncAakD229k', '2013-01-14 15:34:00', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.31.54_ac_depot_CTF.jpg');
INSERT INTO `ss` VALUES(483, 20, '15IFY', 'pqs3BCMRA3ve38X', '2013-01-14 15:34:45', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.34.25_ac_depot_CTF.jpg');
INSERT INTO `ss` VALUES(484, 20, 'I1axQ', '7fSKdZpqzrTVBwE', '2013-01-14 15:43:41', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.42.54_ac_desert3_TKTF.jpg');
INSERT INTO `ss` VALUES(485, 20, 'xhwuc', '5OecE42b83hGtoT', '2013-01-14 15:45:36', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.44.37_ac_desert3_TKTF.jpg');
INSERT INTO `ss` VALUES(486, 20, 'b731r', 'YTxvRpDOCKIeaY0', '2013-01-14 15:58:27', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.58.23_ac_keller_TDM.jpg');
INSERT INTO `ss` VALUES(487, 20, 'RwHmw', 'Se9DdLLMjPzwOo1', '2013-01-14 15:58:28', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.58.25_ac_keller_TDM.jpg');
INSERT INTO `ss` VALUES(488, 20, 'MvOxq', 'kNMFP4PFF6ggOid', '2013-01-14 15:58:29', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.58.26_ac_keller_TDM.jpg');
INSERT INTO `ss` VALUES(489, 20, 'k8zGP', 'rHeWh61kb21Ymea', '2013-01-14 15:58:31', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.58.27_ac_keller_TDM.jpg');
INSERT INTO `ss` VALUES(490, 20, 'QMkv0', 'sf6TjpViVWbwX2w', '2013-01-14 15:58:32', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.58.28_ac_keller_TDM.jpg');
INSERT INTO `ss` VALUES(491, 20, '3IUW4', 'UG97s0ORbOxZzbs', '2013-01-14 15:58:33', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_22.58.29_ac_keller_TDM.jpg');
INSERT INTO `ss` VALUES(492, 20, 'Scz6C', 'PArSOOCJUl2MSR2', '2013-01-14 16:04:49', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_23.04.45_ac_arctic_TDM.jpg');
INSERT INTO `ss` VALUES(493, 20, 'K8Z3s', 'Yo6TQNJi5DqUjuK', '2013-01-14 16:04:50', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_23.04.46_ac_arctic_TDM.jpg');
INSERT INTO `ss` VALUES(494, 20, 'TexpQ', 'O1Iu2ZL3Zca5t0A', '2013-01-14 16:04:51', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_23.04.48_ac_arctic_TDM.jpg');
INSERT INTO `ss` VALUES(495, 20, '6U7rM', '7L7zJ74GXmTdd9D', '2013-01-14 16:04:53', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_23.04.49_ac_arctic_TDM.jpg');
INSERT INTO `ss` VALUES(496, 20, 'nz5oT', '3yYWJbg3R8fTq2G', '2013-01-14 16:04:55', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_23.04.50_ac_arctic_TDM.jpg');
INSERT INTO `ss` VALUES(497, 20, 'BCTrL', 'EOfVMLj8P5hZpw3', '2013-01-14 16:53:15', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130114_23.53.17_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(498, 20, 'M2siV', 'RGpLYzPEJaah5DU', '2013-01-14 17:04:27', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_00.02.51_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(499, 20, 'hdjgK', 'cRYLaE2g1sJ1Snu', '2013-01-14 17:04:29', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_00.04.29_ac_elevation_CTF.jpg');
INSERT INTO `ss` VALUES(500, 20, 'Kjxdj', 'CKrC6mLaqedyZSw', '2013-01-14 17:04:31', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_00.04.30_ac_elevation_CTF.jpg');
INSERT INTO `ss` VALUES(501, 20, 'zN25z', 'UZjJvLDkiBFWmU5', '2013-01-14 19:35:56', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_02.34.54_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(502, 20, 'lobBO', 'vtn88evBtIdG935', '2013-01-14 19:37:48', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_02.36.53_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(503, 20, 'zh3RC', 'CDNQkRQ6kSCPjoA', '2013-01-14 19:46:39', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_02.45.38_ac_shine_TDM.jpg');
INSERT INTO `ss` VALUES(504, 20, 'Lc5kc', 'C4weAQFsGw5Uwf5', '2013-01-14 19:46:41', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_02.45.53_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(505, 20, 'iGIzq', 'yD3vk42VlvNrFN8', '2013-01-14 19:49:06', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_02.48.53_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(506, 20, 'DDsPo', 'uwB9paN1ZSADQ32', '2013-01-14 19:52:39', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_02.51.20_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(507, 20, 'qKtH0', 'XeR6U2hhofz5Rnt', '2013-01-14 19:52:40', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_02.52.05_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(508, 20, 'ZFXaZ', 'yDN2MXOAr9Z5n1m', '2013-01-14 19:54:58', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_02.53.41_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(509, 20, 'CCg2R', 'PEd0tZb4xwaXWJW', '2013-01-14 19:59:30', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_02.57.44_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(510, 20, 'vYWox', '9D88Xj6Z4kT9fRq', '2013-01-14 20:00:45', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_02.59.24_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(511, 20, 'syggm', '8NqCdm10wrsU89N', '2013-01-14 20:12:25', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.11.38_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(512, 20, 'mkWKz', 'vguW5GRUOYcqBq6', '2013-01-14 20:12:27', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.11.45_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(513, 20, '4kLkQ', '0XOBgqraf7rRD2I', '2013-01-14 20:13:54', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.12.17_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(514, 20, 'vMdxJ', 'vXASjmzNoSd4dWg', '2013-01-14 20:13:55', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.12.54_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(515, 20, 'TWZ12', 'NXt1XEnmA5ye0MA', '2013-01-14 20:16:01', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.13.46_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(516, 20, 'sg94V', 'glzQAvum8Pmf8PQ', '2013-01-14 20:16:02', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.15.05_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(517, 20, 'UPQAy', 'z0taz8IkdVf6sU6', '2013-01-14 20:19:30', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.18.32_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(518, 20, 'utXMi', '6ZKgE5QIK8lwr91', '2013-01-14 20:19:38', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.19.22_ac_ingress_CTF.jpg');
INSERT INTO `ss` VALUES(519, 20, 'ZRZPB', '13Rx215LYkhMRRm', '2013-01-14 20:23:03', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.21.44_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(520, 20, 'VNHKk', 'CN81XfUexGomsYg', '2013-01-14 20:27:02', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.22.54_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(521, 20, 'Q00K7', 'IFG27pBSerlUzGe', '2013-01-14 20:27:03', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.23.56_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(522, 20, 'BKHZ4', 'PEbyS0Kkhln6N2w', '2013-01-14 20:40:53', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.40.15_ac_riverdry_TKTF.jpg');
INSERT INTO `ss` VALUES(523, 20, 'OAGyk', 'sozBLfAxryUhhzE', '2013-01-14 20:40:56', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.40.44_ac_riverdry_TKTF.jpg');
INSERT INTO `ss` VALUES(524, 20, 'I6pJ6', '4fBWUI0z4118jHh', '2013-01-14 20:40:58', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_03.40.45_ac_riverdry_TKTF.jpg');
INSERT INTO `ss` VALUES(525, 20, 'ZPOl8', 'ob1IoczoSyEG4Vv', '2013-01-14 21:18:54', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_04.18.42_ac_urban_TDM.jpg');
INSERT INTO `ss` VALUES(526, 20, 'uQFN4', 'JCdRposXOVSZfis', '2013-01-14 21:32:02', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_04.31.46_ac_desert2_TDM.jpg');
INSERT INTO `ss` VALUES(527, 20, 'lErEy', 'qw9VSM23KeFYbqD', '2013-01-14 21:38:15', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_04.37.49_ac_douze_CTF.jpg');
INSERT INTO `ss` VALUES(528, 20, '0emle', 'efuSAT4f9HD6uv6', '2013-01-14 21:38:19', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_04.38.02_ac_douze_CTF.jpg');
INSERT INTO `ss` VALUES(529, 20, 'BXlJb', 'gZsmKZae6HPZ3Qp', '2013-01-14 21:40:10', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_04.39.56_ac_arctic_TDM.jpg');
INSERT INTO `ss` VALUES(530, 20, 'TTyVM', 'VPU28nxSC1DuEUN', '2013-01-14 21:40:14', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_04.39.59_ac_arctic_TDM.jpg');
INSERT INTO `ss` VALUES(531, 20, 'VDJG8', 'a2qrNZCWmNkrfOj', '2013-01-14 21:45:41', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_04.45.23_ac_arid_TDM.jpg');
INSERT INTO `ss` VALUES(532, 20, 'GyOWi', '5Ye6RMOnyCpsoks', '2013-01-14 21:47:59', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_04.47.48_ac_sunset_TDM.jpg');
INSERT INTO `ss` VALUES(533, 20, 'eMTu7', 'RyNJNscmoglb8FA', '2013-01-14 22:03:31', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.03.19_ac_complex_TDM.jpg');
INSERT INTO `ss` VALUES(534, 20, 'ZAiop', 'GkjUXMjJMqtbeMp', '2013-01-14 22:03:52', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.03.40_ac_arabian_TDM.jpg');
INSERT INTO `ss` VALUES(535, 20, 'RhjBe', 'LCqvP88ZOkWiYfX', '2013-01-14 22:08:21', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.06.55_ac_desert_TDM.jpg');
INSERT INTO `ss` VALUES(536, 20, 'PPnh9', '82KNvQKYH8wo3Tc', '2013-01-14 22:11:12', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.08.13_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(537, 20, 'ne4l6', 'kPxUuRXT9Padca5', '2013-01-14 22:11:14', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.09.24_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(538, 20, 'RqkmR', 'HOq00WErRTfpTUJ', '2013-01-14 22:13:32', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.11.04_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(539, 20, 'j8bnF', 'jAOFlCZbLCogOAu', '2013-01-14 22:13:33', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.12.55_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(540, 20, 'Q6J3w', 'e0K7QJGFUQLOOoO', '2013-01-14 22:13:35', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.13.15_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(541, 20, 'gh1OV', 'RTCaxCKn5XvOW5W', '2013-01-14 22:17:23', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.13.24_ac_shine_CTF.jpg');
INSERT INTO `ss` VALUES(542, 20, 'DZ8xt', 'EEBdhoatH1FIxJa', '2013-01-14 22:35:23', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.33.33_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(543, 20, '1OrZX', 'y6PLkY9Ki2zF2RO', '2013-01-14 22:40:38', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.36.50_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(544, 20, 'ZxjjM', 'sYig6BUVaKoWd0a', '2013-01-14 22:40:40', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.39.26_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(545, 20, 'T8Avx', '3MQj4d2Q7lRRWuU', '2013-01-14 22:42:28', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.40.29_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(546, 20, '8bRbg', 'V5JeVBG9jhqjKfl', '2013-01-14 22:42:29', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.40.40_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(547, 20, '0W1kc', '7NTidioOsAvjyQd', '2013-01-14 22:42:30', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.40.43_ac_desert3_CTF.jpg');
INSERT INTO `ss` VALUES(548, 20, 'QW9AM', '80p6GU0BlKo1zdc', '2013-01-14 22:57:55', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_05.57.22_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(549, 20, 'rDVSA', 'AToJlWZz8iHlmd7', '2013-01-14 23:03:37', 'title', 'caption', 'F:\\Documents\\AssaultCube_v1.1\\screenshots\\20130115_06.03.26_ac_depot_TDM.jpg');
INSERT INTO `ss` VALUES(550, 20, 'qa7Je', 'Mlzj8toyDYHJq63', '2013-01-15 13:49:24', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_20.48.22_ac_desert2_HTF.jpg');
INSERT INTO `ss` VALUES(551, 20, 'FktyN', '1MxUASEk98563sy', '2013-01-15 13:52:16', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_20.52.12_ac_arid_TDM.jpg');
INSERT INTO `ss` VALUES(552, 20, 'eXRIm', '6Fx5YKXoVm2Y2Dw', '2013-01-15 13:53:36', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_20.53.05_ac_desert_TOSOK.jpg');
INSERT INTO `ss` VALUES(553, 20, '6VVoD', 'vP6g6XmvCYBhqVa', '2013-01-15 13:55:00', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_20.53.37_ac_desert_TOSOK.jpg');
INSERT INTO `ss` VALUES(554, 20, 'VgfWN', 'uRRJmllWWqoMaDf', '2013-01-15 13:55:22', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_20.55.00_ac_desert_TOSOK.jpg');
INSERT INTO `ss` VALUES(555, 20, 'hVthQ', 'BuU4TlWyxQOW374', '2013-01-15 13:59:11', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_20.59.10_ac_depot_TDM.jpg');
INSERT INTO `ss` VALUES(556, 20, 'ZE2uW', 'JPsyyHtKKOWOYDX', '2013-01-15 14:08:01', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_21.04.55_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(557, 20, 'pwEFL', '9xqG0HpOQdduhpd', '2013-01-15 14:08:02', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_21.05.28_ac_sunset_CTF.jpg');
INSERT INTO `ss` VALUES(558, 20, 'pv5tP', 'XCH9K62YGFogk4R', '2013-01-15 14:08:04', 'title', 'caption', '/home/gm/.assaultcube_v1.1/screenshots/20130115_21.08.01_ac_complex_TDM.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `ss_meta_blacklist`
--

DROP TABLE IF EXISTS `ss_meta_blacklist`;
CREATE TABLE IF NOT EXISTS `ss_meta_blacklist` (
  `ss_id` int(16) NOT NULL,
  `blacklist_name` varchar(64) collate utf8_bin NOT NULL,
  `blacklist_ip` varchar(15) collate utf8_bin NOT NULL,
  `blacklist_reason` varchar(128) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`ss_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `ss_meta_blacklist`
--


-- --------------------------------------------------------

--
-- Table structure for table `ss_meta_players`
--

DROP TABLE IF EXISTS `ss_meta_players`;
CREATE TABLE IF NOT EXISTS `ss_meta_players` (
  `ss_id` int(16) NOT NULL,
  `cn` int(2) NOT NULL,
  `flags` int(8) NOT NULL,
  `frags` int(8) NOT NULL,
  `deaths` int(8) NOT NULL,
  `score` int(8) NOT NULL,
  `team_id` int(4) NOT NULL,
  `nick` varchar(164) character set utf8 collate utf8_bin NOT NULL,
  `knife_atk` int(8) NOT NULL,
  `knife_dmg` int(8) NOT NULL,
  `pistol_atk` int(8) NOT NULL,
  `pistol_dmg` int(8) NOT NULL,
  `carbine_atk` int(8) NOT NULL,
  `carbine_dmg` int(8) NOT NULL,
  `shotgun_atk` int(8) NOT NULL,
  `shotgun_dmg` int(8) NOT NULL,
  `smg_atk` int(8) NOT NULL,
  `smg_dmg` int(8) NOT NULL,
  `sniper_atk` int(8) NOT NULL,
  `sniper_dmg` int(8) NOT NULL,
  `assault_atk` int(8) NOT NULL,
  `assault_dmg` int(8) NOT NULL,
  `cpistol_atk` int(8) NOT NULL,
  `cpistol_dmg` int(8) NOT NULL,
  `nade_atk` int(8) NOT NULL,
  `nade_dmg` int(8) NOT NULL,
  `akimbo_atk` int(8) NOT NULL,
  `akimbo_dmg` int(8) NOT NULL,
  KEY `ss_id` (`ss_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ss_meta_players`
--

INSERT INTO `ss_meta_players` VALUES(185, 0, 0, 7, 6, 69, 1, 'kurucutim-turco', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(185, 1, 0, 6, 8, 45, 1, 'una', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(185, 2, 0, 0, 0, 0, 4, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(185, 4, 0, 1, 17, -58, 0, 'fvlo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(185, 5, 0, 7, 2, 52, 1, 'JKDnaBIKE', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(185, 7, 0, 25, 31, 77, 0, '[HKB]Kamikatze', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(185, 11, 0, 18, 26, 68, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(185, 15, 0, 20, 19, 91, 0, '[HKB]iamnotgood', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(185, 17, 0, 19, 11, 158, 1, 'KAMIKAZE(fr)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(185, 18, 0, 14, 29, 17, 0, 'akadort', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(185, 19, 0, 35, 19, 326, 1, 'FrenchKiller', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(186, 0, 0, 2, 0, 0, 1, 'SwE|Mos|-', 2, 100, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(186, 1, 0, 3, 2, 37, 1, '=HHG=titidu81', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(186, 2, 1, 1, 2, 54, 0, 'Sarah-Connor', 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(186, 3, 2, 1, 0, 76, 0, 'Rambe', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(186, 4, 0, 0, 0, 0, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(187, 0, 0, 9, 13, 43, 0, 'barrio7', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(187, 1, 0, 16, 6, 146, 1, 'rikk4rd', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(187, 2, 0, 0, 0, 0, 0, 'KILLERMAX', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(187, 3, 0, 1, 1, 6, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(188, 0, 0, 9, 13, 43, 0, 'barrio7', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(188, 1, 0, 17, 6, 156, 1, 'rikk4rd', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 28, 312, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(188, 2, 0, 0, 1, -4, 0, 'KILLERMAX', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(188, 3, 0, 1, 1, 6, 4, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(189, 0, 0, 0, 0, 0, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(190, 0, 0, 0, 0, 0, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(190, 1, 0, 0, 0, 0, 1, 'Santa Far', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(190, 2, 0, 0, 0, 0, 0, 'Honey Bunny', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(190, 3, 0, 0, 0, 0, 0, 'luggable', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(191, 0, 0, -1, 0, 0, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(191, 1, 0, 0, 1, 0, 1, 'Santa Far', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(191, 2, 0, 0, 0, 0, 0, 'Honey Bunny', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(191, 3, 0, 0, 0, 0, 0, 'luggable', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(192, 0, 0, -2, 1, 0, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(192, 1, 0, 0, 1, 0, 1, 'Santa Far', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(192, 2, 0, 0, 0, 0, 0, 'Honey Bunny', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(192, 3, 0, 0, 0, 0, 0, 'luggable', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 1, 1, 6, 14, 63, 0, '.44Magnum', 0, 0, 0, 0, 0, 0, 7, 345, 0, 0, 0, 0, 17, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 2, 0, 18, 45, 169, 0, 'noob|gnlscience', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 160, 11, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 3, 0, 8, 15, 67, 0, 'Cloak&Dagger', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 560, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 4, 3, 20, 17, 432, 1, 'pepe', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 120, 0, 0, 0, 0, 16, 114);
INSERT INTO `ss_meta_players` VALUES(193, 5, 4, 46, 32, 999, 0, 'Trance', 0, 0, 0, 0, 0, 0, 0, 0, 98, 510, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 6, 1, 33, 9, 581, 1, 'Goyo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 49, 528, 0, 0, 7, 282, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 7, 0, 15, 28, 131, 0, 'BliZzaRd', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 8, 0, 1, 2, 7, 0, 'jorgp2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 9, 0, 39, 26, 469, 1, 'SwE|Mos|-', 6, 0, 4, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 10, 0, 3, 14, -1, 1, 'nidhal', 0, 0, 0, 0, 2, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 12, 1, 13, 20, 215, 1, 'BR|_Emicidio', 0, 0, 0, 0, 0, 0, 9, 230, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 13, 0, 14, 7, 222, 1, 'aLovelyNosegey', 0, 0, 0, 0, 0, 0, 5, 360, 46, 255, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 14, 0, 8, 7, 92, 1, 'Drakatch', 0, 0, 0, 0, 0, 0, 6, 325, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 15, 0, -1, 10, -36, 0, 'ayberk', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 16, 1, 8, 0, 218, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 54, 408, 0, 0, 1, 169, 0, 0);
INSERT INTO `ss_meta_players` VALUES(193, 18, 0, 6, 4, 112, 1, 'povkon!', 0, 0, 0, 0, 0, 0, 8, 155, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 0, 0, 0, 0, 0, 0, 'Edd', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 1, 1, 6, 15, 59, 0, '.44Magnum', 0, 0, 0, 0, 0, 0, 7, 345, 0, 0, 0, 0, 17, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 2, 0, 18, 46, 165, 0, 'noob|gnlscience', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 240, 11, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 3, 0, 10, 15, 112, 0, 'Cloak&Dagger', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 720, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 4, 3, 20, 17, 444, 1, 'pepe', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 120, 0, 0, 0, 0, 16, 114);
INSERT INTO `ss_meta_players` VALUES(194, 5, 4, 46, 33, 995, 0, 'Trance', 0, 0, 0, 0, 0, 0, 0, 0, 103, 510, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 6, 1, 36, 10, 631, 1, 'Goyo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 74, 768, 0, 0, 8, 466, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 7, 0, 15, 28, 127, 0, 'BliZzaRd', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 8, 0, 1, 2, 7, 0, 'jorgp2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 9, 0, 40, 27, 503, 1, 'SwE|Mos|-', 6, 0, 7, 36, 0, 0, 0, 0, 0, 0, 12, 480, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 10, 0, 3, 14, -1, 1, 'nidhal', 0, 0, 0, 0, 4, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 12, 1, 13, 20, 215, 1, 'BR|_Emicidio', 0, 0, 0, 0, 0, 0, 10, 270, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 13, 0, 16, 8, 289, 1, 'aLovelyNosegey', 0, 0, 0, 0, 0, 0, 9, 645, 46, 255, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 14, 0, 8, 7, 92, 1, 'Drakatch', 0, 0, 0, 0, 0, 0, 6, 325, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 15, 0, -1, 12, -44, 0, 'ayberk', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 16, 1, 8, 1, 214, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 54, 408, 0, 0, 1, 169, 0, 0);
INSERT INTO `ss_meta_players` VALUES(194, 18, 0, 5, 4, 92, 1, 'povkon!', 0, 0, 0, 0, 0, 0, 8, 155, 0, 0, 0, 0, 0, 0, 0, 0, 4, 141, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 0, 0, 1, 1, 7, 0, 'Edd', 0, 0, 0, 0, 8, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 1, 1, 6, 17, 51, 0, '.44Magnum', 0, 0, 0, 0, 4, 0, 9, 385, 0, 0, 0, 0, 17, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 2, 0, 19, 47, 185, 0, 'noob|gnlscience', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 400, 11, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 3, 0, 14, 18, 176, 0, 'Cloak&Dagger', 11, 150, 0, 0, 0, 0, 0, 0, 0, 0, 16, 800, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 4, 3, 20, 19, 436, 1, 'pepe', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 192, 0, 0, 0, 0, 16, 114);
INSERT INTO `ss_meta_players` VALUES(195, 5, 4, 49, 35, 1045, 0, 'Trance', 0, 0, 0, 0, 0, 0, 0, 0, 163, 750, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 6, 1, 38, 11, 652, 1, 'Goyo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120, 1176, 0, 0, 12, 474, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 7, 0, 15, 29, 123, 0, 'BliZzaRd', 12, 0, 0, 0, 0, 0, 0, 0, 31, 105, 6, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 8, 0, 1, 2, 7, 0, 'jorgp2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 9, 0, 0, 0, 0, 1, 'Deka!', 0, 0, 0, 0, 0, 0, 2, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 10, 0, 5, 16, 11, 1, 'nidhal', 0, 0, 0, 0, 19, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 12, 1, 15, 21, 255, 1, 'BR|_Emicidio', 0, 0, 0, 0, 0, 0, 15, 500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 13, 0, 19, 10, 355, 1, 'aLovelyNosegey', 0, 0, 0, 0, 0, 0, 16, 925, 46, 255, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 14, 0, 9, 8, 115, 1, 'Drakatch', 0, 0, 0, 0, 0, 0, 16, 545, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 15, 0, -1, 13, -48, 0, 'ayberk', 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 144, 0, 0, 0, 0, 25, 76);
INSERT INTO `ss_meta_players` VALUES(195, 16, 1, 11, 3, 286, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120, 816, 0, 0, 1, 169, 0, 0);
INSERT INTO `ss_meta_players` VALUES(195, 18, 0, 8, 6, 133, 1, 'povkon!', 0, 0, 0, 0, 0, 0, 17, 595, 0, 0, 0, 0, 0, 0, 0, 0, 4, 141, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 0, 0, 1, 2, 3, 0, 'Edd', 0, 0, 0, 0, 12, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 1, 1, 7, 18, 69, 0, '.44Magnum', 0, 0, 0, 0, 4, 0, 12, 535, 0, 0, 0, 0, 17, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 2, 0, 19, 47, 185, 0, 'noob|gnlscience', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 400, 11, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 3, 0, 16, 19, 194, 0, 'Cloak&Dagger', 11, 150, 0, 0, 0, 0, 0, 0, 0, 0, 19, 960, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 4, 3, 20, 20, 432, 1, 'pepe', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 52, 264, 0, 0, 0, 0, 16, 114);
INSERT INTO `ss_meta_players` VALUES(196, 5, 4, 52, 35, 1093, 0, 'Trance', 0, 0, 0, 0, 0, 0, 0, 0, 195, 975, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 6, 1, 40, 12, 668, 1, 'Goyo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 141, 1368, 0, 0, 12, 474, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 7, 0, 15, 29, 123, 0, 'BliZzaRd', 14, 50, 0, 0, 0, 0, 0, 0, 31, 105, 6, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 8, 0, 1, 2, 7, 0, 'jorgp2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 9, 0, 1, 1, 6, 1, 'Deka!', 0, 0, 0, 0, 0, 0, 4, 170, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 10, 0, 6, 17, 17, 1, 'nidhal', 0, 0, 0, 0, 22, 420, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 12, 1, 15, 22, 251, 1, 'BR|_Emicidio', 0, 0, 0, 0, 0, 0, 16, 545, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 13, 0, 19, 10, 355, 1, 'aLovelyNosegey', 0, 0, 0, 0, 0, 0, 17, 925, 46, 255, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 15, 0, -1, 14, -52, 0, 'ayberk', 14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 144, 0, 0, 0, 0, 25, 76);
INSERT INTO `ss_meta_players` VALUES(196, 16, 1, 12, 3, 296, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 141, 960, 0, 0, 1, 169, 0, 0);
INSERT INTO `ss_meta_players` VALUES(196, 18, 0, 8, 7, 141, 1, 'povkon!', 0, 0, 0, 0, 0, 0, 19, 610, 0, 0, 0, 0, 0, 0, 0, 0, 6, 144, 0, 0);
INSERT INTO `ss_meta_players` VALUES(197, 0, 3, 10, 28, 50, 1, 'manon', 2, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(197, 1, 0, 29, 28, 173, 0, 'daxter', 0, 0, 0, 0, 0, 0, 3, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(197, 2, 5, 36, 27, 333, 1, 'Darkell', 0, 0, 13, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(197, 3, 0, 1, 0, 15, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 96, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(198, 0, 0, 0, 0, 0, 1, 'manon', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(198, 1, 0, 0, 0, 0, 0, 'daxter', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(198, 2, 0, 1, 0, 15, 1, 'Darkell', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 114);
INSERT INTO `ss_meta_players` VALUES(198, 3, 0, 0, 1, -4, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(199, 0, 0, 3, 1, 74, 0, 'Rias_Gremory~', 0, 0, 0, 0, 0, 0, 0, 0, 41, 120, 0, 0, 0, 0, 0, 0, 6, 403, 0, 0);
INSERT INTO `ss_meta_players` VALUES(199, 1, 0, 11, 13, 122, 0, 'ideal_standard', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(199, 2, 3, 18, 7, 398, 0, 'LMFAO', 0, 0, 7, 36, 0, 0, 0, 0, 0, 0, 7, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(199, 3, 2, 6, 3, 326, 1, 'SparkingPot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 40, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(199, 4, 1, 7, 3, 278, 0, '|KH|failure', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(199, 5, 2, 3, 12, 156, 1, 'Maax.--.', 0, 0, 0, 0, 0, 0, 3, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(199, 6, 0, 9, 19, 58, 1, 'MG>DarkOrbit', 0, 0, 0, 0, 0, 0, 3, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(199, 7, 0, 9, 1, 154, 1, '|BH|Alud', 0, 0, 0, 0, 0, 0, 0, 0, 39, 210, 0, 0, 0, 0, 0, 0, 2, 67, 48, 76);
INSERT INTO `ss_meta_players` VALUES(199, 8, 0, 4, 2, 59, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 96, 0, 0, 2, 238, 0, 0);
INSERT INTO `ss_meta_players` VALUES(199, 9, 0, 6, 6, 81, 0, 'dcrits', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 34, 240, 0, 0, 1, 156, 0, 0);
INSERT INTO `ss_meta_players` VALUES(199, 10, 0, 3, 2, 23, 1, 'NubMerc', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21, 192, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(199, 11, 0, 0, 1, -4, 4, '|BH|Falcon"X"', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 0, 0, 9, 25, 54, 0, 'ninjaprofrhere', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 1, 0, 22, 23, 239, 0, 'ladrao157', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 2, 0, 2, 1, 16, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 3, 2, 38, 19, 705, 0, 'Djokovic', 0, 0, 0, 0, 0, 0, 1, 15, 16, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 4, 0, 0, 0, 0, 1, 'Rias_Gremory~', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 5, 0, 22, 18, 173, 1, 'Nirvana', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 96, 0, 0, 1, 87, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 7, 0, 14, 32, 198, 0, 'BlindManiac', 0, 0, 0, 0, 0, 0, 3, 185, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 8, 0, 2, 4, -2, 1, '[KOR]dldduzld', 0, 0, 0, 0, 0, 0, 4, 200, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 9, 0, 0, 15, -53, 0, 'ballremover', 0, 0, 0, 0, 0, 0, 0, 0, 22, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 10, 0, 12, 16, 105, 1, 'Tadpole', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 11, 0, 0, 24, -49, 1, 'Archeon', 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 12, 0, 5, 19, 56, 0, 'fred(fr)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 15, 1, 24, 25, 541, 1, 'Rnbw-Dash_SAINT', 0, 0, 0, 0, 0, 0, 3, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 16, 1, 43, 25, 743, 0, 'JR`', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 247);
INSERT INTO `ss_meta_players` VALUES(200, 18, 6, 23, 12, 838, 1, 'som', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 28, 240, 0, 0, 2, 123, 0, 0);
INSERT INTO `ss_meta_players` VALUES(200, 19, 1, 22, 16, 464, 1, 'Naruto', 0, 0, 0, 0, 0, 0, 0, 0, 19, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 0, 0, 9, 26, 50, 0, 'ninjaprofrhere', 0, 0, 0, 0, 0, 0, 7, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 1, 0, 23, 24, 246, 0, 'ladrao157', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 216, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 2, 0, 5, 2, 68, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 74, 672, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 3, 2, 39, 21, 726, 0, 'Djokovic', 0, 0, 0, 0, 0, 0, 5, 250, 16, 45, 0, 0, 0, 0, 0, 0, 2, 36, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 4, 0, 2, 1, 42, 1, 'Rias_Gremory~', 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 56, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 5, 0, 24, 19, 213, 1, 'Nirvana', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 456, 0, 0, 5, 87, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 7, 0, 15, 34, 202, 0, 'BlindManiac', 0, 0, 0, 0, 0, 0, 9, 380, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 8, 0, 4, 5, 116, 1, '[KOR]dldduzld', 0, 0, 0, 0, 0, 0, 10, 490, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 9, 0, 1, 17, -50, 0, 'ballremover', 0, 0, 0, 0, 0, 0, 0, 0, 25, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 10, 0, 12, 17, 101, 1, 'Tadpole', 0, 0, 0, 0, 0, 0, 0, 0, 39, 150, 6, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 11, 0, 0, 26, -57, 1, 'Archeon', 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 12, 0, 5, 19, 56, 0, 'fred(fr)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 15, 1, 26, 28, 551, 1, 'Rnbw-Dash_SAINT', 0, 0, 0, 0, 0, 0, 7, 270, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 16, 1, 45, 26, 804, 0, 'JR`', 0, 0, 0, 0, 0, 0, 0, 0, 46, 135, 0, 0, 0, 0, 0, 0, 0, 0, 48, 247);
INSERT INTO `ss_meta_players` VALUES(201, 18, 6, 24, 12, 860, 1, 'som', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 264, 0, 0, 4, 123, 0, 0);
INSERT INTO `ss_meta_players` VALUES(201, 19, 1, 22, 17, 460, 1, 'Naruto', 0, 0, 0, 0, 0, 0, 0, 0, 19, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 0, 0, 9, 26, 50, 0, 'ninjaprofrhere', 0, 0, 0, 0, 0, 0, 7, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 1, 0, 24, 26, 261, 0, 'ladrao157', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 94, 480, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 2, 0, 7, 4, 106, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 94, 816, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 3, 2, 40, 22, 744, 0, 'Djokovic', 0, 0, 0, 0, 0, 0, 7, 325, 16, 45, 0, 0, 0, 0, 0, 0, 2, 36, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 4, 0, 6, 2, 154, 1, 'Rias_Gremory~', 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 74, 360, 0, 0, 2, 0, 32, 171);
INSERT INTO `ss_meta_players` VALUES(202, 5, 0, 25, 20, 229, 1, 'Nirvana', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 456, 0, 0, 11, 404, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 7, 0, 15, 36, 194, 0, 'BlindManiac', 0, 0, 0, 0, 0, 0, 13, 480, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 9, 0, 1, 19, -58, 0, 'ballremover', 2, 0, 0, 0, 0, 0, 1, 25, 25, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 10, 0, 12, 18, 97, 1, 'Tadpole', 0, 0, 0, 0, 0, 0, 0, 0, 57, 165, 6, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 11, 0, -1, 27, -105, 1, 'Archeon', 0, 0, 0, 0, 0, 0, 8, 115, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 12, 0, 5, 19, 56, 0, 'fred(fr)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 15, 1, 27, 29, 577, 1, 'Rnbw-Dash_SAINT', 0, 0, 0, 0, 0, 0, 8, 375, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 16, 1, 46, 28, 823, 0, 'JR`', 0, 0, 0, 0, 0, 0, 0, 0, 122, 345, 0, 0, 0, 0, 0, 0, 0, 0, 48, 247);
INSERT INTO `ss_meta_players` VALUES(202, 18, 7, 25, 13, 953, 1, 'som', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 71, 312, 0, 0, 6, 364, 0, 0);
INSERT INTO `ss_meta_players` VALUES(202, 19, 1, 23, 18, 482, 1, 'Naruto', 0, 0, 0, 0, 0, 0, 0, 0, 63, 375, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(203, 0, 5, 23, 7, 399, 1, 'FrT|Montana', 3, 0, 6, 0, 0, 0, 0, 0, 0, 0, 18, 240, 0, 0, 0, 0, 8, 67, 0, 0);
INSERT INTO `ss_meta_players` VALUES(203, 1, 0, 9, 17, 48, 1, 'i`m-not-a-fake', 0, 0, 0, 0, 31, 1020, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(203, 2, 1, 15, 7, 332, 1, 'X', 5, 150, 1, 0, 0, 0, 0, 0, 0, 0, 18, 1120, 0, 0, 0, 0, 2, 37, 0, 0);
INSERT INTO `ss_meta_players` VALUES(203, 3, 0, 3, 1, 34, 0, 'sensimilla', 0, 0, 0, 0, 0, 0, 0, 0, 92, 405, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(203, 4, 2, 10, 11, 147, 0, 'FrT|DeathGun', 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 19, 960, 0, 0, 0, 0, 8, 318, 0, 0);
INSERT INTO `ss_meta_players` VALUES(203, 5, 0, 5, 4, 71, 1, 'Raizen', 2, 0, 19, 180, 0, 0, 0, 0, 0, 0, 18, 480, 0, 0, 0, 0, 8, 246, 0, 0);
INSERT INTO `ss_meta_players` VALUES(203, 6, 0, 0, 0, 12, 1, '[aCKa]lighting', 0, 0, 0, 0, 0, 0, 2, 70, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(203, 7, 3, 6, 11, 280, 0, '=HHG=Angel.PT', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 480, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(203, 8, 0, 6, 2, 151, 0, 'Ed<3Crystal|UF|', 4, 50, 32, 180, 0, 0, 0, 0, 0, 0, 13, 240, 0, 0, 0, 0, 8, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(203, 9, 0, 3, 5, 69, 0, 'B}Verse', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 109, 504, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(203, 10, 0, 1, 3, 10, 1, 'KR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 72, 0, 0, 0, 0, 13, 38);
INSERT INTO `ss_meta_players` VALUES(203, 11, 0, 1, 0, 11, 0, 'valin_ff', 0, 0, 0, 0, 0, 0, 0, 0, 49, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(204, 0, 7, 54, 32, 970, 1, 'FrT|Montana', 15, 100, 42, 144, 0, 0, 0, 0, 0, 0, 63, 2800, 312, 1968, 0, 0, 36, 682, 0, 0);
INSERT INTO `ss_meta_players` VALUES(204, 1, 0, 37, 40, 369, 0, 'i`m-not-a-fake', 6, 100, 0, 0, 174, 4740, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 219, 0, 0);
INSERT INTO `ss_meta_players` VALUES(204, 2, 4, 63, 32, 1206, 0, 'X', 22, 600, 6, 54, 0, 0, 0, 0, 0, 0, 120, 6480, 0, 0, 0, 0, 24, 338, 0, 0);
INSERT INTO `ss_meta_players` VALUES(204, 3, 0, 4, 15, 53, 1, 'Xerebedelll', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 720, 0, 0, 0, 0, 2, 37, 0, 0);
INSERT INTO `ss_meta_players` VALUES(204, 4, 3, 40, 36, 547, 1, 'FrT|DeathGun', 7, 100, 6, 54, 0, 0, 0, 0, 0, 0, 56, 2640, 380, 2592, 0, 0, 42, 747, 0, 0);
INSERT INTO `ss_meta_players` VALUES(204, 5, 3, 40, 26, 798, 0, 'Raizen', 11, 150, 91, 630, 0, 0, 0, 0, 0, 0, 116, 3600, 0, 0, 0, 0, 48, 1197, 28, 171);
INSERT INTO `ss_meta_players` VALUES(204, 6, 2, 21, 23, 507, 0, '[aCKa]lighting', 2, 0, 0, 0, 0, 0, 90, 2910, 0, 0, 0, 0, 0, 0, 0, 0, 30, 110, 0, 0);
INSERT INTO `ss_meta_players` VALUES(204, 7, 4, 25, 41, 747, 1, '=HHG=Angel.PT', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 493, 2904, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(204, 8, 0, 0, 0, 0, 4, 'lucky', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(204, 9, 1, 33, 31, 715, 1, 'B}Verse', 4, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 764, 3864, 0, 0, 10, 343, 0, 0);
INSERT INTO `ss_meta_players` VALUES(204, 10, 0, 12, 10, 226, 0, 'dgfsa', 0, 0, 0, 0, 86, 1800, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(204, 11, 0, 0, 0, 0, 4, '-My.|^OnDuTy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(205, 0, 0, 23, 14, 174, 0, 'B}Verse', 9, 100, 0, 0, 0, 0, 0, 0, 0, 0, 40, 1520, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(205, 1, 0, 5, 10, 10, 1, 'Cyril30', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(205, 2, 0, 19, 15, 115, 1, 'W@rr!0r*', 15, 100, 0, 0, 0, 0, 0, 0, 0, 0, 34, 1440, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(205, 3, 0, 15, 12, 102, 0, '[ED]HGF-ARG', 4, 150, 0, 0, 0, 0, 0, 0, 0, 0, 17, 720, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(205, 4, 0, 2, 3, 8, 0, 'marco12368', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(205, 6, 0, 0, 0, 0, 4, 'nikhop', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(206, 0, 0, 32, 6, 455, 0, 'FD*fundog', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 360, 2712, 0, 0, 8, 108, 0, 0);
INSERT INTO `ss_meta_players` VALUES(206, 1, 1, 10, 11, 203, 0, 'B}Verse', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 183, 1176, 0, 0, 8, 250, 0, 0);
INSERT INTO `ss_meta_players` VALUES(206, 2, 0, 9, 36, 52, 1, '.357', 0, 0, 0, 0, 5, 180, 24, 760, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(206, 3, 0, 6, 5, 61, 0, '{BoB}gRamps', 0, 0, 21, 90, 0, 0, 0, 0, 0, 0, 10, 400, 0, 0, 0, 0, 6, 66, 26, 133);
INSERT INTO `ss_meta_players` VALUES(206, 6, 0, 18, 31, 164, 0, 'Knall-Erbse', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 186, 1536, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(206, 7, 2, 36, 27, 669, 0, 'FrT|Zaekrom', 0, 0, 0, 0, 0, 0, 0, 0, 197, 915, 0, 0, 239, 1344, 0, 0, 0, 0, 23, 114);
INSERT INTO `ss_meta_players` VALUES(206, 9, 0, 57, 24, 848, 1, '=SA=ThePrinter', 0, 0, 0, 0, 0, 0, 0, 0, 537, 2625, 0, 0, 0, 0, 0, 0, 2, 41, 24, 190);
INSERT INTO `ss_meta_players` VALUES(206, 10, 0, 17, 25, 281, 1, 'Pi_Ketar*', 0, 0, 0, 0, 0, 0, 0, 0, 274, 1275, 0, 0, 0, 0, 0, 0, 24, 35, 0, 0);
INSERT INTO `ss_meta_players` VALUES(206, 12, 2, 23, 29, 392, 1, 'AlexPerm', 0, 0, 0, 0, 0, 0, 0, 0, 473, 1695, 0, 0, 0, 0, 0, 0, 15, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(207, 0, 0, 0, 0, 0, 4, '.45|M!S3|#', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(207, 1, 4, 16, 13, 153, 0, '#An0niMe.ReN|', 0, 0, 0, 0, 0, 0, 0, 0, 169, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(207, 2, 2, 2, 7, 32, 0, '{BoB}Haittah', 0, 0, 2, 18, 0, 0, 0, 0, 0, 0, 12, 480, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(207, 3, 0, 2, 1, 47, 1, 'BLC', 0, 0, 0, 0, 0, 0, 6, 305, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(207, 4, 6, 9, 12, 172, 1, '|uRs|.ShoGun', 0, 0, 0, 0, 0, 0, 0, 0, 105, 330, 0, 0, 0, 0, 0, 0, 8, 17, 0, 0);
INSERT INTO `ss_meta_players` VALUES(207, 5, 1, 20, 8, 239, 1, 'Gork', 0, 0, 3, 18, 0, 0, 0, 0, 167, 705, 0, 0, 0, 0, 0, 0, 8, 162, 18, 76);
INSERT INTO `ss_meta_players` VALUES(207, 6, 2, 8, 3, 169, 0, 'B}Verse', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 111, 768, 0, 0, 0, 0, 17, 114);
INSERT INTO `ss_meta_players` VALUES(207, 7, 0, 0, 0, 0, 4, 'ReN|-LeXuS-[T]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(207, 9, 11, 21, 21, 337, 0, '.:HsOs:.W@RR3N', 4, 0, 0, 0, 0, 0, 0, 0, 66, 195, 8, 160, 0, 0, 0, 0, 10, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(208, 0, 1, 9, 13, 166, 0, '|KH|Emoposer', 0, 0, 3, 36, 0, 0, 0, 0, 207, 675, 4, 240, 21, 168, 0, 0, 8, 0, 12, 38);
INSERT INTO `ss_meta_players` VALUES(208, 1, 3, 7, 23, -74, 0, 'CS-Police', 0, 0, 0, 0, 0, 0, 44, 985, 86, 255, 0, 0, 0, 0, 0, 0, 16, 113, 0, 0);
INSERT INTO `ss_meta_players` VALUES(208, 2, 3, 27, 21, 429, 0, '|3i|draza', 0, 0, 0, 0, 0, 0, 91, 3775, 0, 0, 0, 0, 0, 0, 0, 0, 22, 284, 0, 0);
INSERT INTO `ss_meta_players` VALUES(208, 3, 4, 27, 41, 380, 1, 'BLC', 0, 0, 0, 0, 0, 0, 112, 4225, 0, 0, 0, 0, 0, 0, 0, 0, 26, 167, 0, 0);
INSERT INTO `ss_meta_players` VALUES(208, 4, 0, 6, 4, 23, 1, '{BoB}macm[T]', 0, 0, 2, 18, 0, 0, 0, 0, 0, 0, 8, 560, 42, 192, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(208, 5, 1, 23, 37, 227, 1, '{BoB}gRamps', 2, 0, 95, 540, 0, 0, 0, 0, 0, 0, 87, 2720, 63, 336, 0, 0, 30, 615, 9, 57);
INSERT INTO `ss_meta_players` VALUES(208, 6, 9, 21, 31, 273, 1, 'B}Verse', 0, 0, 0, 0, 0, 0, 21, 910, 0, 0, 0, 0, 390, 2232, 0, 0, 7, 63, 15, 38);
INSERT INTO `ss_meta_players` VALUES(208, 7, 4, 48, 41, 535, 0, '{BoB}Haittah', 2, 100, 28, 162, 0, 0, 0, 0, 0, 0, 16, 800, 748, 5352, 0, 0, 48, 606, 79, 475);
INSERT INTO `ss_meta_players` VALUES(208, 8, 12, 86, 19, 1551, 0, 'Zic0', 1, 50, 15, 72, 0, 0, 0, 0, 0, 0, 0, 0, 1146, 9312, 0, 0, 26, 211, 122, 722);
INSERT INTO `ss_meta_players` VALUES(208, 9, 1, 43, 26, 541, 1, 'Gork', 0, 0, 2, 0, 0, 0, 0, 0, 805, 3330, 0, 0, 264, 1776, 0, 0, 35, 169, 107, 513);
INSERT INTO `ss_meta_players` VALUES(208, 10, 0, 4, 6, 17, 0, 'U', 0, 0, 0, 0, 28, 480, 0, 0, 31, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(208, 11, 2, 10, 23, -151, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 288, 1872, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(209, 0, 0, 27, 31, 324, 0, '|40+|shad-99', 0, 0, 7, 18, 0, 0, 0, 0, 0, 0, 0, 0, 541, 3024, 0, 0, 16, 192, 0, 0);
INSERT INTO `ss_meta_players` VALUES(209, 1, 1, 23, 42, 265, 1, 'WuB', 2, 0, 31, 162, 0, 0, 1, 15, 0, 0, 22, 800, 372, 2088, 0, 0, 18, 172, 11, 38);
INSERT INTO `ss_meta_players` VALUES(209, 2, 1, 30, 35, 471, 0, 'KANUNI', 0, 0, 0, 0, 0, 0, 7, 265, 0, 0, 0, 0, 717, 4464, 0, 0, 36, 726, 16, 171);
INSERT INTO `ss_meta_players` VALUES(209, 3, 0, 0, 1, -4, 1, 'R0GU3', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(209, 4, 0, 9, 16, 135, 0, '.45|M!S3|#', 0, 0, 18, 54, 0, 0, 0, 0, 0, 0, 13, 560, 207, 840, 0, 0, 6, 135, 0, 0);
INSERT INTO `ss_meta_players` VALUES(209, 5, 1, 38, 28, 434, 4, 'Phear.', 0, 0, 6, 54, 0, 0, 0, 0, 0, 0, 0, 0, 710, 5232, 0, 0, 8, 0, 61, 361);
INSERT INTO `ss_meta_players` VALUES(209, 6, 2, 69, 28, 1002, 1, 'L0rdzZ', 22, 250, 140, 864, 0, 0, 0, 0, 0, 0, 114, 6880, 0, 0, 0, 0, 16, 320, 19, 171);
INSERT INTO `ss_meta_players` VALUES(209, 7, 0, 63, 32, 849, 1, '.AlliuM~', 0, 0, 220, 1080, 0, 0, 0, 0, 0, 0, 131, 7360, 0, 0, 0, 0, 22, 587, 10, 38);
INSERT INTO `ss_meta_players` VALUES(209, 8, 2, 27, 40, 481, 1, 'B}Verse', 2, 100, 0, 0, 0, 0, 2, 75, 0, 0, 0, 0, 699, 4488, 0, 0, 7, 145, 0, 0);
INSERT INTO `ss_meta_players` VALUES(209, 9, 0, 65, 30, 756, 0, 'Zic0', 8, 200, 179, 1242, 0, 0, 0, 0, 0, 0, 128, 6240, 0, 0, 0, 0, 28, 73, 18, 152);
INSERT INTO `ss_meta_players` VALUES(209, 11, 0, 26, 32, 219, 0, '{BoB}gRamps', 0, 0, 23, 90, 0, 0, 0, 0, 0, 0, 12, 480, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(210, 1, 2, 28, 14, 572, 1, 'patate', 0, 0, 0, 0, 0, 0, 0, 0, 562, 2655, 0, 0, 0, 0, 0, 0, 48, 963, 0, 0);
INSERT INTO `ss_meta_players` VALUES(210, 2, 0, 1, 16, -7, 0, 'bloodymace', 0, 0, 0, 0, 0, 0, 16, 140, 5, 45, 0, 0, 1, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(210, 3, 0, 5, 26, -33, 1, 'lazaroterror', 0, 0, 2, 0, 17, 240, 21, 645, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 19);
INSERT INTO `ss_meta_players` VALUES(210, 4, 6, 48, 17, 1345, 1, 'SaXzE{TyD}', 2, 50, 10, 36, 0, 0, 0, 0, 765, 3300, 0, 0, 0, 0, 0, 0, 31, 483, 0, 0);
INSERT INTO `ss_meta_players` VALUES(210, 5, 2, 20, 18, 560, 0, 'B}Verse', 0, 0, 3, 18, 0, 0, 0, 0, 0, 0, 0, 0, 358, 2616, 0, 0, 6, 221, 67, 437);
INSERT INTO `ss_meta_players` VALUES(210, 9, 1, 26, 31, 501, 0, 'DarkFight', 0, 0, 0, 0, 0, 0, 0, 0, 652, 2760, 0, 0, 90, 552, 0, 0, 12, 87, 0, 0);
INSERT INTO `ss_meta_players` VALUES(211, 1, 7, 21, 24, 678, 1, 'patate', 0, 0, 12, 36, 0, 0, 0, 0, 926, 3270, 0, 0, 0, 0, 0, 0, 8, 107, 0, 0);
INSERT INTO `ss_meta_players` VALUES(211, 2, 2, 15, 19, 263, 0, 'Pan', 0, 0, 6, 36, 0, 0, 36, 1265, 49, 180, 0, 0, 179, 1104, 0, 0, 8, 91, 0, 0);
INSERT INTO `ss_meta_players` VALUES(211, 3, 2, 31, 18, 450, 1, 'h.ac.k', 1, 0, 77, 414, 0, 0, 0, 0, 0, 0, 54, 3360, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(211, 4, 4, 30, 23, 560, 0, 'SaXzE{TyD}', 4, 50, 13, 72, 0, 0, 0, 0, 629, 2730, 22, 1040, 0, 0, 0, 0, 8, 57, 0, 0);
INSERT INTO `ss_meta_players` VALUES(211, 5, 2, 37, 26, 593, 0, 'B}Verse', 0, 0, 7, 36, 0, 0, 0, 0, 0, 0, 0, 0, 592, 4320, 0, 0, 2, 160, 0, 0);
INSERT INTO `ss_meta_players` VALUES(211, 6, 0, 1, 8, -6, 1, 'holi', 0, 0, 5, 72, 0, 0, 0, 0, 101, 255, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(211, 9, 2, 16, 25, 326, 1, 'DarkFight', 1, 0, 0, 0, 0, 0, 0, 0, 573, 2250, 0, 0, 0, 0, 0, 0, 4, 22, 0, 0);
INSERT INTO `ss_meta_players` VALUES(212, 3, 0, 6, 3, 38, 1, 'h.ac.k', 0, 0, 11, 54, 0, 0, 0, 0, 0, 0, 12, 880, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(212, 4, 0, 6, 1, 51, 0, 'SaXzE{TyD}', 2, 0, 5, 36, 0, 0, 0, 0, 0, 0, 9, 640, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(212, 5, 0, 0, 2, -8, 1, 'B}Verse', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 54, 312, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(212, 6, 0, 0, 1, -14, 0, 'holi', 0, 0, 0, 0, 0, 0, 0, 0, 40, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(213, 0, 0, 32, 32, 527, 1, 'B}V-Man', 0, 0, 0, 0, 0, 0, 0, 0, 943, 3720, 0, 0, 0, 0, 0, 0, 16, 141, 0, 0);
INSERT INTO `ss_meta_players` VALUES(213, 1, 4, 21, 35, 605, 0, 'GsF|gabybaires', 0, 0, 9, 54, 0, 0, 0, 0, 1163, 3660, 0, 0, 0, 0, 0, 0, 56, 556, 0, 0);
INSERT INTO `ss_meta_players` VALUES(213, 2, 0, 6, 27, 6, 1, 'B}V-Wifey', 0, 0, 77, 342, 0, 0, 0, 0, 0, 0, 60, 800, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(213, 3, 5, 33, 23, 620, 1, 'h.ac.k', 4, 0, 123, 612, 0, 0, 0, 0, 0, 0, 133, 4080, 0, 0, 0, 0, 18, 357, 13, 57);
INSERT INTO `ss_meta_players` VALUES(213, 4, 1, 40, 33, 672, 0, 'SaXzE{TyD}', 13, 250, 22, 54, 0, 0, 0, 0, 0, 0, 38, 1200, 455, 3144, 0, 0, 54, 722, 0, 0);
INSERT INTO `ss_meta_players` VALUES(213, 5, 2, 41, 37, 917, 1, 'B}Verse', 1, 0, 5, 18, 0, 0, 35, 1575, 0, 0, 0, 0, 534, 3600, 0, 0, 9, 420, 89, 456);
INSERT INTO `ss_meta_players` VALUES(213, 6, 1, 8, 25, 129, 0, 'holi', 1, 0, 57, 144, 0, 0, 32, 425, 528, 1320, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(213, 7, 6, 27, 23, 859, 0, 'PooP', 19, 150, 52, 270, 0, 0, 0, 0, 0, 0, 78, 2800, 0, 0, 0, 0, 48, 702, 0, 0);
INSERT INTO `ss_meta_players` VALUES(213, 8, 1, 38, 11, 719, 0, '-dyH|BigGunZ', 0, 0, 16, 144, 0, 0, 0, 0, 0, 0, 0, 0, 538, 4560, 0, 0, 18, 164, 0, 0);
INSERT INTO `ss_meta_players` VALUES(213, 9, 2, 23, 16, 504, 0, 'OneLastHurrah', 0, 0, 0, 0, 0, 0, 50, 2290, 0, 0, 0, 0, 0, 0, 0, 0, 14, 141, 0, 0);
INSERT INTO `ss_meta_players` VALUES(213, 11, 0, 1, 9, -24, 1, 'SUCHASURMA', 1, 0, 0, 0, 0, 0, 12, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(214, 0, 1, 45, 35, 745, 0, 'B}V-Man', 0, 0, 14, 54, 0, 0, 0, 0, 1223, 5130, 0, 0, 0, 0, 0, 0, 2, 31, 0, 0);
INSERT INTO `ss_meta_players` VALUES(214, 1, 2, 17, 43, 537, 0, 'GsF|gabybaires', 0, 0, 0, 0, 0, 0, 0, 0, 1049, 3075, 0, 0, 0, 0, 0, 0, 12, 312, 13, 19);
INSERT INTO `ss_meta_players` VALUES(214, 2, 0, 5, 46, -64, 1, 'B}V-Wifey', 0, 0, 65, 198, 0, 0, 0, 0, 0, 0, 94, 1280, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(214, 3, 0, 2, 16, 22, 0, 'unarmed', 14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 139, 720, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(214, 4, 3, 47, 34, 873, 0, 'SaXzE{TyD}', 21, 400, 10, 90, 30, 420, 14, 680, 0, 0, 48, 2480, 339, 2472, 0, 0, 10, 290, 28, 190);
INSERT INTO `ss_meta_players` VALUES(214, 5, 7, 48, 37, 1422, 1, 'B}Verse', 1, 0, 32, 180, 0, 0, 5, 130, 0, 0, 0, 0, 901, 5664, 0, 0, 1, 95, 58, 361);
INSERT INTO `ss_meta_players` VALUES(214, 6, 0, 4, 28, -26, 0, 'thejerko', 0, 0, 24, 162, 0, 0, 0, 0, 0, 0, 0, 0, 409, 2328, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(214, 7, 3, 39, 35, 1025, 1, 'PooP', 47, 400, 47, 252, 0, 0, 0, 0, 64, 165, 89, 3600, 15, 144, 0, 0, 8, 94, 77, 456);
INSERT INTO `ss_meta_players` VALUES(214, 8, 1, 5, 2, 151, 1, 'Benze#M|A#', 0, 0, 5, 18, 0, 0, 12, 350, 101, 450, 0, 0, 0, 0, 0, 0, 4, 0, 17, 95);
INSERT INTO `ss_meta_players` VALUES(214, 9, 5, 50, 44, 1284, 0, 'OneLastHurrah', 0, 0, 0, 0, 0, 0, 168, 7395, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(214, 10, 0, 15, 7, 339, 1, 'SubaRu.legacy', 0, 0, 0, 0, 0, 0, 0, 0, 250, 1080, 0, 0, 81, 600, 0, 0, 10, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(214, 11, 0, 15, 17, 203, 1, 'LocoEngr|UF|', 0, 0, 0, 0, 55, 1500, 16, 415, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(215, 0, 0, 7, 1, 106, 1, '-dyH|happy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23, 288, 0, 0, 6, 63, 0, 0);
INSERT INTO `ss_meta_players` VALUES(215, 1, 0, 0, 5, -15, 0, '.:Sj*H!tMaN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 2, 12, 0, 0);
INSERT INTO `ss_meta_players` VALUES(215, 2, 2, 1, 3, 84, 1, 'HyPE|SwellGuy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 45, 0, 0, 0, 0, 0, 15, 114);
INSERT INTO `ss_meta_players` VALUES(215, 3, 0, 3, 4, 28, 0, 'HyPE|GDM', 0, 0, 15, 126, 0, 0, 0, 0, 0, 0, 0, 0, 28, 264, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(215, 4, 0, 0, 0, 0, 4, 'Dante', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(216, 0, 4, 41, 30, 735, 1, '-dyH|happy', 0, 0, 24, 198, 0, 0, 0, 0, 24, 60, 27, 1040, 728, 3432, 0, 0, 20, 71, 147, 703);
INSERT INTO `ss_meta_players` VALUES(216, 1, 5, 31, 38, 573, 0, '.:Sj*H!tMaN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 925, 4536, 0, 0, 34, 473, 0, 0);
INSERT INTO `ss_meta_players` VALUES(216, 2, 4, 30, 36, 608, 1, 'HyPE|SwellGuy', 0, 0, 45, 288, 0, 0, 0, 0, 335, 1185, 5, 80, 681, 2784, 0, 0, 40, 324, 0, 0);
INSERT INTO `ss_meta_players` VALUES(216, 3, 1, 31, 37, 506, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 211, 945, 0, 0, 598, 3312, 0, 0, 51, 850, 0, 0);
INSERT INTO `ss_meta_players` VALUES(216, 4, 0, 0, 0, 0, 4, 'Dante', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(217, 0, 6, 44, 41, 806, 1, '-dyH|happy', 0, 0, 15, 54, 0, 0, 0, 0, 0, 0, 5, 240, 1179, 6216, 0, 0, 4, 0, 14, 95);
INSERT INTO `ss_meta_players` VALUES(217, 1, 3, 38, 49, 563, 0, '.:Sj*H!tMaN', 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 939, 4608, 0, 0, 2, 0, 134, 494);
INSERT INTO `ss_meta_players` VALUES(217, 2, 4, 44, 46, 667, 1, 'HyPE|SwellGuy', 5, 0, 30, 180, 0, 0, 0, 0, 125, 450, 17, 720, 852, 4392, 0, 0, 22, 409, 25, 95);
INSERT INTO `ss_meta_players` VALUES(217, 3, 6, 48, 40, 729, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 975, 6000, 0, 0, 9, 183, 75, 418);
INSERT INTO `ss_meta_players` VALUES(217, 4, 0, 0, 0, 0, 4, 'Dante', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(218, 0, 0, 0, 2, -8, 0, '#M|A#Specchio', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(218, 1, 0, 8, 9, 34, 4, 'TheFuCk?', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(218, 2, 0, 2, 4, 4, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 408, 0, 0, 2, 0, 4, 0);
INSERT INTO `ss_meta_players` VALUES(218, 3, 0, 22, 8, 148, 1, '*_*', 0, 0, 8, 36, 0, 0, 0, 0, 0, 0, 5, 640, 0, 0, 0, 0, 0, 0, 6, 57);
INSERT INTO `ss_meta_players` VALUES(218, 5, 0, 0, 0, 0, 4, 'Zic0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(219, 0, 0, 0, 2, -8, 0, '#M|A#Specchio', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(219, 1, 0, 7, 10, 10, 0, 'TheFuCk?', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 240, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(219, 2, 0, 4, 5, 20, 0, 'HyPE|GDM', 0, 0, 2, 18, 0, 0, 0, 0, 0, 0, 0, 0, 91, 768, 0, 0, 2, 0, 4, 0);
INSERT INTO `ss_meta_players` VALUES(219, 3, 0, 22, 10, 130, 1, '*_*', 0, 0, 15, 54, 0, 0, 0, 0, 0, 0, 13, 1040, 0, 0, 0, 0, 0, 0, 6, 57);
INSERT INTO `ss_meta_players` VALUES(219, 4, 0, 0, 1, -4, 1, '.SR|fixou', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(219, 5, 0, 0, 1, -4, 0, 'Zic0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(219, 6, 0, 0, 1, -29, 1, 'FD*EndGame', 0, 0, 11, 54, 0, 0, 0, 0, 0, 0, 4, 560, 5, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(219, 7, 0, 2, 1, 16, 1, 'SwE|Mos|-', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(220, 0, 4, 38, 25, 493, 0, 'HyPE|GDM', 0, 0, 23, 108, 0, 0, 0, 0, 0, 0, 0, 0, 713, 4464, 0, 0, 4, 83, 0, 0);
INSERT INTO `ss_meta_players` VALUES(220, 1, 4, 35, 31, 501, 0, '-dyH|BigGunZ', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 0, 0, 752, 4584, 0, 0, 2, 18, 0, 0);
INSERT INTO `ss_meta_players` VALUES(220, 2, 0, 33, 35, 327, 1, '.Ludas', 0, 0, 5, 0, 0, 0, 0, 0, 60, 135, 0, 0, 718, 3576, 0, 0, 22, 229, 75, 323);
INSERT INTO `ss_meta_players` VALUES(220, 3, 3, 22, 39, 280, 1, 'FD*1Cap', 0, 0, 0, 0, 0, 0, 7, 85, 708, 2250, 0, 0, 183, 816, 0, 0, 16, 108, 23, 57);
INSERT INTO `ss_meta_players` VALUES(221, 0, 5, 47, 32, 618, 0, 'HyPE|GDM', 0, 0, 28, 126, 0, 0, 0, 0, 0, 0, 0, 0, 863, 5280, 0, 0, 6, 83, 0, 0);
INSERT INTO `ss_meta_players` VALUES(221, 1, 4, 42, 39, 562, 0, '-dyH|BigGunZ', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 0, 0, 943, 5880, 0, 0, 2, 18, 0, 0);
INSERT INTO `ss_meta_players` VALUES(221, 2, 0, 39, 42, 374, 1, '.Ludas', 0, 0, 13, 36, 0, 0, 0, 0, 60, 135, 0, 0, 920, 4560, 0, 0, 22, 229, 75, 323);
INSERT INTO `ss_meta_players` VALUES(221, 3, 3, 31, 48, 363, 1, 'FD*1Cap', 0, 0, 0, 0, 0, 0, 7, 85, 956, 3105, 0, 0, 183, 816, 0, 0, 22, 108, 29, 57);
INSERT INTO `ss_meta_players` VALUES(222, 0, 2, 39, 36, 368, 0, 'HyPE|GDM', 1, 0, 14, 162, 0, 0, 0, 0, 50, 195, 28, 960, 613, 4416, 0, 0, 9, 553, 0, 0);
INSERT INTO `ss_meta_players` VALUES(222, 1, 2, 38, 20, 481, 0, '-dyH|BigGunZ', 0, 0, 0, 0, 9, 300, 0, 0, 0, 0, 0, 0, 369, 2352, 0, 0, 4, 0, 31, 190);
INSERT INTO `ss_meta_players` VALUES(222, 2, 0, 29, 28, 263, 1, '.Ludas', 0, 0, 11, 36, 0, 0, 0, 0, 0, 0, 12, 320, 982, 3192, 0, 0, 52, 648, 30, 76);
INSERT INTO `ss_meta_players` VALUES(222, 3, 1, 26, 49, 187, 1, 'FD*1Cap', 0, 0, 5, 36, 0, 0, 27, 780, 785, 2730, 7, 240, 0, 0, 0, 0, 10, 174, 10, 114);
INSERT INTO `ss_meta_players` VALUES(223, 0, 0, 4, 14, 4, 1, 'Darwin', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(223, 1, 7, 20, 11, 489, 1, 'Guinaepig', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(223, 2, 2, 5, 22, 53, 0, 'Emerson', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(223, 3, 3, 22, 3, 319, 1, 'b00nkind', 0, 0, 7, 18, 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(223, 4, 2, 22, 21, 309, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 27, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(223, 5, 0, 0, 0, 6, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(224, 0, 0, 15, 28, 33, 1, 'CarlGel~BCG', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26, 880, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(224, 1, 0, 21, 18, 128, 0, 'Crazy', 18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 800, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(224, 2, 0, 38, 21, 281, 0, 'GhostHero', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 560, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(224, 3, 0, 12, 12, 72, 1, 'Colgate', 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 720, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(224, 4, 0, 10, 10, 60, 0, 'mounaKea', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 800, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(224, 5, 0, 9, 4, 74, 1, 'Cookies', 4, 50, 0, 0, 0, 0, 0, 0, 0, 0, 24, 560, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(224, 6, 0, 0, 0, 0, 1, 'Coman722', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(225, 0, 0, 4, 2, 41, 1, 'mounaKea', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 42, 456, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(225, 2, 0, 16, 27, 79, 0, 'sagas', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 43, 192, 0, 0, 4, 128, 0, 0);
INSERT INTO `ss_meta_players` VALUES(225, 3, 1, 37, 21, 462, 1, 'FD*fundog', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 60, 336, 0, 0, 8, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(225, 4, 0, 10, 7, 105, 0, 'Emerson', 0, 0, 0, 0, 0, 0, 0, 0, 30, 150, 0, 0, 0, 0, 0, 0, 4, 0, 16, 95);
INSERT INTO `ss_meta_players` VALUES(225, 5, 0, 27, 17, 292, 1, 'Pi_Duckeet', 0, 0, 0, 0, 1, 0, 0, 0, 106, 450, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(225, 6, 1, 33, 13, 417, 0, '.AlliuM~', 0, 0, 14, 90, 0, 0, 0, 0, 0, 0, 9, 400, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(225, 8, 0, 2, 2, 35, 0, 'ShootMup', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 96, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(225, 9, 0, 42, 23, 462, 1, 'rGsF|carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(225, 10, 1, 19, 38, 238, 1, 'Jago', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(226, 0, 3, 45, 38, 954, 0, 'B}Verse', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 847, 6072, 0, 0, 3, 61, 0, 0);
INSERT INTO `ss_meta_players` VALUES(226, 1, 1, 24, 23, 521, 1, 'Comedian', 3, 100, 0, 0, 0, 0, 0, 0, 497, 2355, 0, 0, 0, 0, 0, 0, 20, 181, 0, 0);
INSERT INTO `ss_meta_players` VALUES(226, 2, 1, 4, 7, 79, 1, 'Apollo', 0, 0, 0, 0, 0, 0, 15, 615, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(226, 3, 1, 51, 21, 675, 1, 'FD*fundog', 0, 0, 6, 72, 0, 0, 0, 0, 0, 0, 0, 0, 737, 6024, 0, 0, 54, 391, 0, 0);
INSERT INTO `ss_meta_players` VALUES(226, 4, 0, 0, 0, 0, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(226, 6, 1, 64, 41, 960, 0, '.AlliuM~', 0, 0, 11, 72, 0, 0, 0, 0, 0, 0, 0, 0, 1023, 6624, 0, 0, 16, 77, 152, 1026);
INSERT INTO `ss_meta_players` VALUES(226, 7, 0, 16, 19, 160, 1, 'CS-Police', 0, 0, 0, 0, 0, 0, 48, 1980, 72, 180, 0, 0, 0, 0, 0, 0, 12, 185, 0, 0);
INSERT INTO `ss_meta_players` VALUES(226, 8, 0, 16, 25, 251, 0, 'revenant', 0, 0, 0, 0, 0, 0, 0, 0, 229, 795, 0, 0, 215, 1440, 0, 0, 2, 21, 0, 0);
INSERT INTO `ss_meta_players` VALUES(226, 9, 3, 25, 32, 581, 1, 'rGsF|carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 773, 4416, 0, 0, 58, 1501, 0, 0);
INSERT INTO `ss_meta_players` VALUES(226, 11, 0, 9, 15, 89, 0, 't0a5t', 0, 0, 0, 0, 0, 0, 27, 980, 0, 0, 0, 0, 77, 600, 0, 0, 0, 0, 6, 0);
INSERT INTO `ss_meta_players` VALUES(227, 0, 1, 4, 1, 112, 1, 'Dog{TyD}Dancing', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 48, 0, 0, 2, 120, 0, 0);
INSERT INTO `ss_meta_players` VALUES(227, 1, 9, -2, 3, 574, 0, 'B}Droid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 112, 168, 0, 0, 4, 31, 0, 0);
INSERT INTO `ss_meta_players` VALUES(227, 2, 0, 0, 1, -4, 1, '{TyD}Doogum7X', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(227, 3, 0, 0, 3, -12, 0, 'B}evanzo23', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(227, 4, 0, 0, 0, 0, 4, 'B}Lateralus', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(227, 5, 0, 0, 0, 0, 4, 'B}Verse', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(227, 6, 0, 0, 0, 0, 1, 'Bench.{TyD}', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 0, 0, 0, 0, 0, 4, '[SODA]___ME___', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 1, 0, 14, 24, 151, 1, 'ZanderGT-R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 2, 4, 32, 2, 659, 0, 'LordMoonaN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 120, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 3, 0, 16, 15, 147, 0, '{TBR}BHO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 4, 0, 9, 19, 72, 1, '[Hunt]DiZ[T]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 5, 0, -1, 2, -28, 1, 'ALLEN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 6, 8, 14, 7, 635, 1, 'VideoMartyr', 0, 0, 0, 0, 0, 0, 3, 210, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 7, 0, 7, 11, 107, 0, '=Ulf=', 1, 0, 4, 36, 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 8, 0, 1, 1, 8, 0, 'someone', 0, 0, 0, 0, 0, 0, 3, 255, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 9, 0, 0, 0, 0, 0, 'Z0MBIEZL4Y3R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 10, 0, 0, 2, -8, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 25, 180, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(228, 11, 0, 0, 0, 0, 0, 'wawawwwwdss', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 0, 0, 0, 0, 0, 4, '[SODA]___ME___', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 1, 0, 14, 25, 147, 1, 'ZanderGT-R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 2, 4, 32, 3, 672, 0, 'LordMoonaN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 120, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 3, 0, 16, 15, 147, 0, '{TBR}BHO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 4, 0, 0, 0, 0, 1, 'otni', 0, 0, 0, 0, 0, 0, 2, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 5, 0, -1, 3, -32, 1, 'ALLEN', 0, 0, 0, 0, 0, 0, 4, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 6, 8, 15, 7, 659, 1, 'VideoMartyr', 0, 0, 0, 0, 0, 0, 4, 315, 0, 0, 0, 0, 0, 0, 0, 0, 2, 78, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 7, 0, 8, 12, 125, 0, '=Ulf=', 1, 0, 9, 72, 0, 0, 0, 0, 0, 0, 4, 80, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 8, 0, 2, 3, 22, 0, 'someone', 0, 0, 0, 0, 0, 0, 6, 395, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 9, 0, 0, 1, -4, 0, 'Z0MBIEZL4Y3R', 0, 0, 0, 0, 0, 0, 3, 55, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 10, 0, 2, 3, 34, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 25, 180, 0, 0, 26, 216, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 11, 0, 0, 1, -24, 0, 'wawawwwwdss', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 168, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(229, 12, 0, 1, 3, -2, 1, 'griff', 0, 0, 0, 0, 0, 0, 0, 0, 38, 165, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 0, 0, 33, 19, 239, 1, 'BALTAZAR', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 1, 0, 18, 15, 121, 1, 'padwama', 1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 2, 0, 15, 8, 115, 1, 'Aurmeilius', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 3, 0, 7, 5, 46, 0, 'skP.mdK', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 4, 0, 34, 18, 268, 1, 'noobiest', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 5, 0, 4, 4, 25, 1, 'creepXmaster', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 6, 0, 18, 30, 62, 1, 'BOSS|Roentgen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 7, 0, 9, 6, 67, 1, 'hac_k', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 8, 0, 44, 24, 340, 0, 'Millenius', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 9, 0, 1, 2, 2, 1, 'gbsdkejd', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 10, 0, 1, 1, 6, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 11, 0, 34, 24, 234, 0, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 12, 0, 10, 29, -26, 1, 'DB', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 13, 0, 5, 8, 19, 0, 'skP.Andriks', 2, 50, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 14, 0, 22, 19, 119, 0, 'XXXTHAIXXX', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 15, 0, 34, 25, 226, 0, 'R2D2-BR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 16, 0, 1, 6, -24, 0, 'CamussLoko', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 17, 0, 16, 28, 44, 0, '^_^Azetox^_^', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(230, 19, 0, 2, 7, -18, 0, 'AMDAthlon64x2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 0, 0, 34, 21, 241, 1, 'BALTAZAR', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 1, 0, 20, 16, 137, 1, 'padwama', 6, 50, 0, 0, 0, 0, 0, 0, 0, 0, 5, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 2, 0, 16, 10, 117, 1, 'Aurmeilius', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 3, 0, 9, 8, 45, 0, 'skP.mdK', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 4, 0, 37, 20, 286, 1, 'noobiest', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 480, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 5, 0, 6, 6, 37, 1, 'creepXmaster', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 6, 0, 19, 32, 65, 1, 'BOSS|Roentgen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 7, 0, 14, 9, 102, 1, 'hac_k', 1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 5, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 8, 0, 44, 26, 332, 0, 'Millenius', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 9, 0, 1, 4, -6, 1, 'gbsdkejd', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 10, 0, 2, 2, 2, 1, 'HyPE|GDM', 3, 50, 0, 0, 0, 0, 0, 0, 0, 0, 9, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 11, 0, 37, 26, 258, 0, 'Ronin_Rabbit', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 12, 0, 10, 31, -34, 1, 'DB', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 13, 0, 10, 9, 66, 0, 'skP.Andriks', 3, 100, 0, 0, 0, 0, 0, 0, 0, 0, 10, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 14, 0, 24, 21, 131, 0, 'XXXTHAIXXX', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 15, 0, 35, 26, 232, 0, 'R2D2-BR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 16, 0, 1, 7, -28, 0, 'CamussLoko', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 17, 0, 19, 29, 70, 0, '^_^Azetox^_^', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(231, 19, 0, 4, 8, -2, 0, 'AMDAthlon64x2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(232, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(233, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(234, 0, 0, 2, 3, 14, 0, 'WSSSA', 0, 0, 0, 0, 0, 0, 4, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(234, 1, 1, 1, 0, 38, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(234, 4, 4, 5, 5, 150, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 60, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(235, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(236, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(237, 0, 0, -1, 1, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(238, 0, 12, 19, 15, 534, 1, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 132, 660, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(238, 1, 6, 16, 13, 405, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 109, 600, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(238, 2, 2, 5, 2, 146, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 89, 504, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(239, 0, 12, 19, 15, 525, 1, 'HyPE|JoeSmith', 0, 0, 5, 18, 0, 0, 0, 0, 140, 765, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(239, 1, 6, 16, 14, 401, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 114, 624, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(239, 2, 2, 5, 3, 142, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 89, 504, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(240, 0, 12, 19, 16, 521, 1, 'HyPE|JoeSmith', 0, 0, 5, 18, 0, 0, 0, 0, 142, 780, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(240, 1, 6, 17, 14, 415, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120, 672, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(240, 2, 2, 5, 3, 142, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 89, 504, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(241, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 0, 2, 12, 5, 252, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 191, 1224, 0, 0, 3, 59, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 1, 0, 17, 8, 64, 0, ':SkS:Skytaix', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 2560, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 2, 0, 7, 11, 111, 1, 'bold', 0, 0, 0, 0, 0, 0, 3, 120, 0, 0, 6, 240, 47, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 3, 0, 0, 4, -38, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 45, 165, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 4, 0, 8, 10, 130, 0, 'tomcat', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 129, 816, 0, 0, 4, 93, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 5, 0, 4, 13, -8, 1, 'MG', 0, 0, 0, 0, 0, 0, 12, 605, 0, 0, 1, 0, 0, 0, 0, 0, 2, 76, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 6, 1, 16, 5, 265, 1, 'snifblack98(ITA', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 173, 1320, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 7, 0, 0, 0, 0, 0, '[PSY]Kater', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 8, 0, 8, 8, 86, 0, 'Marioo', 0, 0, 5, 54, 0, 0, 0, 0, 0, 0, 0, 0, 111, 672, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 9, 0, 4, 9, 162, 0, 'PluQz', 0, 0, 0, 0, 0, 0, 7, 190, 52, 180, 0, 0, 0, 0, 0, 0, 0, 0, 4, 38);
INSERT INTO `ss_meta_players` VALUES(242, 10, 0, 7, 10, 34, 1, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 16, 690, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 11, 0, 3, 3, 17, 1, 'Fr5tK5vhjQLLLLL', 1, 0, 0, 0, 0, 0, 0, 0, 28, 210, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 12, 0, 4, 0, 40, 0, 'Pimentinha', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 13, 2, 13, 3, 179, 0, 'kn0ckt', 0, 0, 4, 36, 0, 0, 0, 0, 0, 0, 19, 800, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 14, 0, 7, 9, 72, 1, 'Sigshooter7', 0, 0, 0, 0, 0, 0, 4, 370, 0, 0, 0, 0, 106, 504, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(242, 15, 0, 2, 7, -6, 0, 'Last315', 0, 0, 0, 0, 0, 0, 6, 195, 0, 0, 10, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 0, 2, 13, 6, 258, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 240, 1488, 0, 0, 3, 59, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 1, 0, 18, 8, 110, 0, ':SkS:Skytaix', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 2640, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 2, 0, 8, 12, 125, 1, 'bold', 0, 0, 0, 0, 0, 0, 4, 225, 0, 0, 7, 240, 47, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 3, 0, 0, 6, -94, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 51, 225, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 4, 0, 8, 11, 126, 0, 'tomcat', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 130, 816, 0, 0, 4, 93, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 5, 0, 4, 13, -8, 1, 'MG', 0, 0, 0, 0, 0, 0, 12, 605, 0, 0, 1, 0, 0, 0, 0, 0, 2, 76, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 6, 0, 0, 0, 0, 1, 'GoChezz', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 7, 0, 0, 1, -4, 0, 'bope', 0, 0, 0, 0, 0, 0, 3, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 8, 0, 10, 8, 106, 0, 'Marioo', 0, 0, 5, 54, 0, 0, 0, 0, 0, 0, 0, 0, 139, 840, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 9, 0, 5, 9, 170, 0, 'PluQz', 0, 0, 0, 0, 0, 0, 9, 295, 52, 180, 0, 0, 0, 0, 0, 0, 0, 0, 4, 38);
INSERT INTO `ss_meta_players` VALUES(243, 10, 0, 7, 11, 76, 1, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 19, 770, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 11, 0, 3, 4, 13, 1, 'Fr5tK5vhjQLLLLL', 2, 0, 0, 0, 0, 0, 3, 55, 28, 210, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 12, 0, 7, 2, 61, 0, 'Pimentinha', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 880, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 13, 4, 15, 3, 258, 0, 'kn0ckt', 0, 0, 7, 36, 0, 0, 0, 0, 0, 0, 21, 1120, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 14, 0, 10, 9, 92, 1, 'Sigshooter7', 0, 0, 0, 0, 0, 0, 11, 610, 0, 0, 0, 0, 106, 504, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 15, 0, 3, 7, 4, 0, 'Last315', 0, 0, 0, 0, 0, 0, 6, 195, 0, 0, 15, 560, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(243, 16, 0, 0, 1, -4, 0, 'Rimbaud.A', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 0, 2, 25, 7, 463, 0, 'HyPE|GDM', 0, 0, 13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 391, 2232, 0, 0, 4, 59, 32, 266);
INSERT INTO `ss_meta_players` VALUES(244, 1, 0, 28, 16, 286, 0, ':SkS:Skytaix', 0, 0, 8, 36, 0, 0, 0, 0, 0, 0, 60, 4080, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 2, 0, 10, 18, 133, 1, 'bold', 0, 0, 0, 0, 0, 0, 12, 400, 34, 165, 9, 320, 47, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 3, 0, 1, 12, -132, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 1, 45, 115, 480, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 4, 0, 7, 6, 120, 0, 'Maaegtkztgwsgg', 5, 0, 0, 0, 0, 0, 16, 705, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 41, 323);
INSERT INTO `ss_meta_players` VALUES(244, 5, 2, 9, 22, 122, 1, 'MG', 0, 0, 0, 0, 0, 0, 12, 605, 0, 0, 1, 0, 81, 600, 0, 0, 2, 76, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 6, -1, 1, 8, -56, 1, 'GoChezz', 0, 0, 0, 0, 3, 120, 12, 340, 13, 45, 1, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 7, 1, 6, 12, 50, 0, 'bope', 0, 0, 0, 0, 0, 0, 26, 920, 0, 0, 0, 0, 0, 0, 0, 0, 10, 98, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 8, 0, 18, 11, 210, 0, 'Marioo', 0, 0, 62, 342, 0, 0, 0, 0, 0, 0, 0, 0, 264, 1704, 0, 0, 2, 6, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 9, 0, 4, 18, 104, 0, 'PluQz', 0, 0, 0, 0, 1, 0, 20, 445, 52, 180, 9, 240, 0, 0, 0, 0, 0, 0, 4, 38);
INSERT INTO `ss_meta_players` VALUES(244, 10, 1, 13, 20, 169, 1, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 38, 1610, 0, 0, 0, 0, 0, 0, 0, 0, 16, 227, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 11, 0, 7, 4, 92, 1, 'XxLordordxX', 0, 0, 0, 0, 4, 60, 8, 350, 115, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 12, 0, 14, 6, 86, 0, 'Pimentinha', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 30, 2240, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 13, 4, 22, 4, 290, 1, 'kn0ckt', 0, 0, 15, 36, 0, 0, 0, 0, 0, 0, 45, 2080, 0, 0, 0, 0, 20, 76, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 14, 0, 17, 18, 138, 1, 'Sigshooter7', 0, 0, 0, 0, 0, 0, 47, 1660, 0, 0, 0, 0, 106, 504, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 15, 0, 7, 14, 65, 0, 'Last315', 0, 0, 0, 0, 0, 0, 6, 195, 0, 0, 21, 640, 72, 480, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 16, 0, 0, 0, 0, 4, 'benettikiller', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 17, 0, 0, 1, -4, 1, 'Rufus', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 18, 0, 9, 4, 290, 0, 'gipsymaia', 0, 0, 8, 72, 0, 0, 0, 0, 136, 585, 0, 0, 29, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(244, 19, 0, 0, 0, 0, 0, 'awsa', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 0, 3, 29, 9, 590, 0, 'HyPE|GDM', 0, 0, 13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 487, 2760, 0, 0, 5, 59, 32, 266);
INSERT INTO `ss_meta_players` VALUES(245, 1, 0, 33, 18, 354, 0, ':SkS:Skytaix', 0, 0, 8, 36, 0, 0, 0, 0, 0, 0, 66, 4720, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 2, 1, 12, 19, 189, 1, 'bold', 0, 0, 0, 0, 0, 0, 12, 400, 127, 480, 9, 320, 47, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 3, -1, 0, 15, -212, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 2, 45, 115, 480, 0, 0, 23, 216, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 4, 0, 11, 8, 166, 0, 'Maaegtkztgwsgg', 8, 50, 0, 0, 0, 0, 26, 1045, 0, 0, 0, 0, 0, 0, 0, 0, 2, 127, 41, 323);
INSERT INTO `ss_meta_players` VALUES(245, 5, 2, 9, 27, 78, 1, 'MG', 0, 0, 0, 0, 0, 0, 12, 605, 0, 0, 1, 0, 122, 744, 0, 0, 2, 76, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 6, 0, 0, 0, 0, 4, 'Sofu66', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 7, 0, 7, 16, -26, 0, 'bope', 0, 0, 0, 0, 0, 0, 36, 1255, 0, 0, 0, 0, 0, 0, 0, 0, 12, 196, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 8, 0, 17, 13, 172, 1, 'Marioo', 0, 0, 63, 342, 0, 0, 0, 0, 0, 0, 0, 0, 328, 2016, 0, 0, 2, 6, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 9, 0, 6, 20, 116, 0, 'PluQz', 0, 0, 0, 0, 10, 240, 20, 445, 52, 180, 9, 240, 0, 0, 0, 0, 0, 0, 4, 38);
INSERT INTO `ss_meta_players` VALUES(245, 10, 1, 15, 22, 181, 1, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 43, 1705, 0, 0, 3, 160, 0, 0, 0, 0, 18, 234, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 11, 0, 9, 5, 111, 1, 'XxLordordxX', 0, 0, 0, 0, 4, 60, 8, 350, 117, 360, 10, 640, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 12, 0, 0, 0, 0, 4, 'Oracle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 13, 6, 26, 8, 309, 1, 'kn0ckt', 2, 0, 18, 36, 0, 0, 0, 0, 0, 0, 59, 2640, 0, 0, 0, 0, 22, 76, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 14, 0, 21, 20, 154, 1, 'Sigshooter7', 0, 0, 3, 18, 0, 0, 64, 2150, 0, 0, 0, 0, 106, 504, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 15, 0, 7, 15, 61, 0, 'Last315', 0, 0, 0, 0, 0, 0, 6, 195, 0, 0, 21, 640, 108, 696, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 16, 0, 2, 2, 18, 1, 'benettikiller', 0, 0, 0, 0, 0, 0, 6, 415, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 17, 0, 0, 4, -16, 1, 'Rufus', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 38, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(245, 18, 0, 14, 6, 338, 0, 'gipsymaia', 0, 0, 8, 72, 0, 0, 0, 0, 218, 990, 0, 0, 29, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 0, 4, 33, 10, 690, 0, 'HyPE|GDM', 0, 0, 13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 521, 3120, 0, 0, 5, 59, 32, 266);
INSERT INTO `ss_meta_players` VALUES(246, 1, 0, 35, 19, 370, 0, ':SkS:Skytaix', 0, 0, 8, 36, 0, 0, 0, 0, 0, 0, 70, 4960, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 2, 1, 13, 20, 195, 1, 'bold', 0, 0, 0, 0, 0, 0, 12, 400, 152, 630, 9, 320, 47, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 3, -1, -1, 16, -236, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 2, 45, 115, 480, 0, 0, 38, 360, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 4, 0, 12, 9, 162, 0, 'Maaegtkztgwsgg', 14, 50, 3, 36, 0, 0, 26, 1045, 0, 0, 0, 0, 0, 0, 0, 0, 2, 127, 41, 323);
INSERT INTO `ss_meta_players` VALUES(246, 5, 3, 10, 29, 142, 1, 'MG', 0, 0, 0, 0, 0, 0, 12, 605, 0, 0, 1, 0, 140, 888, 0, 0, 2, 76, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 6, 0, 0, 1, -28, 0, 'Sofu66', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 7, 0, 8, 17, -18, 0, 'bope', 0, 0, 0, 0, 0, 0, 38, 1360, 0, 0, 0, 0, 0, 0, 0, 0, 14, 196, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 8, 0, 17, 13, 164, 1, 'Marioo', 0, 0, 63, 342, 0, 0, 0, 0, 0, 0, 0, 0, 372, 2256, 0, 0, 2, 6, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 9, 0, 6, 21, 112, 0, 'PluQz', 0, 0, 0, 0, 11, 240, 20, 445, 52, 180, 9, 240, 0, 0, 0, 0, 0, 0, 39, 133);
INSERT INTO `ss_meta_players` VALUES(246, 10, 1, 16, 23, 188, 1, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 43, 1705, 0, 0, 7, 240, 0, 0, 0, 0, 18, 234, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 11, 0, 9, 7, 103, 1, 'XxLordordxX', 0, 0, 6, 54, 6, 60, 8, 350, 117, 360, 13, 720, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 12, 0, 0, 0, 0, 4, 'Oracle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 13, 6, 26, 9, 339, 1, 'kn0ckt', 2, 0, 20, 36, 0, 0, 0, 0, 0, 0, 62, 2640, 0, 0, 0, 0, 22, 76, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 14, 0, 23, 21, 171, 1, 'Sigshooter7', 0, 0, 3, 18, 0, 0, 69, 2345, 0, 0, 0, 0, 106, 504, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 15, 0, 7, 16, 57, 0, 'Last315', 0, 0, 0, 0, 12, 120, 6, 195, 0, 0, 21, 640, 108, 696, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 16, 0, 2, 3, 14, 1, 'benettikiller', 0, 0, 0, 0, 0, 0, 11, 425, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 17, 0, 2, 5, 36, 1, 'Rufus', 0, 0, 0, 0, 0, 0, 0, 0, 37, 135, 0, 0, 38, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 18, 0, 15, 7, 344, 0, 'gipsymaia', 0, 0, 8, 72, 0, 0, 0, 0, 232, 1050, 0, 0, 29, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(246, 19, 0, 0, 0, 0, 0, 'Dec0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 0, 4, 32, 13, 606, 0, 'HyPE|GDM', 0, 0, 13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 586, 3552, 0, 0, 5, 59, 32, 266);
INSERT INTO `ss_meta_players` VALUES(247, 1, 0, 42, 25, 414, 0, ':SkS:Skytaix', 0, 0, 8, 36, 0, 0, 8, 390, 0, 0, 78, 5520, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 2, 1, 15, 24, 175, 1, 'bold', 1, 0, 0, 0, 0, 0, 12, 400, 246, 750, 9, 320, 62, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 4, -1, 15, 13, 166, 0, 'Maaegtkztgwsgg', 35, 150, 11, 90, 0, 0, 41, 1495, 0, 0, 0, 0, 0, 0, 0, 0, 2, 127, 41, 323);
INSERT INTO `ss_meta_players` VALUES(247, 5, 3, 14, 37, 130, 1, 'MG', 0, 0, 0, 0, 0, 0, 18, 1070, 0, 0, 1, 0, 175, 1104, 0, 0, 2, 76, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 7, 1, 19, 23, 141, 0, 'bope', 0, 0, 0, 0, 0, 0, 63, 2500, 0, 0, 0, 0, 0, 0, 0, 0, 26, 604, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 8, 0, 21, 18, 259, 1, 'Marioo', 0, 0, 70, 360, 25, 540, 0, 0, 0, 0, 0, 0, 398, 2520, 0, 0, 2, 6, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 9, 0, 8, 24, 110, 0, 'PluQz', 0, 0, 7, 0, 11, 240, 20, 445, 52, 180, 22, 960, 0, 0, 0, 0, 0, 0, 53, 209);
INSERT INTO `ss_meta_players` VALUES(247, 10, 1, 22, 26, 249, 1, 'Ronin_Rabbit', 1, 50, 0, 0, 0, 0, 43, 1705, 0, 0, 26, 880, 0, 0, 0, 0, 18, 234, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 13, 6, 33, 13, 372, 1, 'kn0ckt', 5, 0, 20, 36, 0, 0, 0, 0, 0, 0, 84, 3600, 0, 0, 0, 0, 24, 153, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 14, 0, 29, 28, 231, 1, 'Sigshooter7', 0, 0, 3, 18, 0, 0, 93, 2860, 0, 0, 0, 0, 106, 504, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 15, 0, 9, 20, 61, 0, 'Last315', 0, 0, 0, 0, 16, 120, 8, 270, 36, 150, 23, 800, 108, 696, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 16, 0, 8, 8, 103, 1, 'benettikiller', 0, 0, 0, 0, 0, 0, 13, 510, 0, 0, 0, 0, 68, 552, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 17, 0, 4, 8, 24, 1, 'Rufus', 0, 0, 0, 0, 0, 0, 0, 0, 110, 330, 0, 0, 97, 504, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(247, 18, 0, 20, 13, 370, 0, 'gipsymaia', 0, 0, 8, 72, 0, 0, 0, 0, 356, 1650, 0, 0, 29, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(248, 0, 4, 32, 13, 606, 0, 'HyPE|GDM', 0, 0, 13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 586, 3552, 0, 0, 5, 59, 32, 266);
INSERT INTO `ss_meta_players` VALUES(248, 1, 0, 42, 25, 414, 0, ':SkS:Skytaix', 0, 0, 8, 36, 0, 0, 8, 390, 0, 0, 78, 5520, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(248, 2, 1, 15, 24, 175, 1, 'bold', 1, 0, 0, 0, 0, 0, 12, 400, 246, 750, 9, 320, 87, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(248, 4, -1, 16, 14, 154, 0, 'Maaegtkztgwsgg', 35, 150, 11, 90, 0, 0, 43, 1580, 0, 0, 0, 0, 0, 0, 0, 0, 2, 127, 41, 323);
INSERT INTO `ss_meta_players` VALUES(248, 5, 4, 14, 38, 184, 1, 'MG', 0, 0, 0, 0, 0, 0, 20, 1070, 0, 0, 1, 0, 175, 1104, 0, 0, 2, 76, 0, 0);
INSERT INTO `ss_meta_players` VALUES(248, 7, 1, 20, 24, 149, 0, 'bope', 0, 0, 0, 0, 0, 0, 65, 2605, 0, 0, 0, 0, 0, 0, 0, 0, 26, 604, 0, 0);
INSERT INTO `ss_meta_players` VALUES(248, 8, 0, 21, 18, 259, 1, 'Marioo', 0, 0, 70, 360, 26, 600, 0, 0, 0, 0, 0, 0, 398, 2520, 0, 0, 2, 6, 0, 0);
INSERT INTO `ss_meta_players` VALUES(248, 9, 0, 8, 25, 106, 0, 'PluQz', 0, 0, 7, 0, 11, 240, 20, 445, 52, 180, 24, 960, 0, 0, 0, 0, 0, 0, 53, 209);
INSERT INTO `ss_meta_players` VALUES(248, 10, 1, 22, 26, 249, 1, 'Ronin_Rabbit', 1, 50, 0, 0, 0, 0, 43, 1705, 0, 0, 27, 880, 0, 0, 0, 0, 18, 234, 0, 0);
INSERT INTO `ss_meta_players` VALUES(248, 13, 6, 35, 13, 372, 1, 'kn0ckt', 5, 0, 20, 36, 0, 0, 0, 0, 0, 0, 86, 3840, 0, 0, 0, 0, 26, 153, 0, 0);
INSERT INTO `ss_meta_players` VALUES(248, 14, 0, 32, 29, 293, 1, 'Sigshooter7', 0, 0, 3, 18, 0, 0, 99, 3030, 0, 0, 0, 0, 106, 504, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(248, 15, 0, 10, 21, 107, 0, 'Last315', 0, 0, 0, 0, 16, 120, 8, 270, 36, 150, 24, 880, 108, 696, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(248, 16, 0, 8, 9, 99, 1, 'benettikiller', 0, 0, 0, 0, 0, 0, 13, 510, 0, 0, 0, 0, 78, 576, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(248, 17, 0, 5, 8, 35, 1, 'Rufus', 0, 0, 0, 0, 0, 0, 0, 0, 110, 330, 0, 0, 102, 552, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(249, 0, 4, 32, 13, 606, 0, 'HyPE|GDM', 0, 0, 13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 586, 3552, 0, 0, 5, 59, 32, 266);
INSERT INTO `ss_meta_players` VALUES(249, 1, 0, 42, 25, 414, 0, ':SkS:Skytaix', 0, 0, 8, 36, 0, 0, 8, 390, 0, 0, 78, 5520, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(249, 2, 1, 15, 24, 175, 1, 'bold', 1, 0, 0, 0, 0, 0, 12, 400, 246, 750, 9, 320, 87, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(249, 4, -1, 16, 14, 154, 0, 'Maaegtkztgwsgg', 35, 150, 11, 90, 0, 0, 43, 1580, 0, 0, 0, 0, 0, 0, 0, 0, 2, 127, 41, 323);
INSERT INTO `ss_meta_players` VALUES(249, 5, 4, 14, 38, 184, 1, 'MG', 0, 0, 0, 0, 0, 0, 20, 1070, 0, 0, 1, 0, 175, 1104, 0, 0, 2, 76, 0, 0);
INSERT INTO `ss_meta_players` VALUES(249, 7, 1, 20, 24, 149, 0, 'bope', 0, 0, 0, 0, 0, 0, 65, 2605, 0, 0, 0, 0, 0, 0, 0, 0, 26, 604, 0, 0);
INSERT INTO `ss_meta_players` VALUES(249, 8, 0, 21, 18, 259, 1, 'Marioo', 0, 0, 70, 360, 26, 600, 0, 0, 0, 0, 0, 0, 398, 2520, 0, 0, 2, 6, 0, 0);
INSERT INTO `ss_meta_players` VALUES(249, 9, 0, 8, 25, 106, 0, 'PluQz', 0, 0, 7, 0, 11, 240, 20, 445, 52, 180, 24, 960, 0, 0, 0, 0, 0, 0, 53, 209);
INSERT INTO `ss_meta_players` VALUES(249, 10, 1, 22, 26, 249, 1, 'Ronin_Rabbit', 1, 50, 0, 0, 0, 0, 43, 1705, 0, 0, 28, 880, 0, 0, 0, 0, 18, 234, 0, 0);
INSERT INTO `ss_meta_players` VALUES(249, 13, 6, 35, 13, 393, 1, 'kn0ckt', 5, 0, 20, 36, 0, 0, 0, 0, 0, 0, 86, 3840, 0, 0, 0, 0, 26, 153, 0, 0);
INSERT INTO `ss_meta_players` VALUES(249, 14, 0, 32, 29, 293, 1, 'Sigshooter7', 0, 0, 3, 18, 0, 0, 99, 3030, 0, 0, 0, 0, 106, 504, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(249, 15, 0, 10, 21, 103, 0, 'Last315', 0, 0, 0, 0, 16, 120, 8, 270, 36, 150, 24, 880, 108, 696, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(249, 16, 0, 8, 9, 99, 1, 'benettikiller', 0, 0, 0, 0, 0, 0, 13, 510, 0, 0, 0, 0, 78, 576, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(249, 17, 0, 5, 8, 35, 1, 'Rufus', 0, 0, 0, 0, 0, 0, 0, 0, 110, 330, 0, 0, 102, 552, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(250, 0, 0, 3, 4, 57, 0, 'bypass', 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(250, 1, 0, 0, 1, -4, 1, 'atat2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(250, 2, 1, 8, 8, 130, 0, 'ultimaThule', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(250, 3, 0, 5, 14, 67, 1, 'lex', 0, 0, 0, 0, 0, 0, 1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(250, 4, 3, 21, 5, 470, 0, 'ElCre#M|A#', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(250, 5, 3, 9, 9, 300, 1, 'BrutuX', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(250, 6, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(251, 0, 1, 3, 5, 106, 0, 'bypass', 0, 0, 0, 0, 0, 0, 0, 0, 34, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(251, 1, 0, 0, 2, -8, 1, 'atat2', 0, 0, 0, 0, 0, 0, 2, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(251, 2, 1, 8, 8, 130, 0, 'ultimaThule', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 240, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(251, 3, 0, 5, 15, 63, 1, 'lex', 0, 0, 0, 0, 0, 0, 2, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(251, 4, 3, 23, 5, 509, 0, 'ElCre#M|A#', 0, 0, 0, 0, 0, 0, 0, 0, 28, 195, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(251, 5, 3, 10, 9, 317, 1, 'BrutuX', 0, 0, 0, 0, 0, 0, 0, 0, 16, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(251, 6, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(252, 0, 1, 3, 8, 123, 0, 'bypass', 0, 0, 0, 0, 0, 0, 0, 0, 67, 150, 0, 0, 0, 0, 0, 0, 4, 145, 0, 0);
INSERT INTO `ss_meta_players` VALUES(252, 1, 0, -1, 5, -40, 1, 'atat2', 0, 0, 0, 0, 0, 0, 2, 45, 56, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(252, 2, 2, 12, 9, 223, 0, 'ultimaThule', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 800, 0, 0, 0, 0, 4, 48, 0, 0);
INSERT INTO `ss_meta_players` VALUES(252, 3, 0, 7, 19, 93, 1, 'lex', 0, 0, 0, 0, 0, 0, 13, 275, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(252, 4, 3, 28, 5, 595, 0, 'ElCre#M|A#', 0, 0, 0, 0, 0, 0, 0, 0, 115, 570, 0, 0, 0, 0, 0, 0, 0, 0, 10, 114);
INSERT INTO `ss_meta_players` VALUES(252, 5, 3, 11, 12, 323, 1, 'BrutuX', 0, 0, 0, 0, 0, 0, 0, 0, 61, 240, 0, 0, 0, 0, 0, 0, 4, 16, 0, 0);
INSERT INTO `ss_meta_players` VALUES(252, 6, 0, 1, 3, 6, 1, 'HyPE|GDM', 0, 0, 8, 18, 0, 0, 0, 0, 0, 0, 0, 0, 56, 360, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(252, 7, 0, 4, 1, 66, 0, 'Oxmo', 1, 0, 7, 36, 0, 0, 0, 0, 0, 0, 0, 0, 58, 456, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(253, 0, 1, 3, 8, 123, 0, 'bypass', 0, 0, 0, 0, 0, 0, 0, 0, 67, 150, 0, 0, 0, 0, 0, 0, 5, 145, 0, 0);
INSERT INTO `ss_meta_players` VALUES(253, 1, 0, -1, 5, -40, 1, 'atat2', 0, 0, 0, 0, 0, 0, 2, 45, 56, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(253, 2, 2, 12, 9, 223, 0, 'ultimaThule', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 800, 0, 0, 0, 0, 4, 48, 0, 0);
INSERT INTO `ss_meta_players` VALUES(253, 3, 0, 7, 19, 93, 1, 'lex', 0, 0, 0, 0, 0, 0, 14, 295, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(253, 4, 3, 28, 5, 595, 0, 'ElCre#M|A#', 0, 0, 0, 0, 0, 0, 0, 0, 115, 570, 0, 0, 0, 0, 0, 0, 0, 0, 10, 114);
INSERT INTO `ss_meta_players` VALUES(253, 5, 3, 11, 12, 323, 1, 'BrutuX', 0, 0, 0, 0, 0, 0, 0, 0, 61, 240, 0, 0, 0, 0, 0, 0, 4, 16, 0, 0);
INSERT INTO `ss_meta_players` VALUES(253, 6, 0, 1, 3, 6, 1, 'HyPE|GDM', 0, 0, 8, 18, 0, 0, 0, 0, 0, 0, 0, 0, 56, 360, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(253, 7, 0, 4, 1, 66, 0, 'Oxmo', 1, 0, 7, 36, 0, 0, 0, 0, 0, 0, 0, 0, 58, 456, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 0, 0, 7, 4, 95, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 80, 330, 0, 0, 54, 336, 0, 0, 1, 110, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 1, 0, 1, 0, 22, 1, 'XXXTHAIXXX', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 168, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 2, 0, 5, 10, 15, 0, 'bold', 0, 0, 0, 0, 0, 0, 5, 85, 23, 105, 0, 0, 16, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 3, 0, 3, 6, 58, 0, 'FARIOUZ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 2, 66, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 4, 0, 0, 1, -4, 0, 'seyan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 5, 0, 2, 11, 2, 0, 'MG', 0, 0, 0, 0, 0, 0, 11, 340, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 6, 0, 2, 6, 20, 1, 'SuperM', 0, 0, 0, 0, 7, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 7, 0, 4, 4, 48, 1, 'SEMQQ__|__', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26, 168, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 8, 0, 4, 8, -17, 0, 'Marioo', 0, 0, 0, 0, 20, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 10, 2, 5, 4, 291, 0, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 6, 120, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 11, 0, 5, 7, 43, 1, 'EnryTheLion', 0, 0, 0, 0, 0, 0, 0, 0, 92, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 12, 0, 10, 6, 76, 1, 'L', 0, 0, 0, 0, 16, 420, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 13, 0, 5, 6, 62, 0, ':SkS:Skytaix', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 14, 0, 17, 6, 216, 1, 'Smeagol', 0, 0, 0, 0, 0, 0, 11, 710, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 15, 1, 10, 7, 243, 1, 'Kr0ss0v3r', 0, 0, 0, 0, 0, 0, 6, 200, 0, 0, 0, 0, 0, 0, 0, 0, 8, 139, 15, 114);
INSERT INTO `ss_meta_players` VALUES(254, 16, 0, 0, 0, 0, 4, 'e', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(254, 19, 0, 5, 7, 50, 1, 'Fuktardess', 0, 0, 0, 0, 16, 480, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 0, 0, 15, 7, 216, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 243, 1200, 0, 0, 54, 336, 0, 0, 3, 155, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 1, 0, 7, 5, 124, 1, 'XXXTHAIXXX', 0, 0, 0, 0, 0, 0, 18, 690, 0, 0, 7, 320, 33, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 2, 0, 11, 16, 89, 0, 'bold', 8, 0, 0, 0, 0, 0, 5, 85, 23, 105, 0, 0, 100, 576, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 3, 0, 4, 12, 50, 0, 'FARIOUZ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 107, 792, 0, 0, 4, 66, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 4, 0, 0, 4, -16, 0, 'seyan', 0, 0, 9, 36, 0, 0, 1, 10, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 5, 0, 6, 18, 68, 0, 'MG', 0, 0, 0, 0, 0, 0, 16, 475, 0, 0, 2, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 6, 0, 7, 11, 50, 1, 'SuperM', 0, 0, 0, 0, 27, 660, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 7, 0, 5, 7, 46, 1, 'SEMQQ__|__', 0, 0, 0, 0, 0, 0, 0, 0, 28, 135, 0, 0, 36, 216, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 8, 0, 7, 14, 18, 0, 'Marioo', 0, 0, 0, 0, 27, 840, 0, 0, 101, 435, 0, 0, 14, 216, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 10, 2, 8, 8, 345, 0, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 19, 560, 0, 0, 0, 0, 0, 0, 0, 0, 8, 86, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 11, 0, 12, 11, 121, 0, 'EnryTheLion', 0, 0, 0, 0, 0, 0, 0, 0, 210, 840, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 12, 0, 15, 10, 110, 1, 'L', 0, 0, 0, 0, 24, 600, 0, 0, 0, 0, 0, 0, 94, 888, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 13, 0, 1, 0, 12, 0, 'olivialefgt', 0, 0, 0, 0, 0, 0, 3, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 14, 1, 25, 7, 430, 1, 'Smeagol', 0, 0, 0, 0, 0, 0, 27, 1580, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 15, 2, 14, 11, 419, 1, 'Kr0ss0v3r', 0, 0, 0, 0, 0, 0, 17, 700, 0, 0, 0, 0, 0, 0, 0, 0, 14, 253, 15, 114);
INSERT INTO `ss_meta_players` VALUES(255, 16, 0, 0, 0, 0, 4, 'big_moe5', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 18, 0, 2, 1, 16, 1, 'majorgamemode', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 0, 0, 0, 0, 4, 93, 0, 0);
INSERT INTO `ss_meta_players` VALUES(255, 19, 0, 7, 11, 56, 1, 'Fuktardess', 0, 0, 0, 0, 30, 720, 4, 220, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 0, 0, 15, 7, 216, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 243, 1200, 0, 0, 54, 336, 0, 0, 3, 155, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 1, 0, 7, 5, 124, 1, 'XXXTHAIXXX', 0, 0, 0, 0, 0, 0, 18, 690, 0, 0, 7, 320, 33, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 2, 0, 12, 16, 124, 0, 'bold', 8, 0, 0, 0, 0, 0, 5, 85, 23, 105, 0, 0, 105, 600, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 3, 0, 4, 12, 46, 0, 'FARIOUZ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 107, 792, 0, 0, 4, 66, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 4, 0, 0, 4, -16, 0, 'seyan', 0, 0, 9, 36, 0, 0, 1, 10, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 5, 0, 6, 18, 68, 0, 'MG', 0, 0, 0, 0, 0, 0, 16, 475, 0, 0, 2, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 6, 0, 7, 11, 50, 1, 'SuperM', 0, 0, 0, 0, 27, 660, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 7, 0, 5, 7, 46, 1, 'SEMQQ__|__', 0, 0, 0, 0, 0, 0, 0, 0, 28, 135, 0, 0, 36, 216, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 8, 0, 7, 14, 18, 0, 'Marioo', 0, 0, 0, 0, 27, 840, 0, 0, 101, 435, 0, 0, 14, 216, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 10, 2, 8, 8, 345, 0, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 19, 560, 0, 0, 0, 0, 0, 0, 0, 0, 8, 86, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 11, 0, 12, 11, 121, 0, 'EnryTheLion', 0, 0, 0, 0, 0, 0, 0, 0, 210, 840, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 12, 0, 15, 10, 110, 1, 'L', 0, 0, 0, 0, 24, 600, 0, 0, 0, 0, 0, 0, 94, 888, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 13, 0, 1, 0, 12, 0, 'olivialefgt', 0, 0, 0, 0, 0, 0, 3, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 14, 1, 25, 8, 428, 1, 'Smeagol', 0, 0, 0, 0, 0, 0, 27, 1580, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 15, 2, 14, 11, 419, 1, 'Kr0ss0v3r', 0, 0, 0, 0, 0, 0, 17, 700, 0, 0, 0, 0, 0, 0, 0, 0, 14, 253, 15, 114);
INSERT INTO `ss_meta_players` VALUES(256, 16, 0, 0, 0, 0, 4, 'big_moe5', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 18, 0, 2, 1, 16, 1, 'majorgamemode', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 0, 0, 0, 0, 4, 93, 0, 0);
INSERT INTO `ss_meta_players` VALUES(256, 19, 0, 7, 11, 68, 1, 'Fuktardess', 0, 0, 0, 0, 30, 720, 4, 220, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 0, 0, 54, 20, 783, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 25, 1610, 39, 210, 0, 0, 350, 3048, 0, 0, 4, 36, 43, 285);
INSERT INTO `ss_meta_players` VALUES(257, 1, 0, 22, 28, 261, 1, 'XXXTHAIXXX', 0, 0, 0, 0, 5, 120, 42, 1055, 93, 480, 0, 0, 0, 0, 0, 0, 8, 194, 5, 38);
INSERT INTO `ss_meta_players` VALUES(257, 2, 0, 21, 35, 170, 0, 'bold', 0, 0, 0, 0, 0, 0, 38, 1115, 0, 0, 3, 80, 5, 72, 0, 0, 24, 77, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 3, 0, 12, 24, 116, 0, 'FARIOUZ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 152, 1008, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 4, 0, 0, 0, 0, 4, 'Oracle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 5, 0, 4, 7, 88, 1, 'random-dude', 0, 0, 0, 0, 6, 120, 2, 120, 39, 180, 1, 80, 17, 96, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 6, 0, 0, 3, -22, 0, 'minnesotaburns', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 560, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 7, 0, 9, 30, 14, 1, 'SEMQQ__|__', 0, 0, 0, 0, 4, 0, 19, 265, 0, 0, 0, 0, 42, 384, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 8, 1, 19, 31, 148, 0, 'Marioo', 0, 0, 12, 126, 0, 0, 3, 40, 0, 0, 32, 1200, 98, 840, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 9, 0, 15, 15, 91, 1, 'Pro.BrasiL#tnt', 0, 0, 19, 90, 0, 0, 0, 0, 0, 0, 39, 2000, 38, 192, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 10, 2, 22, 26, 543, 0, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 33, 1305, 0, 0, 0, 0, 0, 0, 0, 0, 26, 174, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 11, 1, 38, 29, 486, 0, 'EnryTheLion', 1, 0, 1, 18, 27, 960, 22, 720, 146, 735, 0, 0, 14, 48, 0, 0, 2, 152, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 12, 0, 7, 8, 82, 1, '(turko)eren)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 126, 936, 0, 0, 14, 273, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 13, 2, 42, 18, 778, 0, '~BiD#AyYaR', 0, 0, 0, 0, 0, 0, 67, 4010, 0, 0, 0, 0, 0, 0, 0, 0, 8, 219, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 14, 3, 60, 29, 1118, 1, 'Smeagol', 0, 0, 0, 0, 0, 0, 84, 3625, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 15, 3, 31, 33, 774, 1, 'Kr0ss0v3r', 0, 0, 0, 0, 0, 0, 29, 1145, 0, 0, 0, 0, 82, 432, 0, 0, 16, 399, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 16, 0, 1, 8, -22, 1, 'big_moe5', 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 2, 0, 9, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 17, 0, 4, 2, 28, 1, 'ultimaThule', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 800, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 18, 0, 9, 5, 98, 0, '|REDS|Ferret*', 0, 0, 14, 18, 47, 1260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 333, 0, 0);
INSERT INTO `ss_meta_players` VALUES(257, 19, 0, 21, 38, 244, 1, 'Fuktardess', 0, 0, 0, 0, 0, 0, 46, 1835, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 0, 0, 65, 23, 928, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 35, 1965, 39, 210, 0, 0, 473, 3960, 0, 0, 6, 36, 43, 285);
INSERT INTO `ss_meta_players` VALUES(258, 1, 0, 27, 38, 289, 1, 'XXXTHAIXXX', 0, 0, 0, 0, 12, 240, 48, 1300, 93, 480, 0, 0, 83, 384, 0, 0, 8, 194, 5, 38);
INSERT INTO `ss_meta_players` VALUES(258, 2, 0, 25, 42, 212, 0, 'bold', 0, 0, 0, 0, 0, 0, 38, 1115, 0, 0, 13, 320, 58, 336, 0, 0, 24, 77, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 3, 0, 13, 28, 136, 0, 'FARIOUZ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 226, 1512, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 4, 0, 0, 0, 0, 4, 'Oracle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 5, 0, 1, 0, 14, 0, 'thrift-shop', 0, 0, 0, 0, 0, 0, 0, 0, 36, 150, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 6, 0, 0, 9, -46, 0, 'minnesotaburns', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 720, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 7, 0, 9, 38, -27, 1, 'SEMQQ__|__', 0, 0, 0, 0, 4, 0, 24, 440, 66, 180, 0, 0, 42, 384, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 8, 1, 27, 36, 210, 0, 'Marioo', 0, 0, 12, 126, 36, 1140, 3, 40, 0, 0, 39, 1520, 98, 840, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 9, 0, 18, 25, 84, 1, 'Pro.BrasiL#tnt', 0, 0, 19, 90, 0, 0, 4, 50, 21, 30, 46, 2240, 46, 264, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 10, 2, 28, 33, 656, 0, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 45, 1890, 0, 0, 0, 0, 0, 0, 0, 0, 32, 362, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 11, 1, 48, 36, 592, 0, 'EnryTheLion', 1, 0, 1, 18, 27, 960, 22, 720, 146, 735, 0, 0, 152, 1416, 0, 0, 2, 152, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 12, 0, 16, 14, 161, 1, '(turko)eren)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 229, 1608, 0, 0, 24, 422, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 13, 3, 56, 23, 1116, 0, '~BiD#AyYaR', 0, 0, 0, 0, 0, 0, 88, 5255, 0, 0, 0, 0, 0, 0, 0, 0, 12, 620, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 14, 3, 73, 37, 1291, 1, 'Smeagol', 0, 0, 0, 0, 0, 0, 130, 5220, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 15, 0, 0, 0, 0, 1, 'Lattenzaun', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 16, 0, -1, 0, -20, 1, 'V4L', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 17, 0, 10, 7, 70, 1, 'ultimaThule', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 33, 1600, 0, 0, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 18, 0, 13, 8, 126, 0, '|REDS|Ferret*', 0, 0, 14, 18, 69, 1980, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26, 373, 0, 0);
INSERT INTO `ss_meta_players` VALUES(258, 19, 0, 24, 44, 279, 1, 'Fuktardess', 0, 0, 0, 0, 0, 0, 63, 2600, 0, 0, 0, 0, 0, 0, 0, 0, 6, 7, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 0, 0, 65, 23, 928, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 35, 1965, 39, 210, 0, 0, 473, 3960, 0, 0, 6, 36, 43, 285);
INSERT INTO `ss_meta_players` VALUES(259, 1, 0, 27, 38, 289, 1, 'XXXTHAIXXX', 0, 0, 0, 0, 12, 240, 48, 1300, 93, 480, 0, 0, 83, 384, 0, 0, 8, 194, 5, 38);
INSERT INTO `ss_meta_players` VALUES(259, 2, 0, 25, 42, 212, 0, 'bold', 0, 0, 0, 0, 0, 0, 38, 1115, 0, 0, 13, 320, 58, 336, 0, 0, 24, 77, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 3, 0, 13, 28, 136, 0, 'FARIOUZ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 226, 1512, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 4, 0, 0, 0, 0, 4, 'Oracle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 5, 0, 1, 0, 14, 0, 'thrift-shop', 0, 0, 0, 0, 0, 0, 0, 0, 36, 150, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 6, 0, 0, 9, -46, 0, 'minnesotaburns', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 720, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 7, 0, 9, 38, -27, 1, 'SEMQQ__|__', 0, 0, 0, 0, 4, 0, 24, 440, 66, 180, 0, 0, 42, 384, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 8, 1, 27, 36, 210, 0, 'Marioo', 0, 0, 12, 126, 36, 1140, 3, 40, 0, 0, 39, 1520, 98, 840, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 9, 0, 18, 25, 84, 1, 'Pro.BrasiL#tnt', 0, 0, 19, 90, 0, 0, 4, 50, 21, 30, 46, 2240, 46, 264, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 10, 2, 28, 33, 656, 0, 'Ronin_Rabbit', 0, 0, 0, 0, 0, 0, 45, 1890, 0, 0, 0, 0, 0, 0, 0, 0, 32, 362, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 11, 1, 48, 36, 592, 0, 'EnryTheLion', 1, 0, 1, 18, 27, 960, 22, 720, 146, 735, 0, 0, 152, 1416, 0, 0, 2, 152, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 12, 0, 16, 14, 161, 1, '(turko)eren)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 229, 1608, 0, 0, 24, 422, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 13, 3, 56, 23, 1116, 0, '~BiD#AyYaR', 0, 0, 0, 0, 0, 0, 88, 5255, 0, 0, 0, 0, 0, 0, 0, 0, 12, 620, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 14, 3, 73, 37, 1291, 1, 'Smeagol', 0, 0, 0, 0, 0, 0, 130, 5220, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 15, 0, 0, 0, 0, 1, 'Lattenzaun', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 16, 0, -1, 0, -20, 1, 'V4L', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 17, 0, 10, 7, 70, 1, 'ultimaThule', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 33, 1600, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 18, 0, 13, 8, 126, 0, '|REDS|Ferret*', 0, 0, 14, 18, 69, 1980, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26, 373, 0, 0);
INSERT INTO `ss_meta_players` VALUES(259, 19, 0, 24, 44, 279, 1, 'Fuktardess', 0, 0, 0, 0, 0, 0, 63, 2600, 0, 0, 0, 0, 0, 0, 0, 0, 6, 7, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 0, 1, 7, 3, 165, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 97, 936, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 1, 0, 6, 2, 66, 1, 'XXXTHAIXXX', 0, 0, 0, 0, 0, 0, 19, 660, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 30, 76);
INSERT INTO `ss_meta_players` VALUES(260, 2, 0, 1, 2, 7, 0, 'bold', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 312, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 3, 0, 2, 2, 12, 0, 'FARIOUZ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 36, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 4, 0, 0, 0, 0, 4, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 5, 0, 1, 2, 2, 0, 'thrift-shop', 0, 0, 0, 0, 0, 0, 0, 0, 107, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 6, 0, 2, 1, 16, 0, 'gipsymaia', 0, 0, 0, 0, 0, 0, 0, 0, 20, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 7, 0, -1, 2, -38, 1, 'minnesotaburns', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 8, 0, 3, 2, 24, 0, 'Marioo', 0, 0, 0, 0, 20, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 46, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 9, 0, 2, 3, 8, 1, 'Pro.BrasiL#tnt', 0, 0, 0, 0, 0, 0, 4, 35, 0, 0, 5, 160, 0, 0, 0, 0, 2, 57, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 10, 0, 0, 2, -8, 0, 'korsak', 0, 0, 0, 0, 0, 0, 3, 20, 37, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 11, 0, 0, 0, 0, 1, 'MorreDiabo!', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 12, 0, 6, 4, 68, 1, '(turko)eren)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 84, 720, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 13, 0, 6, 6, 76, 0, '~BiD#AyYaR', 0, 0, 0, 0, 0, 0, 13, 705, 0, 0, 0, 0, 0, 0, 0, 0, 2, 33, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 15, 0, 2, 4, 4, 1, 'Lattenzaun', 0, 0, 0, 0, 0, 0, 8, 230, 0, 0, 0, 0, 20, 120, 0, 0, 2, 10, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 16, 0, 1, 2, 26, 1, 'V4L', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 80, 29, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 17, 0, 2, 3, 30, 1, 'ultimaThule', 1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 4, 320, 0, 0, 0, 0, 2, 103, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 18, 0, 2, 3, 8, 0, 'craps', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 320, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(260, 19, 0, 3, 5, 10, 1, 'Fuktardess', 0, 0, 0, 0, 3, 120, 1, 90, 0, 0, 0, 0, 31, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 0, 1, 7, 3, 165, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 97, 936, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 1, 0, 6, 2, 66, 1, 'XXXTHAIXXX', 0, 0, 0, 0, 0, 0, 20, 735, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 30, 76);
INSERT INTO `ss_meta_players` VALUES(261, 2, 0, 1, 2, 7, 0, 'bold', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 312, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 3, 0, 2, 2, 12, 0, 'FARIOUZ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 36, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 4, 0, 0, 0, 0, 4, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 5, 0, 1, 2, 2, 0, 'thrift-shop', 0, 0, 0, 0, 0, 0, 0, 0, 107, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 6, 0, 2, 1, 16, 0, 'gipsymaia', 0, 0, 0, 0, 0, 0, 0, 0, 20, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 7, 0, -1, 2, -38, 1, 'minnesotaburns', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 8, 0, 3, 2, 24, 0, 'Marioo', 0, 0, 0, 0, 21, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 46, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 9, 0, 2, 3, 8, 1, 'Pro.BrasiL#tnt', 0, 0, 0, 0, 0, 0, 4, 35, 0, 0, 5, 160, 0, 0, 0, 0, 2, 57, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 10, 0, 0, 2, -8, 0, 'korsak', 0, 0, 0, 0, 0, 0, 3, 20, 37, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 11, 0, 0, 1, -4, 1, 'MorreDiabo!', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 12, 0, 6, 4, 68, 1, '(turko)eren)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 84, 720, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 13, 0, 7, 6, 86, 0, '~BiD#AyYaR', 0, 0, 0, 0, 0, 0, 13, 705, 0, 0, 0, 0, 0, 0, 0, 0, 2, 33, 7, 38);
INSERT INTO `ss_meta_players` VALUES(261, 15, 0, 2, 4, 4, 1, 'Lattenzaun', 0, 0, 0, 0, 0, 0, 8, 230, 0, 0, 0, 0, 20, 120, 0, 0, 2, 10, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 16, 0, 1, 2, 26, 1, 'V4L', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 80, 29, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 17, 0, 2, 3, 30, 1, 'ultimaThule', 1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 5, 400, 0, 0, 0, 0, 2, 103, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 18, 0, 2, 3, 8, 0, 'craps', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 400, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(261, 19, 0, 3, 5, 10, 1, 'Fuktardess', 0, 0, 0, 0, 3, 120, 1, 90, 0, 0, 0, 0, 31, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 0, 1, 7, 3, 165, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 97, 936, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 1, 0, 6, 3, 66, 1, 'XXXTHAIXXX', 0, 0, 0, 0, 0, 0, 20, 735, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 30, 76);
INSERT INTO `ss_meta_players` VALUES(262, 2, 0, 1, 2, 7, 0, 'bold', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 312, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 3, 0, 2, 2, 12, 0, 'FARIOUZ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 36, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 4, 0, 0, 0, 0, 4, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 5, 0, 1, 2, 2, 0, 'thrift-shop', 0, 0, 0, 0, 0, 0, 0, 0, 107, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 6, 0, 2, 1, 16, 0, 'gipsymaia', 0, 0, 0, 0, 0, 0, 0, 0, 20, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 7, 0, -1, 2, -38, 1, 'minnesotaburns', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 8, 0, 3, 2, 24, 0, 'Marioo', 0, 0, 0, 0, 21, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 46, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 9, 0, 2, 3, 8, 1, 'Pro.BrasiL#tnt', 0, 0, 0, 0, 0, 0, 4, 35, 0, 0, 5, 160, 0, 0, 0, 0, 2, 57, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 10, 0, 0, 2, -8, 0, 'korsak', 0, 0, 0, 0, 0, 0, 3, 20, 37, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 11, 0, 0, 1, -4, 1, 'MorreDiabo!', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 12, 0, 6, 4, 68, 1, '(turko)eren)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 84, 720, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 13, 0, 7, 6, 86, 0, '~BiD#AyYaR', 0, 0, 0, 0, 0, 0, 13, 705, 0, 0, 0, 0, 0, 0, 0, 0, 2, 33, 7, 38);
INSERT INTO `ss_meta_players` VALUES(262, 15, 0, 1, 4, 4, 1, 'Lattenzaun', 0, 0, 0, 0, 0, 0, 9, 330, 0, 0, 0, 0, 20, 120, 0, 0, 2, 10, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 16, 0, 1, 2, 26, 1, 'V4L', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 80, 29, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 17, 0, 2, 3, 30, 1, 'ultimaThule', 1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 5, 400, 0, 0, 0, 0, 2, 103, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 18, 0, 2, 3, 8, 0, 'craps', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 400, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(262, 19, 0, 3, 5, 10, 1, 'Fuktardess', 0, 0, 0, 0, 3, 120, 1, 90, 0, 0, 0, 0, 31, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(263, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(264, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 0, 0, 3, 13, 4, 1, 'paula`', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 1, 0, 5, 22, -21, 0, 'tamina', 0, 0, 0, 0, 0, 0, 0, 0, 26, 60, 0, 0, 0, 0, 0, 0, 2, 133, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 2, 0, 0, 13, -40, 0, 'BloodWork', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 72, 0, 0, 4, 133, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 3, 0, 3, 4, 14, 0, 'Efghi', 0, 0, 0, 0, 0, 0, 0, 0, 122, 435, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 4, 2, 22, 22, 437, 1, 'Harumune', 0, 0, 0, 0, 12, 420, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 5, 2, 20, 19, 556, 1, 'ya', 0, 0, 0, 0, 0, 0, 6, 235, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 6, 0, 2, 8, 14, 1, 'KILLME', 0, 0, 0, 0, 0, 0, 7, 170, 10, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 7, 0, -5, 12, -188, 0, 'Fruitcracker', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 1200, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 8, 2, 50, 22, 838, 1, 'Anderson', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 156, 1176, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 9, 3, 19, 13, 639, 0, 'uniJ00$', 0, 0, 0, 0, 0, 0, 12, 470, 0, 0, 0, 0, 0, 0, 0, 0, 8, 199, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 10, 0, 2, 25, -102, 0, 'Turk1shcurse', 1, 0, 1, 0, 0, 0, 0, 0, 109, 480, 0, 0, 0, 0, 0, 0, 8, 117, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 11, 0, 18, 17, 159, 1, 'tt5tt', 0, 0, 0, 0, 0, 0, 9, 370, 0, 0, 0, 0, 0, 0, 0, 0, 8, 155, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 12, 0, 8, 1, 92, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 744, 0, 0, 3, 128, 44, 209);
INSERT INTO `ss_meta_players` VALUES(265, 13, 0, -4, 12, -128, 1, 'SeaCowboy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 14, 0, 0, 1, -4, 1, 'oxoline', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(265, 15, 0, 1, 1, 6, 0, 'h00ver', 0, 0, 0, 0, 0, 0, 0, 0, 22, 105, 0, 0, 0, 0, 0, 0, 6, 116, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 0, 0, 3, 13, 4, 1, 'paula`', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 1, 0, 5, 22, -21, 0, 'tamina', 0, 0, 0, 0, 0, 0, 0, 0, 26, 60, 0, 0, 0, 0, 0, 0, 2, 133, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 2, 0, 0, 13, -40, 0, 'BloodWork', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 72, 0, 0, 4, 133, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 3, 0, 3, 4, 14, 0, 'Efghi', 0, 0, 0, 0, 0, 0, 0, 0, 122, 435, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 4, 2, 22, 22, 437, 1, 'Harumune', 0, 0, 0, 0, 12, 420, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 5, 2, 20, 19, 556, 1, 'ya', 0, 0, 0, 0, 0, 0, 6, 235, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 6, 0, 2, 8, 14, 1, 'KILLME', 0, 0, 0, 0, 0, 0, 7, 170, 10, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 7, 0, -5, 12, -188, 0, 'Fruitcracker', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 1200, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 8, 2, 50, 22, 838, 1, 'Anderson', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 156, 1176, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 9, 3, 19, 13, 639, 0, 'uniJ00$', 0, 0, 0, 0, 0, 0, 12, 470, 0, 0, 0, 0, 0, 0, 0, 0, 8, 199, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 10, 0, 2, 25, -102, 0, 'Turk1shcurse', 1, 0, 1, 0, 0, 0, 0, 0, 109, 480, 0, 0, 0, 0, 0, 0, 8, 117, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 11, 0, 18, 17, 159, 1, 'tt5tt', 0, 0, 0, 0, 0, 0, 9, 370, 0, 0, 0, 0, 0, 0, 0, 0, 8, 155, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 12, 0, 8, 1, 92, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 744, 0, 0, 3, 128, 44, 209);
INSERT INTO `ss_meta_players` VALUES(266, 13, 0, -4, 12, -128, 1, 'SeaCowboy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 14, 0, 0, 1, -4, 1, 'oxoline', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(266, 15, 0, 1, 1, 6, 0, 'h00ver', 0, 0, 0, 0, 0, 0, 0, 0, 22, 105, 0, 0, 0, 0, 0, 0, 6, 116, 0, 0);
INSERT INTO `ss_meta_players` VALUES(267, 1, 1, 5, 1, 154, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 93, 552, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(267, 2, 1, 7, 4, 141, 1, 'tick', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 480, 0, 0, 2, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(267, 3, 1, 9, 5, 199, 0, '|Br$|DiegoP9', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 240, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(267, 4, 0, 0, 1, -4, 0, 'Buggerby', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(267, 6, 1, 3, 0, 133, 1, 'LuaRs[AdmiN]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 288, 0, 0, 2, 87, 0, 0);
INSERT INTO `ss_meta_players` VALUES(267, 7, 0, 1, 3, -12, 1, 'Sgt.GTFO', 0, 0, 0, 0, 0, 0, 6, 210, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(267, 8, 0, 2, 7, 19, 1, 'Infernosnip3r', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(267, 9, 0, 1, 3, 6, 0, 'Abner', 0, 0, 0, 0, 0, 0, 0, 0, 99, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(268, 0, 0, 0, 1, -4, 0, 'Steven_Seagal', 0, 0, 0, 0, 0, 0, 0, 0, 22, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(268, 1, 2, 11, 4, 292, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 203, 1200, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(268, 2, 1, 12, 8, 196, 1, 'tick', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 176, 1200, 0, 0, 4, 102, 27, 76);
INSERT INTO `ss_meta_players` VALUES(268, 3, 1, 15, 12, 284, 0, '|Br$|DiegoP9', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 101, 960, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(268, 6, 1, 9, 4, 194, 1, 'LuaRs[AdmiN]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 98, 792, 0, 0, 2, 87, 0, 0);
INSERT INTO `ss_meta_players` VALUES(268, 8, 0, 3, 9, 45, 1, 'Infernosnip3r', 0, 0, 0, 0, 0, 0, 0, 0, 41, 120, 1, 0, 35, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(268, 9, 0, 1, 5, -2, 0, 'Abner', 0, 0, 0, 0, 0, 0, 1, 0, 99, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(269, 0, 1, 3, 5, 86, 0, 'Steven_Seagal', 0, 0, 0, 0, 0, 0, 0, 0, 112, 435, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(269, 1, 2, 21, 8, 471, 0, 'HyPE|GDM', 0, 0, 4, 18, 0, 0, 0, 0, 0, 0, 0, 0, 368, 2376, 0, 0, 2, 0, 5, 0);
INSERT INTO `ss_meta_players` VALUES(269, 2, 0, 4, 1, 53, 1, 'Lon3r', 0, 0, 2, 18, 0, 0, 0, 0, 0, 0, 4, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(269, 3, 1, 18, 17, 315, 0, '|Br$|DiegoP9', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 184, 1344, 0, 0, 12, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(269, 4, 0, 0, 5, -29, 1, 'FreestyleMyth', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 14, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(269, 5, 0, 1, 2, -8, 1, 'V3RUC', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 240, 0, 0, 4, 46, 7, 0);
INSERT INTO `ss_meta_players` VALUES(269, 6, 1, 13, 7, 254, 1, 'LuaRs[AdmiN]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 154, 1272, 0, 0, 2, 87, 0, 0);
INSERT INTO `ss_meta_players` VALUES(269, 7, 0, 2, 2, 12, 0, 'Jihard', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 38, 288, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(269, 8, 0, 6, 14, 107, 1, 'Infernosnip3r', 0, 0, 0, 0, 1, 0, 7, 160, 41, 120, 12, 400, 35, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(269, 9, 0, 2, 6, 4, 0, 'Abner', 0, 0, 0, 0, 0, 0, 5, 125, 99, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(269, 10, 0, 0, 0, 0, 0, 'nordin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(270, 0, 4, 8, 12, 390, 0, 'Steven_Seagal', 0, 0, 0, 0, 0, 0, 0, 0, 485, 1530, 0, 0, 0, 0, 0, 0, 10, 123, 0, 0);
INSERT INTO `ss_meta_players` VALUES(270, 1, 2, 34, 19, 673, 1, 'HyPE|GDM', 0, 0, 17, 126, 0, 0, 0, 0, 77, 285, 8, 160, 518, 3408, 0, 0, 8, 76, 24, 114);
INSERT INTO `ss_meta_players` VALUES(270, 2, 0, 21, 4, 329, 1, 'Lon3r', 0, 0, 53, 306, 0, 0, 0, 0, 0, 0, 44, 1920, 0, 0, 0, 0, 14, 328, 0, 0);
INSERT INTO `ss_meta_players` VALUES(270, 3, 3, 20, 19, 481, 0, '|Br$|DiegoP9', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 42, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(270, 4, 0, 1, 2, -8, 1, 'SarahConnor-Cat', 0, 0, 0, 0, 0, 0, 2, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(270, 7, 0, 4, 10, 70, 0, 'Jihard', 1, 0, 8, 18, 0, 0, 0, 0, 0, 0, 0, 0, 122, 912, 0, 0, 12, 31, 9, 57);
INSERT INTO `ss_meta_players` VALUES(270, 8, 0, 15, 23, 227, 1, 'Infernosnip3r', 0, 0, 0, 0, 10, 120, 7, 160, 120, 495, 26, 1280, 35, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(270, 11, 0, 9, 6, 80, 0, 'es', 1, 0, 16, 162, 0, 0, 0, 0, 0, 0, 19, 1120, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(271, 0, 4, 18, 20, 519, 0, 'Steven_Seagal', 0, 0, 0, 0, 0, 0, 0, 0, 806, 2820, 0, 0, 0, 0, 0, 0, 16, 123, 0, 0);
INSERT INTO `ss_meta_players` VALUES(271, 1, 2, 51, 26, 1061, 1, 'HyPE|GDM', 0, 0, 30, 180, 0, 0, 0, 0, 77, 285, 8, 160, 771, 5088, 0, 0, 10, 137, 80, 437);
INSERT INTO `ss_meta_players` VALUES(271, 2, 0, 29, 9, 435, 1, 'Lon3r', 5, 50, 29, 126, 0, 0, 0, 0, 0, 0, 17, 560, 0, 0, 0, 0, 0, 0, 67, 437);
INSERT INTO `ss_meta_players` VALUES(271, 3, 5, 26, 27, 774, 0, '|Br$|DiegoP9', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 180, 936, 0, 0, 10, 217, 0, 0);
INSERT INTO `ss_meta_players` VALUES(271, 4, 0, 8, 14, 71, 1, 'SarahConnor-Cat', 0, 0, 0, 0, 0, 0, 46, 1260, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(271, 5, 1, 18, 13, 322, 0, 'LuaRs[AdmiN]', 0, 0, 0, 0, 0, 0, 0, 0, 169, 705, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(271, 6, 0, 0, 0, 0, 4, 'P_rmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(271, 7, 0, 8, 17, 100, 0, 'Jihard', 1, 0, 8, 18, 2, 60, 0, 0, 0, 0, 0, 0, 215, 1416, 0, 0, 14, 31, 9, 57);
INSERT INTO `ss_meta_players` VALUES(271, 8, 0, 19, 33, 230, 1, 'Infernosnip3r', 1, 0, 9, 36, 18, 240, 7, 160, 209, 885, 26, 1280, 35, 144, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(271, 10, 0, 0, 1, -4, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 24, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(271, 11, 2, 22, 16, 359, 0, 'es', 9, 200, 20, 180, 0, 0, 0, 0, 0, 0, 49, 2080, 0, 0, 0, 0, 22, 383, 0, 0);
INSERT INTO `ss_meta_players` VALUES(272, 0, 4, 18, 20, 519, 0, 'Steven_Seagal', 0, 0, 0, 0, 0, 0, 0, 0, 806, 2820, 0, 0, 0, 0, 0, 0, 16, 123, 0, 0);
INSERT INTO `ss_meta_players` VALUES(272, 1, 2, 51, 26, 1061, 1, 'HyPE|GDM', 0, 0, 30, 180, 0, 0, 0, 0, 77, 285, 8, 160, 771, 5088, 0, 0, 10, 137, 80, 437);
INSERT INTO `ss_meta_players` VALUES(272, 2, 0, 29, 9, 435, 1, 'Lon3r', 5, 50, 29, 126, 0, 0, 0, 0, 0, 0, 17, 560, 0, 0, 0, 0, 0, 0, 67, 437);
INSERT INTO `ss_meta_players` VALUES(272, 3, 5, 26, 27, 774, 0, '|Br$|DiegoP9', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 180, 936, 0, 0, 10, 217, 0, 0);
INSERT INTO `ss_meta_players` VALUES(272, 4, 0, 8, 14, 71, 1, 'SarahConnor-Cat', 0, 0, 0, 0, 0, 0, 46, 1260, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(272, 5, 1, 18, 13, 322, 0, 'LuaRs[AdmiN]', 0, 0, 0, 0, 0, 0, 0, 0, 169, 705, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(272, 6, 0, 0, 0, 0, 4, 'P_rmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(272, 7, 0, 8, 17, 100, 0, 'Jihard', 1, 0, 8, 18, 2, 60, 0, 0, 0, 0, 0, 0, 215, 1416, 0, 0, 14, 31, 9, 57);
INSERT INTO `ss_meta_players` VALUES(272, 8, 0, 19, 33, 230, 1, 'Infernosnip3r', 1, 0, 9, 36, 18, 240, 7, 160, 209, 885, 26, 1280, 35, 144, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(272, 10, 0, 0, 1, -4, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 24, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(272, 11, 2, 22, 16, 359, 0, 'es', 9, 200, 20, 180, 0, 0, 0, 0, 0, 0, 49, 2080, 0, 0, 0, 0, 22, 383, 0, 0);
INSERT INTO `ss_meta_players` VALUES(273, 0, 1, 1, 1, 121, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(273, 1, 2, 40, 17, 800, 0, '|40+|Aworm', 0, 0, 0, 0, 0, 0, 0, 0, 68, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(273, 2, 1, 37, 22, 635, 0, 'FrT|Montana', 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 40, 264, 0, 0, 2, 54, 0, 0);
INSERT INTO `ss_meta_players` VALUES(273, 3, 2, 35, 18, 763, 1, '[PSY]Hermiona', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 37, 312, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(273, 4, 0, 12, 25, 107, 0, 'mahicol', 0, 0, 0, 0, 0, 0, 7, 265, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 19);
INSERT INTO `ss_meta_players` VALUES(273, 6, 0, 9, 25, 87, 0, '[PSY]Kater', 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 5, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(273, 8, 0, 11, 16, 202, 1, 'bruder', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 408, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(273, 12, 0, 14, 12, 355, 1, 'JackTheRipper', 0, 0, 0, 0, 0, 0, 7, 375, 0, 0, 0, 0, 0, 0, 0, 0, 2, 83, 0, 0);
INSERT INTO `ss_meta_players` VALUES(273, 13, 0, 4, 6, 28, 1, 'CamouflageRXT', 0, 0, 0, 0, 0, 0, 0, 0, 44, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(274, 0, 0, 1, 2, 2, 0, '=SA=Furios', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 14, 72, 0, 0);
INSERT INTO `ss_meta_players` VALUES(274, 1, 0, 0, 3, -12, 1, 'Pi_WildSnorlax', 8, 250, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 34, 0, 0, 0, 8, 60, 0, 0);
INSERT INTO `ss_meta_players` VALUES(274, 2, 0, 1, 3, 3, 0, '{BoB}Legend', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(274, 3, 0, 3, 1, 26, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 34, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(275, 0, 0, 1, 2, 2, 0, '=SA=Furios', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 14, 72, 0, 0);
INSERT INTO `ss_meta_players` VALUES(275, 1, 0, 0, 3, -12, 1, 'Pi_WildSnorlax', 8, 250, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 34, 0, 0, 0, 8, 60, 0, 0);
INSERT INTO `ss_meta_players` VALUES(275, 2, 0, 1, 3, 3, 0, '{BoB}Legend', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(275, 3, 0, 3, 1, 26, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 34, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(276, 0, 0, 0, 1, -4, 0, '=SA=Furios', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(276, 1, 0, 0, 1, -4, 0, 'Pi_WildSnorlax', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(276, 2, 0, 1, 0, 10, 1, '{BoB}Legend', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 277, 0, 0);
INSERT INTO `ss_meta_players` VALUES(276, 3, 0, 1, 0, 14, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(277, 0, 0, 0, 2, -8, 0, '=SA=Furios', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(277, 1, 0, 0, 1, -4, 0, 'Pi_WildSnorlax', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(277, 2, 0, 1, 0, 14, 1, '{BoB}Legend', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 12, 277, 0, 0);
INSERT INTO `ss_meta_players` VALUES(277, 3, 0, 1, 1, 20, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 240, 0, 0, 2, 157, 0, 0);
INSERT INTO `ss_meta_players` VALUES(278, 0, 0, -1, 3, -12, 1, '=SA=Furios', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 6, 70, 0, 0);
INSERT INTO `ss_meta_players` VALUES(278, 1, 1, 0, 1, 19, 1, 'Pi_WildSnorlax', 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 2, 48, 0, 0);
INSERT INTO `ss_meta_players` VALUES(278, 2, 0, 1, 0, 15, 0, '{BoB}Legend', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 22, 455, 0, 0);
INSERT INTO `ss_meta_players` VALUES(278, 3, 0, 1, 1, 20, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 240, 0, 0, 2, 157, 0, 0);
INSERT INTO `ss_meta_players` VALUES(279, 0, 6, 48, 48, 708, 1, '=SA=Furios', 1, 50, 55, 234, 0, 0, 0, 0, 0, 0, 0, 0, 1087, 5088, 0, 0, 34, 502, 115, 513);
INSERT INTO `ss_meta_players` VALUES(279, 1, 2, 37, 58, 382, 1, 'Pi_WildSnorlax', 0, 0, 9, 54, 0, 0, 0, 0, 0, 0, 0, 0, 1052, 5760, 0, 0, 36, 65, 30, 152);
INSERT INTO `ss_meta_players` VALUES(279, 2, 5, 62, 38, 893, 0, '{BoB}Legend', 0, 0, 41, 216, 0, 0, 0, 0, 0, 0, 0, 0, 1323, 7032, 0, 0, 36, 487, 145, 684);
INSERT INTO `ss_meta_players` VALUES(279, 3, 5, 41, 49, 549, 0, 'HyPE|GDM', 0, 0, 6, 18, 0, 0, 0, 0, 241, 780, 0, 0, 819, 4536, 0, 0, 24, 726, 0, 0);
INSERT INTO `ss_meta_players` VALUES(280, 0, 6, 48, 48, 708, 1, '=SA=Furios', 1, 50, 55, 234, 0, 0, 0, 0, 0, 0, 0, 0, 1087, 5088, 0, 0, 34, 502, 115, 513);
INSERT INTO `ss_meta_players` VALUES(280, 1, 2, 37, 58, 382, 1, 'Pi_WildSnorlax', 0, 0, 9, 54, 0, 0, 0, 0, 0, 0, 0, 0, 1052, 5760, 0, 0, 36, 65, 30, 152);
INSERT INTO `ss_meta_players` VALUES(280, 2, 5, 62, 38, 893, 0, '{BoB}Legend', 0, 0, 41, 216, 0, 0, 0, 0, 0, 0, 0, 0, 1323, 7032, 0, 0, 37, 487, 145, 684);
INSERT INTO `ss_meta_players` VALUES(280, 3, 5, 41, 49, 549, 0, 'HyPE|GDM', 0, 0, 6, 18, 0, 0, 0, 0, 241, 780, 0, 0, 819, 4536, 0, 0, 24, 726, 0, 0);
INSERT INTO `ss_meta_players` VALUES(281, 0, 4, 31, 43, 416, 1, '=SA=Furios', 0, 0, 18, 54, 0, 0, 0, 0, 0, 0, 0, 0, 1007, 4152, 0, 0, 48, 310, 157, 779);
INSERT INTO `ss_meta_players` VALUES(281, 1, 0, 22, 45, 155, 1, 'Pi_WildSnorlax', 0, 0, 53, 252, 0, 0, 0, 0, 373, 1455, 52, 1440, 193, 984, 0, 0, 16, 77, 0, 0);
INSERT INTO `ss_meta_players` VALUES(281, 2, 14, 42, 20, 973, 0, '{BoB}Legend', 0, 0, 15, 54, 0, 0, 0, 0, 0, 0, 0, 0, 1352, 5424, 0, 0, 26, 200, 54, 285);
INSERT INTO `ss_meta_players` VALUES(281, 3, 4, 45, 33, 645, 0, 'HyPE|GDM', 0, 0, 8, 18, 0, 0, 0, 0, 19, 120, 2, 0, 893, 6240, 0, 0, 23, 254, 0, 0);
INSERT INTO `ss_meta_players` VALUES(282, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(283, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 0, 0, 6, 8, 33, 1, 'GHOST', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 1, 0, 1, 0, 0, 1, 'BlackProSniper', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 2, 0, 11, 7, 87, 1, 'BOSS|Roentgen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 3, 0, 9, 8, 58, 1, 'jonathan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 4, 0, 6, 10, 25, 0, 'WASD(ita)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 5, 0, 7, 6, 51, 0, 'bold', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 6, 0, 8, 5, 65, 1, 'Sebiception', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 7, 0, 0, 0, 0, 0, 'Marina:$', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 8, 0, 9, 7, 57, 0, 'Zachary-Levi', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 9, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 10, 0, 5, 8, 23, 1, 'R2D2-BR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 11, 0, 13, 5, 119, 0, '[TR]BSTKILLER', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 12, 0, 6, 8, 33, 1, 'Twodo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 13, 0, 4, 9, 9, 0, 'Rygsus(PL)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(284, 15, 0, 8, 7, 52, 0, 'LifeLess', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 0, 0, 6, 9, 29, 1, 'GHOST', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 1, 0, 1, 0, 15, 1, 'BlackProSniper', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 2, 0, 11, 7, 87, 1, 'BOSS|Roentgen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 3, 0, 9, 9, 54, 1, 'jonathan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 4, 0, 6, 10, 25, 0, 'WASD(ita)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 5, 0, 7, 6, 51, 0, 'bold', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 6, 0, 8, 5, 65, 1, 'Sebiception', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 8, 0, 10, 7, 67, 0, 'Zachary-Levi', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 9, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 10, 0, 5, 8, 23, 1, 'R2D2-BR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 11, 0, 13, 5, 115, 0, '[TR]BSTKILLER', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 12, 0, 6, 8, 33, 1, 'Twodo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 13, 0, 5, 9, 19, 0, 'Rygsus(PL)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(285, 15, 0, 8, 7, 52, 0, 'LifeLess', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 0, 0, 6, 9, 29, 1, 'GHOST', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 1, 0, 3, 1, 31, 1, 'BlackProSniper', 1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 2, 0, 12, 7, 97, 1, 'BOSS|Roentgen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 3, 0, 9, 9, 54, 1, 'jonathan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 4, 0, 7, 10, 35, 0, 'WASD(ita)', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 5, 0, 7, 6, 51, 0, 'bold', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 6, 0, 8, 5, 65, 1, 'Sebiception', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 8, 0, 12, 8, 83, 0, 'Zachary-Levi', 2, 50, 0, 0, 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 9, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 10, 0, 5, 8, 23, 1, 'R2D2-BR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 11, 0, 13, 5, 115, 0, '[TR]BSTKILLER', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 12, 0, 6, 9, 29, 1, 'Twodo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 13, 0, 5, 9, 19, 0, 'Rygsus(PL)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(286, 15, 0, 8, 8, 48, 0, 'LifeLess', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 0, 0, 6, 9, 29, 1, 'GHOST', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 1, 0, 3, 1, 31, 1, 'BlackProSniper', 1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 2, 0, 13, 8, 103, 1, 'BOSS|Roentgen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 3, 0, 9, 9, 54, 1, 'jonathan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 4, 0, 7, 11, 31, 0, 'WASD(ita)', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 5, 0, 9, 6, 71, 0, 'bold', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 6, 0, 8, 5, 65, 1, 'Sebiception', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 8, 0, 12, 8, 83, 0, 'Zachary-Levi', 2, 50, 0, 0, 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 9, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 10, 0, 5, 9, 19, 1, 'R2D2-BR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 11, 0, 13, 5, 115, 0, '[TR]BSTKILLER', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 12, 0, 6, 9, 29, 1, 'Twodo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 13, 0, 5, 9, 19, 0, 'Rygsus(PL)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(287, 15, 0, 8, 8, 48, 0, 'LifeLess', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(288, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(289, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 0, 0, 15, 23, 59, 1, 'Steven_Seagal', 0, 0, 0, 0, 0, 0, 0, 0, 15, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 1, 0, 17, 11, 260, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 2, 1, 23, 25, 362, 1, '[ED]ElTioLaVara', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 28, 216, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 3, 0, 1, 4, -4, 1, 'ChupalaPuto', 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 4, 1, 36, 17, 468, 0, 'Troy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 5, 0, 21, 22, 171, 0, 'PorcoGripado', 0, 0, 0, 0, 5, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 6, 0, 10, 22, 72, 0, 'klebbeBR', 0, 0, 0, 0, 0, 0, 3, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 7, 0, 7, 11, 26, 0, 'moroxo', 0, 0, 0, 0, 0, 0, 0, 0, 23, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 8, 0, 1, 1, 18, 1, 'ok', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 9, 1, 17, 28, 168, 1, 'Valeva*rxt', 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 10, 0, 12, 22, 56, 0, 'basic', 0, 0, 0, 0, 0, 0, 2, 65, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 11, 0, 0, 0, 0, 4, 'elrobto', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 12, 0, 1, 14, -46, 1, 'Yodass34', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 13, 0, 1, 1, 6, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 14, 0, 11, 15, 73, 0, 'B0ris_The_Blade', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 15, 0, 27, 11, 474, 0, 'DES|Mazellan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 16, 0, 27, 27, 222, 1, 'General_MIDI', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 17, 0, 0, 0, 0, 4, 'R2D2-BR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 18, 0, 15, 22, 135, 1, 'Kpopluver13', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(290, 19, 0, 34, 18, 302, 0, 'Pi_DOC442WATSON', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 120, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(291, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(292, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(293, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(294, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(295, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(296, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(297, 0, 0, -1, 1, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(298, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(299, 0, 0, -1, 1, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(300, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(301, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(302, 0, 0, -1, 1, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(303, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(304, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 0, 0, 7, 23, 44, 1, 'Piich', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 1, 0, 2, 1, 16, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 2, 0, 0, 4, -26, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 3, 0, 14, 25, 95, 0, 'Antuani', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 4, 3, 20, 6, 515, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 5, 9, 52, 25, 1309, 0, 'Michael28SP', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 6, 1, 9, 17, 186, 1, 'St4rKiller', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 7, 1, 7, 1, 185, 0, '.45|Vulture', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 8, 2, 21, 24, 403, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 9, 0, 0, 5, -20, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 10, 0, -1, 1, -41, 0, 'kolonelklink', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 178, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 11, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(305, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 0, 0, 9, 24, 62, 1, 'Piich', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 1, 0, 2, 1, 16, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 2, 0, 0, 5, -30, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 28, 75, 0, 0, 0, 0, 0, 0, 4, 23, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 3, 0, 18, 27, 164, 0, 'Antuani', 0, 0, 0, 0, 0, 0, 0, 0, 107, 330, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 4, 3, 21, 8, 517, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 50, 195, 0, 0, 0, 0, 0, 0, 2, 11, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 5, 10, 54, 27, 1413, 0, 'Michael28SP', 0, 0, 6, 36, 0, 0, 0, 0, 0, 0, 7, 240, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 6, 1, 9, 19, 178, 1, 'St4rKiller', 0, 0, 0, 0, 0, 0, 7, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 7, 1, 10, 3, 227, 0, '.45|Vulture', 0, 0, 4, 54, 0, 0, 0, 0, 0, 0, 3, 320, 12, 48, 0, 0, 2, 81, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 8, 2, 23, 27, 427, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 62, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 9, 0, 0, 6, -24, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0);
INSERT INTO `ss_meta_players` VALUES(306, 10, 0, -1, 3, -27, 0, 'kolonelklink', 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 178, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 11, 0, 6, 1, 127, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 86, 576, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(306, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(307, 0, 0, 10, 26, 64, 1, 'Piich', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 28, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(307, 1, 0, 1, 2, -8, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 34, 72, 0, 0, 2, 136, 0, 0);
INSERT INTO `ss_meta_players` VALUES(307, 2, 0, 1, 6, -24, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 58, 240, 0, 0, 0, 0, 0, 0, 6, 74, 0, 0);
INSERT INTO `ss_meta_players` VALUES(307, 4, 4, 21, 9, 604, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 68, 240, 0, 0, 0, 0, 0, 0, 6, 11, 0, 0);
INSERT INTO `ss_meta_players` VALUES(307, 5, 10, 58, 29, 1534, 0, 'Michael28SP', 0, 0, 7, 54, 0, 0, 0, 0, 0, 0, 12, 480, 0, 0, 0, 0, 8, 278, 0, 0);
INSERT INTO `ss_meta_players` VALUES(307, 7, 1, 17, 5, 279, 0, '.45|Vulture', 2, 50, 4, 54, 0, 0, 0, 0, 0, 0, 7, 800, 12, 48, 0, 0, 4, 254, 0, 0);
INSERT INTO `ss_meta_players` VALUES(307, 8, 2, 25, 29, 479, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 648, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(307, 9, 0, 0, 7, -28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 1, 0);
INSERT INTO `ss_meta_players` VALUES(307, 10, 0, 0, 4, -20, 0, 'kolonelklink', 0, 0, 0, 0, 0, 0, 4, 110, 0, 0, 0, 0, 0, 0, 0, 0, 2, 178, 0, 0);
INSERT INTO `ss_meta_players` VALUES(307, 11, 0, 9, 2, 185, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 147, 984, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(307, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(307, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 0, 0, 12, 31, 84, 1, 'Piich', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 56, 456, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 1, 0, 1, 5, -20, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 69, 240, 0, 0, 8, 137, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 2, 0, 2, 10, -16, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 155, 510, 0, 0, 0, 0, 0, 0, 10, 74, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 3, 1, 3, 1, 109, 0, 'megaderp', 1, 0, 8, 72, 0, 0, 0, 0, 0, 0, 7, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 4, 5, 26, 11, 773, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 143, 645, 0, 0, 0, 0, 0, 0, 10, 54, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 5, 10, 70, 32, 1712, 0, 'Michael28SP', 4, 150, 12, 90, 0, 0, 0, 0, 0, 0, 26, 1520, 0, 0, 0, 0, 19, 356, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 7, 1, 19, 7, 286, 0, '.45|Vulture', 2, 50, 11, 90, 0, 0, 0, 0, 0, 0, 13, 1040, 12, 48, 0, 0, 4, 254, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 8, 2, 29, 32, 531, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 153, 1200, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 9, 0, 0, 10, -40, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 3, 0);
INSERT INTO `ss_meta_players` VALUES(308, 10, 0, 1, 7, -2, 0, 'kolonelklink', 0, 0, 0, 0, 0, 0, 12, 385, 0, 0, 0, 0, 0, 0, 0, 0, 2, 178, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 11, 0, 15, 5, 281, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 257, 1656, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(308, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 0, 0, 12, 33, 76, 1, 'Piich', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 576, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 1, 0, 2, 7, 1, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 107, 384, 0, 0, 8, 137, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 2, 0, 2, 10, -16, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 169, 510, 0, 0, 0, 0, 0, 0, 12, 81, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 3, 1, 6, 3, 133, 0, 'megaderp', 2, 50, 8, 72, 0, 0, 0, 0, 0, 0, 10, 560, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 4, 5, 27, 12, 792, 0, 'HyPE|JoeSmith', 0, 0, 5, 36, 0, 0, 0, 0, 185, 840, 0, 0, 0, 0, 0, 0, 10, 54, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 5, 10, 71, 34, 1715, 0, 'Michael28SP', 7, 150, 15, 126, 0, 0, 0, 0, 0, 0, 30, 1760, 0, 0, 0, 0, 22, 356, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 6, 0, 1, 1, 18, 0, 'Miko', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 7, 1, 21, 7, 301, 0, '.45|Vulture', 2, 50, 11, 90, 0, 0, 0, 0, 0, 0, 17, 1280, 12, 48, 0, 0, 4, 254, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 8, 2, 32, 34, 586, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 209, 1536, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 9, 0, 0, 10, -40, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 3, 0);
INSERT INTO `ss_meta_players` VALUES(309, 10, 0, 3, 8, 18, 1, 'kolonelklink', 0, 0, 0, 0, 0, 0, 16, 640, 0, 0, 0, 0, 0, 0, 0, 0, 2, 178, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 11, 0, 17, 8, 337, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 295, 1872, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(309, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 0, 0, 14, 34, 92, 1, 'Piich', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 107, 768, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 1, 0, 2, 7, 3, 0, 'jefersoneid', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 122, 384, 0, 0, 12, 137, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 2, 0, 4, 11, 29, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 206, 570, 0, 0, 0, 0, 0, 0, 14, 317, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 3, 1, 7, 5, 135, 0, 'megaderp', 2, 50, 13, 126, 0, 0, 0, 0, 0, 0, 15, 800, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 4, 5, 29, 14, 817, 0, 'HyPE|JoeSmith', 0, 0, 5, 36, 0, 0, 0, 0, 212, 930, 0, 0, 0, 0, 0, 0, 12, 146, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 5, 10, 74, 35, 1779, 0, 'Michael28SP', 8, 150, 15, 126, 0, 0, 0, 0, 0, 0, 37, 2000, 0, 0, 0, 0, 28, 627, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 6, 0, 4, 1, 51, 0, 'Miko', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 7, 1, 21, 9, 293, 0, '.45|Vulture', 2, 50, 11, 90, 0, 0, 0, 0, 0, 0, 22, 1360, 12, 48, 0, 0, 4, 254, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 8, 2, 33, 36, 636, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 232, 1632, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 9, 0, 0, 12, -48, 1, 'unarmed', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0, 3, 0);
INSERT INTO `ss_meta_players` VALUES(310, 10, 0, 4, 10, 22, 1, 'kolonelklink', 0, 0, 0, 0, 0, 0, 23, 885, 0, 0, 0, 0, 0, 0, 0, 0, 2, 178, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 11, 0, 19, 10, 351, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 333, 2232, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 12, 0, 1, 1, 6, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(310, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 0, 0, 14, 34, 92, 1, 'Piich', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 107, 768, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 1, 0, 2, 7, 3, 0, 'jefersoneid', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 122, 384, 0, 0, 12, 137, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 2, 0, 4, 11, 29, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 206, 570, 0, 0, 0, 0, 0, 0, 14, 317, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 3, 1, 7, 5, 135, 0, 'megaderp', 2, 50, 13, 126, 0, 0, 0, 0, 0, 0, 15, 800, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 4, 5, 29, 14, 817, 0, 'HyPE|JoeSmith', 0, 0, 5, 36, 0, 0, 0, 0, 212, 930, 0, 0, 0, 0, 0, 0, 12, 146, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 5, 10, 74, 35, 1779, 0, 'Michael28SP', 8, 150, 15, 126, 0, 0, 0, 0, 0, 0, 37, 2000, 0, 0, 0, 0, 28, 627, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 6, 0, 4, 1, 51, 0, 'Miko', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 7, 1, 21, 9, 293, 0, '.45|Vulture', 2, 50, 11, 90, 0, 0, 0, 0, 0, 0, 22, 1360, 12, 48, 0, 0, 4, 254, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 8, 2, 33, 36, 636, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 232, 1632, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 9, 0, 0, 12, -48, 1, 'unarmed', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0, 3, 0);
INSERT INTO `ss_meta_players` VALUES(311, 10, 0, 4, 10, 22, 1, 'kolonelklink', 0, 0, 0, 0, 0, 0, 23, 885, 0, 0, 0, 0, 0, 0, 0, 0, 2, 178, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 11, 0, 19, 10, 351, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 333, 2232, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 12, 0, 1, 1, 6, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(311, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 0, 0, 0, 3, -12, 1, 'leoson', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 1, 1, 1, 2, 69, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 2, 0, 2, 4, 16, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 8, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 3, 1, 9, 1, 178, 0, 'megaderp', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 4, 0, 10, 0, 184, 0, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 5, 1, 5, 1, 174, 0, 'Michael28SP', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 6, 0, 0, 0, 0, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 7, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 8, 0, 1, 7, 2, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 9, 0, 0, 3, -12, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 10, 0, 1, 1, 6, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 12, 0, 3, 0, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 13, 0, 3, 4, 38, 1, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(312, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 0, 0, -1, 3, -32, 1, 'leoson', 0, 0, 0, 0, 0, 0, 3, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 1, 1, 1, 2, 69, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 2, 0, 2, 5, 21, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 32, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 3, 1, 13, 1, 213, 0, 'megaderp', 0, 0, 7, 72, 0, 0, 0, 0, 0, 0, 4, 640, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 4, 0, 10, 0, 184, 0, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 21, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 5, 2, 6, 1, 306, 0, 'Michael28SP', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 6, 0, 0, 1, -4, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 7, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 8, 0, 1, 9, -6, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 9, 0, 0, 4, -16, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 10, 0, 1, 2, 2, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 12, 0, 3, 1, 26, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 13, 0, 5, 4, 58, 1, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(313, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 0, 0, -1, 3, -32, 1, 'leoson', 0, 0, 0, 0, 0, 0, 5, 155, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 1, 1, 1, 2, 69, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 2, 0, 2, 5, 21, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 32, 60, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 3, 1, 13, 2, 221, 0, 'megaderp', 0, 0, 7, 72, 0, 0, 0, 0, 0, 0, 5, 640, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 4, 0, 11, 0, 194, 0, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 36, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 5, 2, 7, 1, 316, 0, 'Michael28SP', 0, 0, 2, 36, 0, 0, 0, 0, 0, 0, 4, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 6, 0, 1, 1, 30, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 7, 0, -1, 1, -24, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 24, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 8, 0, 1, 9, 6, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 9, 0, 0, 5, -20, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 10, 0, 1, 2, 2, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 13, 0, 5, 5, 54, 1, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(314, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 0, 0, -1, 3, -32, 1, 'leoson', 0, 0, 0, 0, 0, 0, 6, 175, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 1, 1, 1, 2, 69, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 2, 0, 2, 5, 21, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 35, 75, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 3, 1, 13, 2, 221, 0, 'megaderp', 0, 0, 7, 72, 0, 0, 0, 0, 0, 0, 5, 640, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 4, 0, 11, 0, 194, 0, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 47, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 5, 2, 7, 1, 328, 0, 'Michael28SP', 0, 0, 2, 36, 0, 0, 0, 0, 0, 0, 4, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 6, 0, 1, 1, 30, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 7, 0, -1, 1, -24, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 24, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 8, 0, 1, 9, 6, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 9, 0, 0, 5, -20, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 10, 0, 1, 2, 2, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 13, 0, 5, 5, 54, 1, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(315, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 0, 0, -1, 4, -36, 1, 'leoson', 0, 0, 0, 0, 0, 0, 7, 180, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 1, 1, 1, 2, 69, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 2, 0, 1, 5, 1, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 38, 90, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 3, 1, 13, 2, 221, 0, 'megaderp', 0, 0, 9, 72, 0, 0, 0, 0, 0, 0, 6, 720, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 4, 0, 11, 0, 194, 0, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 56, 165, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 5, 2, 7, 2, 326, 0, 'Michael28SP', 0, 0, 2, 36, 0, 0, 0, 0, 0, 0, 5, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 6, 0, 1, 1, 30, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 7, 0, -1, 1, -24, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 24, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 8, 0, 2, 9, 53, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 9, 0, 0, 5, -20, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 10, 0, 1, 2, 2, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 13, 0, 5, 5, 54, 1, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(316, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 0, 0, -1, 4, -36, 1, 'leoson', 0, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 1, 1, 1, 4, 65, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 48, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 2, 0, 2, 7, 3, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 68, 120, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 3, 1, 17, 3, 264, 0, 'megaderp', 0, 0, 24, 108, 0, 0, 0, 0, 0, 0, 11, 1200, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 4, 0, 12, 1, 200, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 89, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 5, 2, 10, 3, 359, 0, 'Michael28SP', 0, 0, 2, 36, 0, 0, 0, 0, 0, 0, 10, 640, 0, 0, 0, 0, 2, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 6, 0, 1, 2, 26, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 168, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 7, 0, 2, 2, 7, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 47, 336, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 8, 0, 4, 10, 83, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 43, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 9, 0, 0, 6, -24, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 10, 0, 2, 4, 4, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 13, 0, 6, 6, 85, 1, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(317, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 0, 0, -1, 4, -36, 1, 'leoson', 0, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 1, 1, 1, 4, 61, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 48, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 2, 0, 2, 7, 3, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 68, 120, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 3, 1, 17, 3, 264, 0, 'megaderp', 0, 0, 24, 108, 0, 0, 0, 0, 0, 0, 12, 1200, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 4, 0, 12, 1, 200, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 89, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 5, 2, 12, 3, 359, 0, 'Michael28SP', 0, 0, 7, 54, 0, 0, 0, 0, 0, 0, 11, 880, 0, 0, 0, 0, 2, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 6, 0, 1, 2, 26, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 168, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 7, 0, 2, 2, 7, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 47, 336, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 8, 0, 4, 11, 93, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 52, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 9, 0, 0, 6, -24, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 10, 0, 2, 4, 4, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 13, 0, 6, 6, 85, 1, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(318, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 0, 0, 0, 6, -34, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 4, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 1, 1, 2, 6, 87, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 60, 96, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 2, 0, 3, 9, 29, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 109, 225, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 3, 1, 25, 4, 366, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 19, 1840, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 154, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 5, 2, 16, 3, 426, 0, 'Michael28SP', 1, 50, 7, 54, 0, 0, 0, 0, 0, 0, 16, 1040, 0, 0, 0, 0, 10, 249, 5, 0);
INSERT INTO `ss_meta_players` VALUES(319, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 7, 0, 6, 3, 69, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 8, 0, 6, 14, 126, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 103, 696, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 10, 0, 3, 5, 34, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 36, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 11, 0, 0, 0, 0, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(319, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 0, 0, 0, 6, -34, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 4, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 1, 1, 2, 6, 87, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 60, 96, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 2, 0, 3, 9, 29, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 113, 225, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 3, 1, 25, 5, 362, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 20, 1840, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 154, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 5, 3, 16, 3, 426, 0, 'Michael28SP', 1, 50, 7, 54, 0, 0, 0, 0, 0, 0, 16, 1040, 0, 0, 0, 0, 10, 249, 5, 0);
INSERT INTO `ss_meta_players` VALUES(320, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 7, 0, 6, 3, 69, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 8, 0, 7, 14, 137, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 107, 720, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 10, 0, 3, 5, 34, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 37, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 11, 0, 0, 0, 0, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(320, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 0, 0, 0, 6, -34, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 4, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 1, 1, 2, 7, 83, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 144, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 2, 0, 4, 9, 39, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 132, 300, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 3, 1, 25, 5, 362, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 20, 1840, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 158, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 5, 3, 17, 3, 520, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 18, 1200, 0, 0, 0, 0, 10, 249, 5, 0);
INSERT INTO `ss_meta_players` VALUES(321, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 7, 0, 6, 3, 69, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 8, 0, 7, 15, 133, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 816, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 10, 0, 3, 6, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 11, 0, 1, 0, 10, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(321, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 0, 0, 0, 6, -34, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 5, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 1, 1, 2, 7, 83, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 144, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 2, 0, 4, 9, 39, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 132, 300, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 3, 1, 25, 5, 362, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 20, 1840, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 158, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 5, 3, 17, 3, 520, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 18, 1200, 0, 0, 0, 0, 10, 249, 5, 0);
INSERT INTO `ss_meta_players` VALUES(322, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 7, 0, 6, 3, 69, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 8, 0, 7, 15, 133, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 816, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 10, 0, 3, 6, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 11, 0, 1, 0, 10, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(322, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 0, 0, 0, 6, -34, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 6, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 1, 1, 2, 7, 83, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 144, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 2, 0, 4, 9, 39, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 132, 300, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 3, 1, 25, 5, 362, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 20, 1840, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 158, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 5, 3, 17, 3, 520, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 18, 1200, 0, 0, 0, 0, 10, 249, 5, 0);
INSERT INTO `ss_meta_players` VALUES(323, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 7, 0, 6, 3, 69, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 8, 0, 7, 15, 133, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 816, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 10, 0, 3, 6, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 11, 0, 1, 0, 10, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(323, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 0, 0, 0, 6, -34, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 6, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 1, 1, 2, 7, 83, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 144, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 2, 0, 4, 9, 39, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 132, 300, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 3, 1, 25, 5, 362, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 20, 1840, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 158, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 5, 3, 17, 3, 520, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 19, 1200, 0, 0, 0, 0, 10, 249, 5, 0);
INSERT INTO `ss_meta_players` VALUES(324, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 7, 0, 6, 3, 69, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 8, 0, 7, 15, 133, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 816, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 10, 0, 3, 6, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 11, 0, 1, 0, 10, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(324, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 0, 0, 0, 6, -34, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 6, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 1, 1, 2, 7, 83, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 144, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 2, 0, 4, 9, 39, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 132, 300, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 3, 1, 25, 5, 362, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 20, 1840, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 158, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 5, 3, 17, 3, 520, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 19, 1200, 0, 0, 0, 0, 11, 249, 5, 0);
INSERT INTO `ss_meta_players` VALUES(325, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 7, 0, 6, 3, 69, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 8, 0, 7, 15, 133, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 816, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 10, 0, 3, 6, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 11, 0, 1, 0, 10, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(325, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 0, 0, 0, 6, -34, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 6, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 1, 1, 2, 7, 83, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 144, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 2, 0, 4, 9, 39, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 132, 300, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 3, 1, 26, 5, 372, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 21, 1920, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 158, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 5, 3, 17, 3, 520, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 19, 1200, 0, 0, 0, 0, 12, 249, 5, 0);
INSERT INTO `ss_meta_players` VALUES(326, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 7, 0, 6, 3, 69, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 8, 0, 7, 15, 133, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 816, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 10, 0, 3, 6, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 11, 0, 1, 1, 6, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(326, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 0, 0, 0, 6, -34, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 6, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 1, 1, 2, 7, 83, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 144, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 2, 0, 4, 9, 39, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 132, 300, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 3, 1, 26, 5, 372, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 21, 1920, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 158, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 5, 3, 17, 3, 520, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 19, 1200, 0, 0, 0, 0, 12, 290, 5, 0);
INSERT INTO `ss_meta_players` VALUES(327, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 7, 0, 6, 3, 69, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 8, 0, 7, 15, 133, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 816, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 10, 0, 3, 6, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 11, 0, 1, 1, 6, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(327, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 0, 0, 0, 7, -38, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 6, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 1, 1, 2, 7, 83, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 144, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 2, 0, 4, 9, 39, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 132, 300, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 3, 1, 27, 5, 382, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 22, 2000, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 158, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 5, 3, 18, 3, 530, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 20, 1280, 0, 0, 0, 0, 13, 290, 5, 0);
INSERT INTO `ss_meta_players` VALUES(328, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 7, 0, 6, 4, 65, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 8, 0, 7, 15, 133, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 816, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 10, 0, 3, 6, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 11, 0, 1, 1, 6, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(328, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 0, 0, 0, 7, -38, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 6, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 1, 1, 2, 7, 83, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 144, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 2, 0, 4, 9, 39, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 132, 300, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 3, 1, 27, 5, 382, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 22, 2000, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 158, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 5, 3, 18, 3, 530, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 20, 1280, 0, 0, 0, 0, 13, 290, 5, 0);
INSERT INTO `ss_meta_players` VALUES(329, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 7, 0, 6, 4, 65, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 8, 0, 7, 15, 133, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 816, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 10, 0, 3, 6, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 11, 0, 1, 1, 6, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(329, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 0, 0, 0, 7, -38, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 6, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 1, 1, 2, 7, 83, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 144, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 2, 0, 4, 9, 39, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 132, 300, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 3, 1, 27, 5, 382, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 22, 2000, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 158, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 5, 3, 18, 3, 530, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 20, 1280, 0, 0, 0, 0, 13, 290, 5, 0);
INSERT INTO `ss_meta_players` VALUES(330, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 7, 0, 6, 4, 65, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 8, 0, 7, 15, 133, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120, 816, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 10, 0, 3, 6, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 11, 0, 1, 1, 6, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(330, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 0, 0, 0, 7, -38, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 41, 96, 0, 0, 6, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 1, 1, 2, 7, 83, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 144, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 2, 0, 4, 9, 39, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 132, 300, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 3, 1, 27, 5, 382, 0, 'megaderp', 7, 150, 26, 126, 0, 0, 0, 0, 0, 0, 22, 2000, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 4, 0, 14, 5, 204, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 158, 645, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 5, 3, 18, 4, 538, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 20, 1280, 0, 0, 0, 0, 14, 338, 5, 0);
INSERT INTO `ss_meta_players` VALUES(331, 6, 0, 2, 4, 28, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 7, 0, 6, 4, 65, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 123, 912, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 8, 0, 8, 15, 168, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 124, 840, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 9, 0, 0, 7, -28, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 10, 0, 3, 6, 30, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 11, 0, 1, 1, 6, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 13, 0, 6, 7, 81, 4, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(331, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 0, 0, 0, 8, -42, 1, 'leoson', 1, 0, 0, 0, 0, 0, 10, 210, 0, 0, 0, 0, 61, 96, 0, 0, 6, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 1, 1, 4, 8, 123, 0, 'jefersoneid', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 92, 288, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 2, 0, 4, 10, 49, 1, '=rANGO=', 0, 0, 0, 0, 0, 0, 0, 0, 154, 300, 0, 0, 0, 0, 0, 0, 8, 1, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 3, 2, 30, 5, 545, 0, 'megaderp', 7, 150, 34, 162, 0, 0, 0, 0, 0, 0, 27, 2400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 4, 0, 17, 5, 258, 0, 'HyPE|JoeSmith', 0, 0, 1, 0, 0, 0, 0, 0, 219, 855, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 5, 3, 18, 5, 534, 0, 'Michael28SP', 2, 100, 7, 54, 0, 0, 0, 0, 0, 0, 20, 1280, 0, 0, 0, 0, 18, 340, 5, 0);
INSERT INTO `ss_meta_players` VALUES(332, 6, 0, 2, 5, 24, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 71, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 7, 0, 7, 6, 80, 1, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 42, 135, 0, 0, 141, 1032, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 8, 0, 11, 17, 202, 1, 'FrauHolle', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 158, 1224, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 9, 0, 0, 8, -32, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 38, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 10, 0, 3, 7, 26, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 62, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 11, 0, 1, 2, 2, 1, 'Akram', 0, 0, 0, 0, 0, 0, 0, 0, 64, 330, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 13, 0, 6, 7, 81, 0, 'SlimingDog(Ger)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 16, 0, 0, 0, 0, 4, 'tut', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(332, 19, 0, 0, 0, 0, 4, 'mayhem0313', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(333, 0, 0, -1, 1, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(334, 0, 0, -1, 1, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(335, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(336, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(337, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(338, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(339, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(340, 0, 0, 4, 7, 16, 1, 'M2lanie', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(340, 1, 0, 3, 2, 72, 1, 'ADOS|Bit', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(340, 2, 0, 2, 1, 16, 0, 'MarcoSSilva100]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(340, 3, 0, 4, 5, 28, 4, 'Joaoneto', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(340, 4, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(340, 5, 1, 12, 9, 234, 0, 'SERKAN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(340, 6, 0, -1, 5, -20, 0, 'v4share_CcheEEF', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(340, 12, 0, 6, 8, 56, 1, 'aleman48', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(341, 0, 0, 4, 8, 16, 1, 'M2lanie', 0, 0, 0, 0, 0, 0, 3, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(341, 1, 0, 3, 2, 72, 1, 'ADOS|Bit', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(341, 2, 0, 2, 1, 16, 0, 'MarcoSSilva100]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(341, 3, 0, 4, 5, 28, 0, 'Joaoneto', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(341, 4, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(341, 5, 1, 13, 9, 234, 0, 'SERKAN', 0, 0, 0, 0, 0, 0, 3, 205, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(341, 6, 0, -1, 5, -20, 0, 'v4share_CcheEEF', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(341, 12, 0, 6, 8, 56, 1, 'aleman48', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(342, 0, 0, 4, 8, 12, 1, 'M2lanie', 0, 0, 0, 0, 0, 0, 3, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(342, 1, 0, 3, 2, 72, 1, 'ADOS|Bit', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(342, 2, 0, 2, 1, 16, 0, 'MarcoSSilva100]', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(342, 3, 0, 4, 5, 28, 0, 'Joaoneto', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(342, 4, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(342, 5, 1, 13, 9, 244, 0, 'SERKAN', 0, 0, 0, 0, 0, 0, 3, 205, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(342, 6, 0, -1, 5, -20, 0, 'v4share_CcheEEF', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(342, 12, 0, 6, 8, 56, 1, 'aleman48', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(343, 0, 0, 4, 8, 12, 1, 'M2lanie', 0, 0, 0, 0, 0, 0, 3, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(343, 1, 0, 3, 2, 72, 1, 'ADOS|Bit', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(343, 2, 0, 2, 1, 16, 0, 'MarcoSSilva100]', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(343, 3, 0, 4, 5, 28, 0, 'Joaoneto', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(343, 4, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(343, 5, 1, 13, 9, 244, 0, 'SERKAN', 0, 0, 0, 0, 0, 0, 3, 205, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(343, 6, 0, -1, 5, -20, 0, 'v4share_CcheEEF', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(343, 12, 0, 6, 8, 56, 1, 'aleman48', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 0, 0, 9, 16, 76, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 1, 0, 8, 8, 57, 0, '.', 9, 100, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 2, 0, 11, 9, 134, 1, 'cabbie', 0, 0, 0, 0, 11, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 3, 0, 6, 5, 40, 1, 'aussenseiter', 1, 0, 8, 54, 0, 0, 0, 0, 0, 0, 4, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 4, 0, 14, 8, 94, 1, 'Feng', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 560, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 5, 0, 3, 9, 16, 1, 'andres', 0, 0, 0, 0, 13, 480, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 6, 0, 5, 10, 38, 0, 'sadamhossin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 120, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 7, 0, 0, 1, -4, 0, 'sefudeu', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 9, 0, 7, 15, 22, 1, 'You''reDead!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 10, 0, 6, 8, 40, 0, 'riot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 11, 0, 0, 3, -22, 0, 'evilturkey', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 49, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 12, 0, 23, 12, 217, 0, 'Kpopluver13', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 52, 384, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 13, 0, 3, 4, 19, 0, 'RKTnoob', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 24, 0, 0, 4, 123, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 14, 0, 5, 5, 30, 1, 'TriZzomiXxHeywa', 0, 0, 0, 0, 0, 0, 8, 190, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 15, 0, 1, 3, -2, 1, '[Heywaa]Alicia.', 0, 0, 0, 0, 0, 0, 0, 0, 16, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 16, 0, 7, 2, 67, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 34, 192, 0, 0, 4, 372, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 17, 0, 1, 3, -2, 1, 'LaggersLead', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 18, 0, 0, 2, -8, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 15, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(344, 19, 0, 4, 2, 32, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 77, 528, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 0, 0, 10, 17, 72, 0, 'unarmed', 2, 100, 0, 0, 0, 0, 0, 0, 0, 0, 4, 160, 0, 0, 0, 0, 8, 61, 25, 38);
INSERT INTO `ss_meta_players` VALUES(345, 1, 0, 7, 11, 45, 0, '.', 9, 100, 0, 0, 6, 240, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 4, 14, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 2, 0, 14, 14, 204, 1, 'cabbie', 0, 0, 0, 0, 12, 360, 6, 215, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 3, 0, 9, 7, 62, 1, 'aussenseiter', 1, 0, 14, 54, 0, 0, 0, 0, 33, 135, 7, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 4, 0, 17, 12, 115, 1, 'Feng', 5, 50, 5, 36, 0, 0, 0, 0, 0, 0, 18, 1120, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 5, 0, 4, 12, 14, 1, 'andres', 0, 0, 0, 0, 13, 480, 8, 115, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 6, 0, 8, 12, 55, 0, 'sadamhossin', 0, 0, 0, 0, 0, 0, 6, 315, 0, 0, 0, 0, 0, 0, 0, 0, 12, 448, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 7, 0, 0, 1, -4, 0, 'sefudeu', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 8, 0, 0, 0, 0, 4, 'EeSsPp', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 9, 0, 8, 18, 32, 1, 'You''reDead!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 11, 0, 3, 5, 13, 0, 'evilturkey', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 504, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 12, 0, 27, 14, 249, 0, 'Kpopluver13', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 112, 744, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 13, 0, 6, 4, 49, 0, 'RKTnoob', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 65, 408, 0, 0, 8, 123, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 14, 0, 6, 8, 28, 1, 'TriZzomiXxHeywa', 0, 0, 0, 0, 0, 0, 22, 550, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 15, 0, 1, 6, -14, 1, '[Heywaa]Alicia.', 0, 0, 0, 0, 0, 0, 0, 0, 54, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 16, 0, 17, 3, 168, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 163, 1104, 0, 0, 6, 563, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 17, 0, 3, 6, 18, 1, 'LaggersLead', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 76, 456, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 18, 0, 0, 6, -24, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 82, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(345, 19, 0, 8, 4, 64, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 126, 840, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(346, 0, 1, 11, 11, 123, 0, 'L@ct0', 0, 0, 0, 0, 0, 0, 5, 270, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(346, 1, 0, 6, 12, 20, 1, 'jagon', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(346, 2, 0, 0, 4, -16, 1, 'bastian', 0, 0, 0, 0, 0, 0, 10, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(346, 3, 0, 11, 13, 129, 0, 'DiGiDiX', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 72, 0, 0, 0, 0, 80, 475);
INSERT INTO `ss_meta_players` VALUES(346, 4, 0, 7, 2, 108, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 67, 384, 0, 0, 2, 290, 0, 0);
INSERT INTO `ss_meta_players` VALUES(346, 5, 0, 4, 1, 91, 0, 'BLC', 0, 0, 0, 0, 0, 0, 12, 395, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(346, 6, 0, 0, 0, 0, 1, 'AVENTADOR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(346, 7, 2, 6, 7, 204, 0, 'Nickname', 0, 0, 0, 0, 0, 0, 0, 0, 37, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 0, 0, 3, 4, 19, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 1, 1, 5, 8, 139, 1, 'GUAYASAMIN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 194, 912, 0, 0, 12, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 2, 0, 5, 14, 119, 0, 'r0n', 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 19, 480, 0, 0, 0, 0, 2, 8, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 3, 0, 12, 6, 135, 1, 'greg', 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 24, 1120, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 4, 2, 7, 6, 280, 1, 'Nieukerk', 0, 0, 8, 36, 0, 0, 0, 0, 0, 0, 14, 320, 29, 192, 0, 0, 4, 21, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 5, 1, 10, 0, 271, 1, 'harps{TyD}', 0, 0, 0, 0, 0, 0, 0, 0, 190, 1020, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 6, 0, 8, 6, 136, 0, 'PericoPETMANIA', 2, 0, 0, 0, 0, 0, 0, 0, 161, 735, 0, 0, 0, 0, 0, 0, 4, 70, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 7, 0, 11, 1, 98, 1, 'JuNkeE''zZ', 2, 50, 14, 90, 0, 0, 0, 0, 0, 0, 20, 1200, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 8, 0, 2, 9, -16, 0, 'zebLPP', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 560, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 9, 0, 1, 9, 54, 0, 'Steven_Seagal', 0, 0, 0, 0, 0, 0, 0, 0, 215, 600, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 10, 0, 5, 3, 38, 0, 'HEROIN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 84, 624, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 11, 0, 5, 9, -2, 0, 'Joaoneto', 0, 0, 1, 0, 0, 0, 17, 675, 59, 210, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 12, 0, 3, 1, 31, 1, 'MrGiogyo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 13, 0, 5, 6, 52, 1, 'Harkxist', 0, 0, 0, 0, 0, 0, 11, 530, 27, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(347, 14, 0, 1, 1, 11, 1, 'Matador30', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 24, 0, 0, 2, 67, 0, 0);
INSERT INTO `ss_meta_players` VALUES(348, 0, 0, 0, 0, 0, 0, '&#039;HyPE|GDM\\&', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(348, 0, 0, 0, 0, 0, 0, '&#039;PericoPETM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(348, 0, 0, 0, 0, 0, 0, '&#039;TehWeirdo\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(348, 0, 0, 0, 0, 0, 0, '&#039;LeTroll\\&#', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(349, 0, 0, 0, 0, 0, 0, '&#039;HyPE|GDM\\&', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(349, 0, 0, 0, 0, 0, 0, '&#039;PericoPETM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(349, 0, 0, 0, 0, 0, 0, '&#039;TehWeirdo\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(349, 0, 0, 0, 0, 0, 0, '&#039;LeTroll\\&#', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''DJMcFlinty\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''MILLO.COM\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''polskajakcos\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''BRASILEIRINHO;)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''CubicShots\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''ts61\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''DonChisciotte\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''woop\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''Qu0xi\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''Treebark40000\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''eren\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''HyPE|GDM\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''Adew\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''DaniTum\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(350, 0, 0, 0, 0, 0, 0, '''badgirl\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''DJMcFlinty\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''MILLO.COM\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''polskajakcos\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''BRASILEIRINHO;)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''CubicShots\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''ts61\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''DonChisciotte\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''woop\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''Qu0xi\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''Treebark40000\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''eren\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''HyPE|GDM\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''Adew\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''DaniTum\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(351, 0, 0, 0, 0, 0, 0, '''badgirl\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(352, 0, 0, 0, 0, 0, 0, '''.Kelwin\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(352, 0, 0, 0, 0, 0, 0, '''HyPE|GDM\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(353, 0, 0, 0, 0, 0, 0, '''.Kelwin\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(353, 0, 0, 0, 0, 0, 0, '''HyPE|GDM\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(353, 0, 0, 0, 0, 0, 0, '''IT$M4$T4\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(353, 0, 0, 0, 0, 0, 0, '''-Ls^.Sw4G*\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(353, 0, 0, 0, 0, 0, 0, '''unarmed\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(354, 0, 0, 0, 0, 0, 0, '''.Kelwin\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(354, 0, 0, 0, 0, 0, 0, '''HyPE|GDM\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(354, 0, 0, 0, 0, 0, 0, '''IT$M4$T4\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(354, 0, 0, 0, 0, 0, 0, '''-Ls^.Sw4G*\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(354, 0, 0, 0, 0, 0, 0, '''unarmed\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(355, 0, 0, 0, 0, 0, 0, '''.Kelwin\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(355, 0, 0, 0, 0, 0, 0, '''HyPE|GDM\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(355, 0, 0, 0, 0, 0, 0, '''IT$M4$T4\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(355, 0, 0, 0, 0, 0, 0, '''-Ls^.Sw4G*\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(355, 0, 0, 0, 0, 0, 0, '''unarmed\\', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(356, 0, 0, -1, 1, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(357, 0, 7, 15, 2, 432, 1, '.Kelwin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(357, 1, 1, 2, 3, 55, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(357, 2, 1, 2, 7, 39, 0, 'IT$M4$T4', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(357, 3, 1, 0, 6, 11, 0, '-Ls^.Sw4G*', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(357, 4, 0, 1, 2, 6, 1, 'DES|Godsmack', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(357, 5, 0, 0, 0, 0, 4, 'surdo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(358, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 0, 0, 0, 1, -4, 0, 'BOSS|Roentgen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 1, 0, 1, 0, 10, 1, 'fps_doug2', 0, 0, 0, 0, 0, 0, 0, 0, 15, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 2, 0, 2, 1, 16, 1, 'Warmembr', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 3, 0, 0, 0, 0, 1, 'DiamondCassie', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 4, 0, 0, 0, 0, 4, 'Fojones10', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 5, 0, 0, 1, -4, 0, 'elia12', 0, 0, 8, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 6, 0, 1, 1, 23, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 7, 0, 0, 1, -4, 0, '7', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 8, 0, 0, 0, 0, 4, 'Vampir3Bit3s', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 9, 0, 0, 0, 0, 1, 'ZaNTeX_w0N', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 10, 0, 0, 0, 0, 0, '|BrZ|PsyPro|Pt', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(359, 11, 0, 1, 0, 10, 1, 'omaehasinu', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 120, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(360, 0, 0, 4, 4, 24, 0, 'BOSS|Roentgen', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(360, 1, 0, 3, 5, 10, 1, 'fps_doug2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(360, 2, 0, 0, 0, 0, 4, '[ED]Carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(360, 4, 0, 5, 3, 33, 0, 'Fojones10', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 480, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(360, 5, 0, 3, 4, 9, 1, 'elia12', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(360, 6, 0, 7, 1, 66, 0, 'HyPE|GDM', 7, 50, 0, 0, 0, 0, 0, 0, 0, 0, 18, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(360, 7, 0, 0, 5, -20, 0, '7', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(360, 8, 0, 1, 4, -6, 1, 'Vampir3Bit3s', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(360, 9, 0, 6, 4, 34, 1, 'ZaNTeX_w0N', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 640, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(360, 10, 0, 7, 3, 58, 0, '|BrZ|PsyPro|Pt', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 560, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(360, 11, 0, 4, 4, 24, 1, 'omaehasinu', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(361, 0, 0, 4, 11, 31, 1, 'mort', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 45, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(361, 1, 3, 9, 6, 337, 1, '|KH|32', 0, 0, 0, 0, 0, 0, 12, 710, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(361, 2, 2, 11, 7, 308, 1, 'Pi_Takkunen', 0, 0, 0, 0, 12, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(361, 3, 0, 5, 11, 6, 0, 'rompeanos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 168, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(361, 4, 0, 7, 7, 112, 0, 'Teapot|', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 84, 504, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(361, 5, 3, 7, 10, 318, 0, 'ibr', 0, 0, 0, 0, 0, 0, 2, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(361, 6, 0, 5, 3, 62, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 49, 384, 0, 0, 6, 233, 0, 0);
INSERT INTO `ss_meta_players` VALUES(361, 7, 0, 3, 3, 24, 0, '{BoB}haXoR.', 0, 0, 0, 0, 0, 0, 0, 0, 89, 405, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(361, 8, 0, 10, 5, 160, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 70, 270, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(361, 9, 0, 5, 1, 87, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 40, 264, 0, 0, 3, 183, 3, 19);
INSERT INTO `ss_meta_players` VALUES(361, 10, 0, 0, 1, -4, 1, 'unad.001', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(362, 0, 0, 14, 5, 223, 1, 'MaryAnn', 0, 0, 8, 0, 0, 0, 0, 0, 427, 1740, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(362, 1, 6, 45, 36, 1111, 1, '|KH|32', 0, 0, 0, 0, 0, 0, 109, 5715, 0, 0, 0, 0, 0, 0, 0, 0, 40, 745, 0, 0);
INSERT INTO `ss_meta_players` VALUES(362, 2, 0, 1, 5, -8, 1, 'AsSoMNiak', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 312, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(362, 3, 0, 15, 44, 96, 0, 'rompeanos', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 383, 2352, 0, 0, 2, 7, 0, 0);
INSERT INTO `ss_meta_players` VALUES(362, 4, 2, 44, 24, 883, 1, 'Teapot|', 6, 0, 0, 0, 0, 0, 0, 0, 920, 3795, 0, 0, 162, 1200, 0, 0, 20, 164, 45, 285);
INSERT INTO `ss_meta_players` VALUES(362, 5, 6, 22, 39, 840, 0, 'ibr', 0, 0, 0, 0, 0, 0, 52, 2090, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(362, 6, 0, 23, 15, 276, 1, 'V3RUC', 0, 0, 23, 54, 0, 0, 0, 0, 0, 0, 0, 0, 383, 2688, 0, 0, 26, 651, 28, 190);
INSERT INTO `ss_meta_players` VALUES(362, 7, 2, 20, 23, 499, 1, 'SDBS', 0, 0, 0, 0, 0, 0, 66, 2730, 0, 0, 0, 0, 0, 0, 0, 0, 8, 178, 0, 0);
INSERT INTO `ss_meta_players` VALUES(362, 8, 0, 37, 24, 634, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 731, 3240, 0, 0, 0, 0, 0, 0, 12, 175, 0, 0);
INSERT INTO `ss_meta_players` VALUES(362, 9, 1, 48, 28, 738, 0, 'HyPE|GDM', 0, 0, 8, 72, 0, 0, 0, 0, 274, 1065, 0, 0, 660, 4320, 0, 0, 6, 237, 12, 38);
INSERT INTO `ss_meta_players` VALUES(362, 10, 0, 9, 34, 32, 0, 'unad.001', 0, 0, 0, 0, 0, 0, 28, 770, 199, 525, 4, 80, 148, 696, 0, 0, 10, 65, 5, 19);
INSERT INTO `ss_meta_players` VALUES(362, 11, 0, 2, 6, 35, 0, 'mark13', 0, 0, 0, 0, 0, 0, 18, 435, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(363, 0, 0, 14, 5, 223, 1, 'MaryAnn', 0, 0, 8, 0, 0, 0, 0, 0, 427, 1740, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(363, 1, 6, 45, 36, 1111, 1, '|KH|32', 0, 0, 0, 0, 0, 0, 109, 5715, 0, 0, 0, 0, 0, 0, 0, 0, 40, 745, 0, 0);
INSERT INTO `ss_meta_players` VALUES(363, 2, 0, 1, 5, -8, 1, 'AsSoMNiak', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 312, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(363, 3, 0, 15, 44, 96, 0, 'rompeanos', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 383, 2352, 0, 0, 2, 7, 0, 0);
INSERT INTO `ss_meta_players` VALUES(363, 4, 2, 44, 24, 883, 1, 'Teapot|', 6, 0, 0, 0, 0, 0, 0, 0, 920, 3795, 0, 0, 162, 1200, 0, 0, 20, 164, 45, 285);
INSERT INTO `ss_meta_players` VALUES(363, 5, 6, 22, 39, 840, 0, 'ibr', 0, 0, 0, 0, 0, 0, 52, 2090, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(363, 6, 0, 23, 15, 276, 1, 'V3RUC', 0, 0, 23, 54, 0, 0, 0, 0, 0, 0, 0, 0, 383, 2688, 0, 0, 26, 651, 28, 190);
INSERT INTO `ss_meta_players` VALUES(363, 7, 2, 20, 23, 499, 1, 'SDBS', 0, 0, 0, 0, 0, 0, 66, 2730, 0, 0, 0, 0, 0, 0, 0, 0, 8, 178, 0, 0);
INSERT INTO `ss_meta_players` VALUES(363, 8, 0, 37, 24, 634, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 731, 3240, 0, 0, 0, 0, 0, 0, 12, 175, 0, 0);
INSERT INTO `ss_meta_players` VALUES(363, 9, 1, 48, 28, 738, 0, 'HyPE|GDM', 0, 0, 8, 72, 0, 0, 0, 0, 274, 1065, 0, 0, 660, 4320, 0, 0, 6, 237, 12, 38);
INSERT INTO `ss_meta_players` VALUES(363, 10, 0, 9, 34, 32, 0, 'unad.001', 0, 0, 0, 0, 0, 0, 28, 770, 199, 525, 4, 80, 148, 696, 0, 0, 10, 65, 5, 19);
INSERT INTO `ss_meta_players` VALUES(363, 11, 0, 2, 6, 35, 0, 'mark13', 0, 0, 0, 0, 0, 0, 18, 435, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(364, 0, 0, 4, 3, 44, 1, 'MaryAnn', 1, 0, 0, 0, 0, 0, 0, 0, 164, 675, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(364, 1, 0, 6, 4, 76, 1, '|KH|32', 0, 0, 0, 0, 0, 0, 19, 820, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(364, 3, 0, 1, 3, -2, 0, 'rompeanos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 96, 0, 0, 2, 50, 0, 0);
INSERT INTO `ss_meta_players` VALUES(364, 4, 0, 3, 3, 29, 1, 'Teapot|', 0, 0, 0, 0, 0, 0, 0, 0, 72, 390, 0, 0, 0, 0, 0, 0, 0, 0, 26, 190);
INSERT INTO `ss_meta_players` VALUES(364, 5, 0, 0, 1, -4, 0, 'ibr', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(364, 6, 0, 6, 1, 69, 1, 'V3RUC', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 67, 504, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(364, 7, 0, 0, 0, 0, 1, 'SDBS', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(364, 8, 0, 4, 2, 103, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 63, 330, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(364, 9, 0, 2, 5, 5, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 26, 105, 0, 0, 51, 288, 0, 0, 3, 172, 0, 0);
INSERT INTO `ss_meta_players` VALUES(364, 10, 0, 1, 5, 23, 0, 'unad.001', 0, 0, 0, 0, 0, 0, 0, 0, 115, 360, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(364, 11, 0, 3, 3, 64, 0, 'mark13', 0, 0, 0, 0, 0, 0, 16, 530, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 0, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 1, 0, 9, 2, 137, 0, 'ThePinkOne', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 2, 0, 9, 28, 71, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 3, 0, 5, 12, 23, 1, 'fuidecama', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 4, 2, 33, 24, 515, 0, 'SICARIOMEXICANO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 5, 0, 32, 46, 130, 1, 'HITMAN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 6, 2, 40, 22, 876, 1, 'luc', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 7, 0, 0, 1, -4, 1, 'acea', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 8, 0, 8, 26, 9, 1, 'Patriot1917', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 9, 1, 49, 24, 617, 0, 'trem.bala', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 10, 0, 4, 5, 132, 1, 'Goatboy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 11, 0, 0, 1, -4, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(365, 17, 2, 31, 31, 606, 0, 'GUAYASAMIN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 1, 0, 9, 3, 150, 0, 'ThePinkOne', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 2, 0, 9, 29, 67, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 3, 0, 5, 13, 10, 1, 'fuidecama', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 4, 2, 35, 25, 567, 0, 'SICARIOMEXICANO', 0, 0, 0, 0, 0, 0, 6, 195, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 5, 0, 33, 47, 138, 1, 'HITMAN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 6, 2, 41, 22, 958, 1, 'luc', 0, 0, 0, 0, 0, 0, 5, 165, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 7, 0, 0, 2, 11, 1, 'acea', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 8, 0, 8, 27, 5, 1, 'Patriot1917', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 9, 1, 49, 25, 613, 0, 'trem.bala', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 160, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 10, 0, 6, 5, 166, 1, 'Goatboy', 0, 0, 0, 0, 5, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 11, 0, 0, 1, -4, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(366, 17, 2, 32, 32, 612, 0, 'GUAYASAMIN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 0, 0, 1, 1, 44, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 24, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 1, 0, 11, 4, 191, 0, 'ThePinkOne', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 47, 360, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 2, 0, 10, 30, 78, 0, 'unarmed', 1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 137, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 3, 0, 5, 13, 10, 1, 'fuidecama', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 45, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 4, 2, 37, 25, 587, 0, 'SICARIOMEXICANO', 0, 0, 0, 0, 0, 0, 11, 410, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 5, 0, 33, 49, 130, 1, 'HITMAN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23, 168, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 6, 3, 41, 23, 1032, 1, 'luc', 0, 0, 0, 0, 0, 0, 6, 235, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 7, 0, 0, 3, 7, 1, 'acea', 0, 0, 0, 0, 4, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 8, 0, 9, 27, 51, 1, 'Patriot1917', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 40, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 9, 1, 49, 25, 603, 0, 'trem.bala', 0, 0, 4, 36, 0, 0, 0, 0, 0, 0, 8, 560, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 10, 0, 6, 7, 158, 1, 'Goatboy', 0, 0, 0, 0, 9, 180, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 11, 0, 0, 1, -4, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(367, 17, 2, 33, 33, 630, 0, 'GUAYASAMIN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 49, 264, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(368, 0, 1, 0, 1, 22, 0, 'topgunsarg', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(368, 1, 1, -1, 1, 19, 0, 'PlasmaToast', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(368, 2, 0, 0, 1, -4, 1, 'Ghelere', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(368, 3, 0, 0, 0, 0, 1, 'GRIMM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(368, 4, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 0, 0, 0, 0, 0, 1, 'unad.001', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 1, 0, 1, 0, 21, 0, 'ThePinkOne', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 95, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 2, 0, 0, 0, 0, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 3, 0, 1, 0, 10, 0, 'MEATBOY!!!', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 4, 0, 1, 1, 17, 0, 'SICARIOMEXICANO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 5, 0, 0, 0, 0, 1, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 6, 0, 1, 1, 6, 1, 'luc', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 7, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 8, 0, 0, 1, -4, 1, 'Patriot1917', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 9, 0, 1, 1, 6, 0, 'trem.bala', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 10, 0, 1, 1, 6, 1, '(@_@)Boss', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(369, 17, 0, 0, 1, -4, 1, 'GUAYASAMIN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 0, 0, 0, 2, -8, 1, 'unad.001', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 1, 0, 3, 1, 51, 0, 'ThePinkOne', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 288, 0, 0, 0, 95, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 2, 0, 0, 2, -8, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 3, 0, 1, 1, 6, 0, 'MEATBOY!!!', 0, 0, 0, 0, 0, 0, 8, 95, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 4, 0, 5, 1, 71, 0, 'SICARIOMEXICANO', 0, 0, 0, 0, 0, 0, 4, 250, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 5, 0, 1, 0, 10, 1, 'DES|byrus', 1, 50, 0, 0, 0, 0, 0, 0, 39, 135, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 6, 0, 1, 4, -6, 1, 'luc', 0, 0, 0, 0, 0, 0, 5, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 7, 1, 2, 0, 106, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 408, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 8, 0, 0, 2, -8, 1, 'Patriot1917', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 9, 0, 1, 2, 2, 0, 'trem.bala', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 10, 0, 2, 2, 14, 1, '(@_@)Boss', 0, 0, 0, 0, 0, 0, 7, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 11, 0, 0, 0, 0, 0, 'Cole', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 12, 0, 0, 0, 0, 1, 'Ryan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(370, 17, 0, 3, 2, 70, 1, 'GUAYASAMIN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 53, 360, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(371, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(372, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(373, 0, 1, 4, 4, 32, 0, 'topgunsarg', 0, 0, 0, 0, 0, 0, 1, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(373, 1, 1, -1, 3, 2, 0, 'PlasmaToast', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(373, 2, 0, -1, 4, -16, 1, 'Ghelere', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(373, 3, 0, 2, 6, 4, 1, 'GRIMM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(373, 4, 0, 0, 2, -8, 0, '#FULKRUM#', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(373, 5, 1, 1, 0, 90, 1, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(373, 6, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(374, 0, 1, 5, 6, 8, 0, 'topgunsarg', 0, 0, 0, 0, 0, 0, 13, 670, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(374, 1, 1, -1, 4, 12, 0, 'PlasmaToast', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 216, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(374, 2, 0, -1, 6, -24, 1, 'Ghelere', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(374, 3, 0, 2, 6, 4, 1, 'GRIMM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(374, 4, 0, 0, 4, -16, 0, '#FULKRUM#', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(374, 5, 1, 1, 2, 104, 1, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 123, 0, 0);
INSERT INTO `ss_meta_players` VALUES(374, 6, 1, 3, 0, 117, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 288, 0, 0, 2, 204, 0, 0);
INSERT INTO `ss_meta_players` VALUES(374, 7, 0, 0, 1, -4, 0, '|AoX|.Kaka', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(375, 0, 1, 6, 6, 40, 0, 'topgunsarg', 0, 0, 0, 0, 0, 0, 4, 265, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(375, 1, 1, -1, 8, -4, 0, 'PlasmaToast', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 45, 384, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(375, 2, 0, -1, 7, -28, 1, 'Ghelere', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(375, 3, 0, 2, 7, 14, 1, 'GRIMM', 0, 0, 0, 0, 0, 0, 7, 195, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(375, 4, 0, 1, 0, 10, 0, 'WSSSA', 0, 0, 0, 0, 0, 0, 3, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(375, 5, 1, 2, 3, 132, 1, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 17, 45, 0, 0, 0, 0, 0, 0, 14, 183, 0, 0);
INSERT INTO `ss_meta_players` VALUES(375, 6, 1, 7, 1, 163, 1, 'HyPE|GDM', 0, 0, 9, 90, 0, 0, 0, 0, 0, 0, 0, 0, 114, 768, 0, 0, 2, 204, 0, 0);
INSERT INTO `ss_meta_players` VALUES(375, 7, 0, -1, 4, -24, 0, '|AoX|.Kaka', 1, 0, 0, 0, 0, 0, 3, 180, 0, 0, 4, 80, 0, 0, 0, 0, 6, 71, 0, 0);
INSERT INTO `ss_meta_players` VALUES(376, 0, 0, -1, 9, -79, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(376, 1, 0, 3, 8, 14, 1, 'AntonioAsesix10', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(376, 2, 1, 7, 4, 132, 0, 'young', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(376, 3, 0, 2, 4, 4, 0, 'Meine', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(376, 4, 2, 8, 0, 195, 0, 'ButtDominator', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(376, 5, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(376, 18, 10, 14, 4, 569, 1, 'luc', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(377, 0, 0, -1, 11, -87, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(377, 1, 0, 3, 10, 6, 1, 'AntonioAsesix10', 0, 0, 0, 0, 0, 0, 2, 65, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(377, 2, 1, 9, 5, 150, 0, 'young', 0, 0, 0, 0, 0, 0, 3, 125, 0, 0, 0, 0, 0, 0, 0, 0, 0, 124, 0, 0);
INSERT INTO `ss_meta_players` VALUES(377, 3, 0, 3, 5, 10, 0, 'Meine', 0, 0, 8, 54, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(377, 4, 2, 8, 2, 195, 0, 'ButtDominator', 0, 0, 0, 0, 0, 0, 4, 140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(377, 5, 1, 3, 0, 85, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 0, 0, 0, 0, 0, 38, 209);
INSERT INTO `ss_meta_players` VALUES(377, 18, 10, 18, 6, 622, 1, 'luc', 0, 0, 0, 0, 0, 0, 8, 475, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(378, 0, 0, 0, 13, -85, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 168, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(378, 1, 0, 3, 11, 18, 1, 'AntonioAsesix10', 0, 0, 0, 0, 0, 0, 3, 65, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(378, 2, 1, 10, 6, 164, 0, 'young', 0, 0, 0, 0, 0, 0, 6, 200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 124, 0, 0);
INSERT INTO `ss_meta_players` VALUES(378, 4, 3, 9, 2, 280, 0, 'ButtDominator', 0, 0, 0, 0, 0, 0, 8, 270, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(378, 5, 1, 7, 0, 131, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 57, 456, 0, 0, 0, 0, 38, 209);
INSERT INTO `ss_meta_players` VALUES(378, 18, 10, 19, 9, 634, 1, 'luc', 0, 0, 0, 0, 0, 0, 16, 750, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(379, 0, 0, 0, 13, -85, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 64, 168, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(379, 1, 0, 3, 11, 18, 1, 'AntonioAsesix10', 0, 0, 0, 0, 0, 0, 3, 65, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(379, 2, 1, 10, 6, 164, 0, 'young', 0, 0, 0, 0, 0, 0, 6, 200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 124, 0, 0);
INSERT INTO `ss_meta_players` VALUES(379, 4, 3, 9, 2, 280, 0, 'ButtDominator', 0, 0, 0, 0, 0, 0, 8, 270, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(379, 5, 1, 7, 0, 131, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 57, 456, 0, 0, 0, 0, 38, 209);
INSERT INTO `ss_meta_players` VALUES(379, 18, 10, 19, 9, 634, 1, 'luc', 0, 0, 0, 0, 0, 0, 16, 750, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(380, 0, 0, 0, 13, -85, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 69, 168, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(380, 1, 0, 3, 11, 18, 1, 'AntonioAsesix10', 0, 0, 0, 0, 0, 0, 3, 65, 0, 0, 2, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(380, 2, 1, 10, 6, 164, 0, 'young', 0, 0, 0, 0, 0, 0, 6, 200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 124, 0, 0);
INSERT INTO `ss_meta_players` VALUES(380, 4, 3, 9, 2, 280, 0, 'ButtDominator', 0, 0, 0, 0, 0, 0, 8, 270, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(380, 5, 1, 7, 0, 131, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 57, 456, 0, 0, 0, 0, 38, 209);
INSERT INTO `ss_meta_players` VALUES(380, 18, 10, 19, 9, 634, 1, 'luc', 0, 0, 0, 0, 0, 0, 16, 750, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(381, 0, 10, 15, 8, 561, 1, '.Lw|{!n\\\\/@L!D}|', 0, 0, 0, 0, 0, 0, 0, 0, 7, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(381, 1, 0, 1, 0, 20, 0, 'Metabee.', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(381, 2, 2, 7, 13, 173, 0, 'BrutuX', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(381, 3, 0, 0, 0, 0, 0, 'ibr', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(381, 4, 0, 7, 5, 78, 1, 'CL|Snowman"', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(381, 5, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(382, 0, 10, 16, 11, 566, 1, '.Lw|{!n\\\\/@L!D}|', 0, 0, 0, 0, 0, 0, 0, 0, 25, 120, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(382, 1, 0, 3, 0, 60, 0, 'Metabee.', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 61, 432, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(382, 2, 2, 9, 16, 176, 0, 'BrutuX', 0, 0, 1, 18, 0, 0, 0, 0, 0, 0, 8, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(382, 3, 1, 3, 2, 80, 0, 'ibr', 0, 0, 0, 0, 0, 0, 9, 330, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(382, 4, 0, 11, 8, 122, 1, 'CL|Snowman"', 2, 50, 13, 36, 0, 0, 0, 0, 0, 0, 9, 640, 0, 0, 0, 0, 2, 100, 0, 0);
INSERT INTO `ss_meta_players` VALUES(382, 5, 0, 2, 3, 8, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(382, 7, 0, 0, 0, 0, 1, '-Ls^.Sw4G*', 0, 0, 0, 0, 0, 0, 0, 0, 16, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(382, 8, 0, 0, 1, -4, 0, 'Seacowboy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(383, 0, 10, 19, 13, 604, 1, '.Lw|{!n\\\\/@L!D}|', 0, 0, 9, 54, 0, 0, 0, 0, 25, 120, 12, 400, 55, 336, 0, 0, 4, 82, 0, 0);
INSERT INTO `ss_meta_players` VALUES(383, 1, 1, 3, 1, 150, 4, 'Metabee.', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 63, 432, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(383, 2, 2, 12, 22, 203, 0, 'BrutuX', 1, 0, 5, 54, 0, 0, 0, 0, 0, 0, 25, 1040, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(383, 3, 1, 4, 8, 93, 0, 'ibr', 0, 0, 0, 0, 0, 0, 15, 490, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(383, 4, 0, 17, 9, 175, 1, 'CL|Snowman"', 2, 50, 31, 162, 0, 0, 0, 0, 0, 0, 20, 1360, 0, 0, 0, 0, 8, 100, 0, 0);
INSERT INTO `ss_meta_players` VALUES(383, 5, 1, 8, 3, 197, 1, 'HyPE|GDM', 0, 0, 4, 18, 0, 0, 0, 0, 0, 0, 0, 0, 121, 672, 0, 0, 2, 11, 30, 171);
INSERT INTO `ss_meta_players` VALUES(383, 7, 1, 7, 0, 221, 1, '-Ls^.Sw4G*', 0, 0, 0, 0, 0, 0, 0, 0, 98, 510, 0, 0, 0, 0, 0, 0, 10, 194, 0, 0);
INSERT INTO `ss_meta_players` VALUES(383, 8, 0, 0, 7, -28, 0, 'Seacowboy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(383, 9, 1, 0, 0, 35, 1, 'Smeagol', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(383, 10, 0, 0, 1, -4, 0, 'bold', 0, 0, 0, 0, 0, 0, 2, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(384, 0, 10, 29, 20, 695, 1, '.Lw|{!n\\\\/@L!D}|', 0, 0, 21, 162, 0, 0, 0, 0, 98, 480, 17, 640, 137, 864, 0, 0, 12, 144, 0, 0);
INSERT INTO `ss_meta_players` VALUES(384, 1, 1, 3, 1, 150, 4, 'Metabee.', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 63, 432, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(384, 2, 2, 16, 33, 253, 0, 'BrutuX', 1, 0, 5, 54, 0, 0, 0, 0, 139, 675, 35, 1120, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(384, 3, 0, 0, 1, 0, 0, 'SLOVAKIA', 0, 0, 0, 0, 0, 0, 0, 0, 7, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(384, 4, 1, 27, 12, 390, 1, 'CL|Snowman"', 4, 100, 43, 270, 0, 0, 0, 0, 0, 0, 34, 2320, 0, 0, 0, 0, 14, 203, 14, 19);
INSERT INTO `ss_meta_players` VALUES(384, 5, 1, 21, 9, 365, 0, 'HyPE|GDM', 0, 0, 4, 18, 0, 0, 0, 0, 0, 0, 0, 0, 293, 2184, 0, 0, 3, 11, 60, 247);
INSERT INTO `ss_meta_players` VALUES(384, 6, 0, 4, 5, 20, 1, 'EtienneL2', 0, 0, 0, 0, 0, 0, 0, 0, 126, 630, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(384, 7, 4, 18, 4, 615, 1, '-Ls^.Sw4G*', 1, 50, 0, 0, 0, 0, 0, 0, 314, 1590, 0, 0, 0, 0, 0, 0, 16, 394, 0, 0);
INSERT INTO `ss_meta_players` VALUES(384, 8, 0, 0, 14, -56, 0, 'Seacowboy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(384, 9, 0, 5, 2, 147, 1, 'uRs|PORTUGAL', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 53, 600, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(384, 10, 0, 3, 11, 17, 0, 'bold', 0, 0, 0, 0, 0, 0, 2, 20, 221, 630, 0, 0, 0, 0, 0, 0, 6, 116, 0, 0);
INSERT INTO `ss_meta_players` VALUES(384, 11, 1, 2, 1, 120, 1, 'Jeqqu', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(385, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 0, 1, 4, 6, 146, 0, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 38, 120, 0, 0, 0, 0, 0, 0, 2, 21, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 1, 0, 9, 4, 167, 1, 'HyPE|GDM', 3, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 130, 1128, 0, 0, 1, 25, 23, 190);
INSERT INTO `ss_meta_players` VALUES(386, 2, 0, 10, 4, 133, 1, 'Bench.{TyD}', 0, 0, 0, 0, 0, 0, 0, 0, 102, 285, 0, 0, 5, 0, 0, 0, 8, 112, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 3, 0, 1, 9, 12, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 78, 264, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 4, 0, 0, 0, 0, 1, '{ric}', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 5, 0, 9, 7, 112, 0, '|40+|Capt_Tuna', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 13, 560, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 6, 0, 4, 3, 45, 0, 'ElCre#M|A#', 3, 50, 0, 0, 0, 0, 0, 0, 102, 540, 0, 0, 0, 0, 0, 0, 2, 37, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 7, 0, 5, 4, 50, 0, 'EBOOT', 0, 0, 0, 0, 0, 0, 0, 0, 79, 345, 0, 0, 0, 0, 0, 0, 2, 157, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 8, 0, 2, 6, -4, 1, 'pj', 0, 0, 0, 0, 0, 0, 0, 0, 53, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 9, 1, 15, 4, 249, 0, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 172, 705, 0, 0, 0, 0, 0, 0, 9, 146, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 10, 0, 1, 4, -6, 0, 'TwixEmma', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 36, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 11, 0, 2, 2, 12, 1, 'CL|Snowman', 0, 0, 0, 0, 4, 180, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 2, 0, 1, 19);
INSERT INTO `ss_meta_players` VALUES(386, 12, 0, 0, 0, 0, 0, 'haf', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(386, 13, 0, 0, 0, 0, 4, 'y.p', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(387, 0, 1, 5, 9, 158, 0, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 125, 360, 0, 0, 0, 0, 0, 0, 4, 118, 0, 0);
INSERT INTO `ss_meta_players` VALUES(387, 1, 0, 17, 7, 288, 1, 'HyPE|GDM', 3, 50, 0, 0, 0, 0, 0, 0, 141, 690, 0, 0, 146, 1344, 0, 0, 3, 25, 23, 190);
INSERT INTO `ss_meta_players` VALUES(387, 2, 0, 14, 5, 171, 1, 'Bench.{TyD}', 0, 0, 0, 0, 0, 0, 11, 470, 102, 285, 0, 0, 5, 0, 0, 0, 12, 112, 0, 0);
INSERT INTO `ss_meta_players` VALUES(387, 3, 0, 1, 10, 8, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 118, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(387, 4, 0, 2, 3, 20, 1, '{ric}', 0, 0, 0, 0, 0, 0, 7, 175, 0, 0, 0, 0, 65, 384, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(387, 5, 0, 11, 9, 155, 0, '|40+|Capt_Tuna', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 17, 800, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(387, 7, 0, 11, 5, 111, 0, 'EBOOT', 0, 0, 5, 36, 0, 0, 0, 0, 164, 810, 0, 0, 0, 0, 0, 0, 8, 213, 0, 0);
INSERT INTO `ss_meta_players` VALUES(387, 8, 0, 1, 3, 0, 1, 'drekkett', 0, 0, 0, 0, 0, 0, 8, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(387, 9, 1, 16, 9, 229, 0, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 296, 1185, 0, 0, 0, 0, 0, 0, 11, 146, 0, 0);
INSERT INTO `ss_meta_players` VALUES(387, 10, 0, 3, 9, 11, 0, 'TwixEmma', 0, 0, 0, 0, 0, 0, 10, 405, 0, 0, 0, 0, 36, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(387, 11, 1, 6, 4, 192, 1, 'CL|Snowman', 0, 0, 0, 0, 17, 600, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 10, 0, 1, 19);
INSERT INTO `ss_meta_players` VALUES(387, 12, 0, 0, 4, -16, 0, 'haf', 0, 0, 0, 0, 0, 0, 0, 0, 37, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(387, 13, 0, 2, 2, 36, 1, 'y.p', 0, 0, 9, 36, 0, 0, 0, 0, 0, 0, 6, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(388, 0, 0, 0, 0, 0, 1, '=SA?Million', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(388, 1, 0, 0, 0, 0, 4, '=SA=Furios', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(388, 2, 0, 0, 0, 0, 4, 'CL|Snowman', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(388, 3, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(389, 0, 0, 0, 0, 0, 1, '=SA?Million', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(389, 1, 0, 0, 0, 0, 0, '=SA=Furios', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(389, 2, 0, -1, 1, -4, 4, 'CL|Snowman', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(389, 3, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(389, 4, 0, 0, 0, 0, 1, 'HyPE|SwellGuy', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(390, 0, 0, 0, 0, 0, 1, '.aK|TiAg0', 0, 0, 2, 36, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 0, 0, 10, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(390, 1, 0, 0, 3, -12, 0, '=SA=#2', 0, 0, 0, 0, 0, 0, 0, 0, 18, 0, 0, 0, 10, 0, 0, 0, 10, 60, 0, 0);
INSERT INTO `ss_meta_players` VALUES(390, 2, 0, 0, 0, 0, 4, 'Zadig', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(390, 3, 0, 0, 0, 0, 0, 'CL|Snowman', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(390, 4, 0, 1, 0, 15, 1, 'HyPE|SwellGuy', 1, 0, 0, 0, 0, 0, 0, 0, 40, 240, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(390, 5, 0, 2, 0, 15, 0, '=SA=1*', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(390, 6, 0, 2, 1, 16, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 216, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(391, 0, 0, 4, 5, 10, 0, '.aK|TiAg0', 0, 0, 6, 54, 0, 0, 0, 0, 0, 0, 30, 560, 0, 0, 0, 0, 16, 0, 27, 0);
INSERT INTO `ss_meta_players` VALUES(391, 1, 0, 2, 7, -8, 1, '=SA=#2"', 1, 50, 3, 18, 0, 0, 0, 0, 18, 0, 6, 160, 47, 24, 0, 0, 20, 111, 0, 0);
INSERT INTO `ss_meta_players` VALUES(391, 2, 0, -1, 1, -4, 4, 'Zadig', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(391, 3, 0, 0, 1, -4, 1, '=SniperAssasin=', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(391, 4, 0, 1, 0, 15, 0, 'HyPE|SwellGuy', 1, 0, 0, 0, 0, 0, 0, 0, 40, 240, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(391, 5, 0, 9, 8, 18, 1, '=SA=#2*', 3, 100, 12, 54, 0, 0, 0, 0, 0, 0, 21, 1760, 20, 0, 0, 0, 8, 215, 0, 0);
INSERT INTO `ss_meta_players` VALUES(391, 6, 0, 8, 5, 55, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 696, 0, 0, 1, 208, 51, 380);
INSERT INTO `ss_meta_players` VALUES(392, 0, 3, 36, 39, 493, 0, '.aK|TiAg0', 0, 0, 54, 324, 0, 0, 0, 0, 299, 990, 84, 3520, 79, 168, 0, 0, 60, 277, 0, 0);
INSERT INTO `ss_meta_players` VALUES(392, 1, 1, 40, 37, 423, 1, '=SA=#2"', 0, 0, 31, 126, 0, 0, 0, 0, 0, 0, 0, 0, 987, 5016, 0, 0, 50, 368, 45, 152);
INSERT INTO `ss_meta_players` VALUES(392, 2, 0, 0, 0, 0, 4, 'Zadig', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(392, 3, 3, 33, 38, 441, 1, '=SniperAssasin=', 2, 0, 95, 612, 4, 180, 0, 0, 0, 0, 100, 4320, 0, 0, 0, 0, 22, 285, 45, 228);
INSERT INTO `ss_meta_players` VALUES(392, 4, 2, 44, 44, 566, 0, 'HyPE|SwellGuy', 0, 0, 8, 72, 0, 0, 0, 0, 1427, 6150, 0, 0, 0, 0, 0, 0, 8, 37, 37, 171);
INSERT INTO `ss_meta_players` VALUES(392, 5, 4, 46, 44, 708, 1, '=SA=#1*', 0, 0, 15, 36, 0, 0, 0, 0, 0, 0, 0, 0, 1049, 7176, 0, 0, 6, 147, 25, 114);
INSERT INTO `ss_meta_players` VALUES(392, 6, 0, 40, 37, 439, 0, 'HyPE|GDM', 0, 0, 5, 18, 0, 0, 0, 0, 31, 135, 0, 0, 795, 4968, 0, 0, 17, 565, 9, 57);
INSERT INTO `ss_meta_players` VALUES(393, 1, 1, 27, 20, 327, 1, '=SA=#2"', 0, 0, 18, 54, 0, 0, 0, 0, 0, 0, 0, 0, 510, 3096, 0, 0, 26, 417, 0, 0);
INSERT INTO `ss_meta_players` VALUES(393, 3, 1, 11, 26, 70, 1, '=SniperAssasin=', 2, 50, 58, 378, 0, 0, 0, 0, 0, 0, 52, 1840, 0, 0, 0, 0, 20, 246, 0, 0);
INSERT INTO `ss_meta_players` VALUES(393, 4, 0, 27, 25, 318, 0, 'HyPE|SwellGuy', 0, 0, 0, 0, 0, 0, 0, 0, 764, 3165, 0, 0, 57, 408, 0, 0, 4, 112, 0, 0);
INSERT INTO `ss_meta_players` VALUES(393, 6, 1, 22, 21, 258, 0, 'HyPE|GDM', 0, 0, 8, 18, 0, 0, 0, 0, 20, 120, 0, 0, 363, 1800, 0, 0, 1, 0, 113, 437);
INSERT INTO `ss_meta_players` VALUES(394, 1, 1, 30, 32, 349, 1, '=SA=#2"', 0, 0, 17, 54, 0, 0, 0, 0, 0, 0, 0, 0, 586, 3312, 0, 0, 32, 501, 67, 399);
INSERT INTO `ss_meta_players` VALUES(394, 3, 3, 33, 38, 386, 1, '=SniperAssasin=', 3, 0, 30, 180, 0, 0, 0, 0, 0, 0, 25, 1120, 543, 2904, 0, 0, 10, 17, 0, 0);
INSERT INTO `ss_meta_players` VALUES(394, 4, 1, 40, 31, 469, 0, 'HyPE|SwellGuy', 2, 100, 30, 162, 0, 0, 0, 0, 0, 0, 0, 0, 775, 5016, 0, 0, 4, 0, 19, 38);
INSERT INTO `ss_meta_players` VALUES(394, 6, 5, 29, 31, 484, 0, 'HyPE|GDM', 0, 0, 15, 90, 0, 0, 0, 0, 0, 0, 0, 0, 654, 3720, 0, 0, 1, 79, 0, 0);
INSERT INTO `ss_meta_players` VALUES(395, 1, 2, 42, 44, 537, 1, '=SA=#2"', 0, 0, 25, 90, 0, 0, 0, 0, 0, 0, 0, 0, 839, 4512, 0, 0, 46, 737, 83, 494);
INSERT INTO `ss_meta_players` VALUES(395, 3, 4, 44, 52, 511, 1, '=SniperAssasin=', 3, 0, 36, 216, 0, 0, 0, 0, 0, 0, 25, 1120, 833, 4368, 0, 0, 12, 17, 0, 0);
INSERT INTO `ss_meta_players` VALUES(395, 4, 1, 54, 43, 618, 0, 'HyPE|SwellGuy', 3, 150, 45, 270, 0, 0, 0, 0, 259, 1125, 0, 0, 898, 5664, 0, 0, 8, 82, 19, 38);
INSERT INTO `ss_meta_players` VALUES(395, 6, 6, 41, 42, 645, 0, 'HyPE|GDM', 0, 0, 15, 90, 0, 0, 0, 0, 38, 150, 0, 0, 870, 4704, 0, 0, 3, 79, 14, 95);
INSERT INTO `ss_meta_players` VALUES(396, 1, 3, 48, 49, 616, 1, '=SA=#2"', 0, 0, 25, 90, 0, 0, 2, 20, 0, 0, 0, 0, 933, 5208, 0, 0, 46, 737, 97, 551);
INSERT INTO `ss_meta_players` VALUES(396, 3, 4, 48, 56, 576, 1, '=SniperAssasin=', 3, 0, 36, 216, 0, 0, 0, 0, 0, 0, 25, 1120, 980, 4920, 0, 0, 12, 17, 0, 0);
INSERT INTO `ss_meta_players` VALUES(396, 4, 1, 60, 49, 686, 0, 'HyPE|SwellGuy', 3, 150, 45, 270, 0, 0, 0, 0, 419, 1740, 0, 0, 898, 5664, 0, 0, 10, 82, 19, 38);
INSERT INTO `ss_meta_players` VALUES(396, 6, 6, 44, 46, 679, 0, 'HyPE|GDM', 0, 0, 15, 90, 0, 0, 0, 0, 38, 150, 0, 0, 940, 5184, 0, 0, 3, 79, 14, 95);
INSERT INTO `ss_meta_players` VALUES(397, 1, 3, 49, 50, 624, 1, '=SA=#2"', 0, 0, 25, 90, 0, 0, 2, 20, 0, 0, 0, 0, 947, 5304, 0, 0, 48, 737, 97, 551);
INSERT INTO `ss_meta_players` VALUES(397, 3, 4, 48, 57, 572, 1, '=SniperAssasin=', 3, 0, 36, 216, 0, 0, 0, 0, 0, 0, 25, 1120, 987, 4944, 0, 0, 12, 17, 0, 0);
INSERT INTO `ss_meta_players` VALUES(397, 4, 1, 61, 49, 702, 0, 'HyPE|SwellGuy', 3, 150, 45, 270, 0, 0, 0, 0, 437, 1785, 0, 0, 898, 5664, 0, 0, 10, 82, 19, 38);
INSERT INTO `ss_meta_players` VALUES(397, 6, 6, 45, 47, 690, 0, 'HyPE|GDM', 0, 0, 15, 90, 0, 0, 0, 0, 38, 150, 0, 0, 959, 5256, 0, 0, 3, 79, 14, 95);
INSERT INTO `ss_meta_players` VALUES(398, 1, 3, 49, 50, 624, 1, '=SA=#2"', 0, 0, 25, 90, 0, 0, 2, 20, 0, 0, 0, 0, 947, 5304, 0, 0, 48, 737, 97, 551);
INSERT INTO `ss_meta_players` VALUES(398, 3, 4, 48, 57, 572, 1, '=SniperAssasin=', 3, 0, 36, 216, 0, 0, 0, 0, 0, 0, 25, 1120, 987, 4944, 0, 0, 12, 17, 0, 0);
INSERT INTO `ss_meta_players` VALUES(398, 4, 1, 61, 49, 702, 0, 'HyPE|SwellGuy', 3, 150, 45, 270, 0, 0, 0, 0, 437, 1785, 0, 0, 898, 5664, 0, 0, 10, 82, 19, 38);
INSERT INTO `ss_meta_players` VALUES(398, 6, 6, 45, 47, 690, 0, 'HyPE|GDM', 0, 0, 15, 90, 0, 0, 0, 0, 38, 150, 0, 0, 959, 5256, 0, 0, 3, 79, 14, 95);
INSERT INTO `ss_meta_players` VALUES(399, 1, 5, 38, 39, 528, 0, '=SniperAliance=', 1, 50, 20, 72, 0, 0, 0, 0, 13, 60, 4, 0, 881, 4632, 0, 0, 56, 193, 0, 0);
INSERT INTO `ss_meta_players` VALUES(399, 3, 5, 34, 31, 543, 0, '=SniperAssasin=', 0, 0, 7, 18, 0, 0, 0, 0, 0, 0, 0, 0, 1019, 4776, 0, 0, 44, 287, 0, 0);
INSERT INTO `ss_meta_players` VALUES(399, 4, 5, 32, 37, 539, 1, 'HyPE|SwellGuy', 2, 50, 9, 36, 0, 0, 0, 0, 1028, 3675, 0, 0, 189, 672, 0, 0, 33, 54, 43, 228);
INSERT INTO `ss_meta_players` VALUES(399, 6, 4, 36, 36, 558, 1, 'HyPE|GDM', 0, 0, 10, 90, 0, 0, 0, 0, 14, 90, 0, 0, 818, 4704, 0, 0, 15, 114, 111, 665);
INSERT INTO `ss_meta_players` VALUES(400, 0, 0, 6, 11, 82, 0, 'argnuevo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(400, 1, 1, 20, 6, 374, 0, '[ED]Carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(400, 2, 0, 8, 15, 91, 0, '#M|A#TiO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(400, 3, 0, 7, 12, 69, 1, 'Jeses', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(400, 4, 0, 16, 8, 154, 0, 'FrT|Montana', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(400, 5, 1, 5, 13, 141, 1, 'Nicktou', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(400, 6, 0, 2, 2, 46, 1, '|AOD|Sniper', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 95);
INSERT INTO `ss_meta_players` VALUES(400, 7, 0, 11, 7, 132, 0, 'CALLOSE', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(400, 8, 1, 3, 6, 94, 1, 'Foil_Shur_Fine', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(400, 9, 2, 12, 15, 301, 0, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(400, 10, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(400, 11, 2, 10, 7, 300, 1, 'EBOOT', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(401, 0, 0, 7, 11, 104, 0, 'argnuevo', 0, 0, 0, 0, 0, 0, 0, 0, 55, 180, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(401, 1, 1, 21, 7, 385, 0, '[ED]Carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 33, 192, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(401, 2, 0, 8, 16, 87, 0, '#M|A#TiO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(401, 3, 0, 8, 13, 75, 1, 'Jeses', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(401, 4, 0, 17, 9, 160, 0, 'FrT|Montana', 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 4, 80, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(401, 5, 1, 6, 14, 149, 1, 'Nicktou', 0, 0, 0, 0, 0, 0, 7, 190, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(401, 6, 0, 2, 3, 42, 1, '|AOD|Sniper', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 80, 0, 0, 0, 0, 0, 0, 15, 95);
INSERT INTO `ss_meta_players` VALUES(401, 7, 0, 12, 9, 136, 0, 'CALLOSE', 0, 0, 0, 0, 0, 0, 6, 310, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(401, 8, 1, 4, 7, 113, 1, 'Foil_Shur_Fine', 0, 0, 0, 0, 0, 0, 0, 0, 8, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(401, 9, 2, 11, 16, 277, 0, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 35, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(401, 10, 0, 0, 1, -4, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(401, 11, 2, 11, 7, 300, 1, 'EBOOT', 0, 0, 7, 18, 0, 0, 0, 0, 51, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(402, 0, 0, 0, 0, 0, 0, 'Drikce', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(402, 1, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(403, 0, 0, 1, 5, -26, 0, 'ANDERSON', 0, 0, 0, 0, 0, 0, 6, 155, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(403, 1, 0, 13, 1, 156, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 156, 1104, 0, 0, 8, 121, 76, 361);
INSERT INTO `ss_meta_players` VALUES(403, 2, 5, 19, 12, 258, 1, '|BrZ|*PsyPro|fr', 0, 0, 12, 72, 0, 0, 0, 0, 0, 0, 10, 960, 0, 0, 0, 0, 12, 85, 0, 0);
INSERT INTO `ss_meta_players` VALUES(403, 3, 2, 4, 3, 52, 1, 'bruder', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(403, 5, 0, 0, 0, 0, 4, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(403, 6, 0, 0, 4, -16, 1, 'Keen,Cmdr', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(404, 0, 0, 2, 7, -24, 0, 'ANDERSON', 0, 0, 0, 0, 0, 0, 13, 295, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(404, 1, 0, 17, 1, 208, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 216, 1440, 0, 0, 9, 223, 76, 361);
INSERT INTO `ss_meta_players` VALUES(404, 2, 5, 19, 15, 246, 1, '|BrZ|*PsyPro|fr', 0, 0, 16, 72, 0, 0, 0, 0, 0, 0, 13, 960, 0, 0, 0, 0, 12, 85, 0, 0);
INSERT INTO `ss_meta_players` VALUES(404, 3, 2, 4, 3, 52, 1, 'bruder', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(404, 4, 0, 0, 0, 0, 0, 'DES|Mitixx', 0, 0, 0, 0, 0, 0, 0, 0, 8, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(404, 5, 0, 0, 0, 0, 4, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(404, 6, 0, 2, 6, -4, 1, 'Keen,Cmdr', 0, 0, 0, 0, 10, 300, 0, 0, 0, 0, 0, 0, 46, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(405, 0, 0, 2, 8, -28, 0, 'ANDERSON', 0, 0, 0, 0, 0, 0, 14, 295, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(405, 1, 8, 24, 2, 465, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 280, 1848, 0, 0, 15, 568, 113, 513);
INSERT INTO `ss_meta_players` VALUES(405, 2, 0, 1, 4, -2, 1, 'sirilo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 168, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(405, 3, 0, 0, 0, 0, 1, '.45|Dam''s', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(405, 4, 0, 6, 2, 52, 0, 'DES|Mitixx', 0, 0, 0, 0, 0, 0, 0, 0, 156, 855, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(405, 6, 0, 2, 11, -24, 1, 'Keen,Cmdr', 0, 0, 0, 0, 14, 360, 0, 0, 0, 0, 0, 0, 46, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(405, 7, 0, 4, 3, -2, 1, 'LG*|Gundam', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 672, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(405, 8, 0, 3, 2, 68, 0, 'Phant0mPT', 0, 0, 0, 0, 0, 0, 0, 0, 73, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(405, 9, 0, 0, 1, -4, 0, 'DarkSkullsPT', 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(405, 10, 0, 1, 2, -15, 1, 'jj', 0, 0, 0, 0, 0, 0, 0, 0, 30, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(405, 11, 0, 0, 2, -8, 0, 'charlie', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(405, 12, 0, 0, 1, -14, 1, 'oldmen', 0, 0, 0, 0, 0, 0, 0, 0, 27, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 0, 3, 4, 16, 36, 0, 'ANDERSON', 0, 0, 0, 0, 0, 0, 15, 295, 169, 330, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 1, 13, 31, 7, 635, 0, 'HyPE|gdm', 0, 0, 3, 18, 0, 0, 0, 0, 52, 180, 0, 0, 375, 2424, 0, 0, 17, 568, 159, 684);
INSERT INTO `ss_meta_players` VALUES(406, 2, 0, 1, 9, -74, 1, 'sirilo', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 384, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 3, 2, 4, 3, 79, 1, '.Lw|Pr!nTuS|', 0, 0, 0, 0, 0, 0, 0, 0, 95, 525, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 4, 3, 18, 6, 360, 0, 'DES|Mitixx', 0, 0, 0, 0, 0, 0, 0, 0, 359, 1680, 0, 0, 0, 0, 0, 0, 8, 75, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 5, 0, -1, 3, -80, 1, 'unarmed', 0, 0, 14, 0, 7, 120, 13, 155, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 6, 0, 5, 15, 28, 1, 'Keen,Cmdr', 0, 0, 0, 0, 30, 720, 0, 0, 0, 0, 0, 0, 46, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 7, 3, 13, 6, 144, 1, 'LG*|Gundam', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 234, 1800, 0, 0, 14, 45, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 8, 1, 8, 7, 137, 0, 'Phant0mPT', 0, 0, 0, 0, 0, 0, 2, 30, 206, 840, 0, 0, 20, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 9, 0, 1, 7, -6, 0, 'DarkSkullsPT', 0, 0, 0, 0, 7, 120, 0, 0, 0, 0, 0, 0, 85, 216, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 10, 0, 2, 5, -12, 0, 'jj', 0, 0, 0, 0, 0, 0, 0, 0, 98, 285, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 11, 2, 3, 6, 62, 0, 'charlie', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 58, 648, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(406, 12, 2, 7, 8, 171, 1, 'oldmen', 0, 0, 0, 0, 0, 0, 1, 10, 229, 1155, 0, 0, 0, 0, 0, 0, 0, 0, 16, 95);
INSERT INTO `ss_meta_players` VALUES(406, 13, 2, 4, 3, 146, 1, 'bonanca', 0, 0, 0, 0, 0, 0, 6, 285, 0, 0, 0, 0, 0, 0, 0, 0, 8, 111, 0, 0);
INSERT INTO `ss_meta_players` VALUES(407, 0, 0, 1, 9, -5, 0, 'ANDERSON', 0, 0, 0, 0, 0, 0, 0, 0, 68, 165, 13, 240, 16, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(407, 1, 1, 19, 5, 313, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 16, 90, 0, 0, 279, 2184, 0, 0, 5, 63, 48, 209);
INSERT INTO `ss_meta_players` VALUES(407, 2, 0, 4, 10, 24, 1, 'sirilo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 70, 456, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(407, 3, 0, 7, 8, 60, 1, 'beshoy', 0, 0, 0, 0, 0, 0, 0, 0, 127, 615, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0);
INSERT INTO `ss_meta_players` VALUES(407, 4, 1, 19, 6, 352, 0, 'DES|Mitixx', 0, 0, 0, 0, 0, 0, 0, 0, 407, 2265, 0, 0, 0, 0, 0, 0, 12, 92, 0, 0);
INSERT INTO `ss_meta_players` VALUES(407, 5, 0, 0, 1, -4, 1, 'Separ', 0, 0, 0, 0, 0, 0, 0, 0, 12, 75, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(407, 6, 0, 5, 6, 27, 0, '|*MDA*|Klos', 2, 0, 24, 180, 0, 0, 0, 0, 0, 0, 7, 240, 0, 0, 0, 0, 4, 0, 16, 114);
INSERT INTO `ss_meta_players` VALUES(407, 7, 1, 14, 5, 249, 1, 'LG*|Gundam', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 227, 1920, 0, 0, 12, 180, 0, 0);
INSERT INTO `ss_meta_players` VALUES(407, 8, 0, 7, 11, 67, 0, 'Phant0mPT', 0, 0, 0, 0, 1, 0, 0, 0, 190, 705, 0, 0, 36, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(407, 9, 0, 2, 8, -7, 0, 'EMPLASTRO', 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 5, 80, 27, 168, 0, 0, 2, 32, 0, 0);
INSERT INTO `ss_meta_players` VALUES(407, 10, 0, 3, 9, 42, 0, 'jj', 0, 0, 0, 0, 0, 0, 0, 0, 198, 450, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(407, 11, 0, 13, 10, 115, 0, 'charlie', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 197, 1920, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(407, 12, 0, 7, 8, 88, 1, 'oldmen', 0, 0, 0, 0, 0, 0, 6, 255, 136, 405, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(407, 13, 0, 9, 8, 76, 1, 'bonanca', 0, 0, 0, 0, 0, 0, 4, 60, 0, 0, 0, 0, 168, 1200, 0, 0, 8, 45, 0, 0);
INSERT INTO `ss_meta_players` VALUES(408, 0, 1, 20, 16, 279, 1, 'HyPE|gdm', 0, 0, 26, 126, 0, 0, 7, 270, 97, 315, 0, 0, 411, 2064, 0, 0, 8, 149, 0, 0);
INSERT INTO `ss_meta_players` VALUES(408, 1, 4, 16, 18, 288, 1, '.:HsOs:.Zarkan', 0, 0, 0, 0, 65, 1560, 10, 410, 0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(408, 2, 3, 20, 18, 326, 0, '{BoB}Mise[T]', 8, 0, 5, 54, 13, 300, 19, 805, 0, 0, 0, 0, 260, 1368, 0, 0, 8, 146, 0, 0);
INSERT INTO `ss_meta_players` VALUES(408, 3, 1, 15, 18, 203, 0, '*Fawkes', 0, 0, 44, 288, 0, 0, 0, 0, 0, 0, 47, 1360, 0, 0, 0, 0, 6, 106, 62, 418);
INSERT INTO `ss_meta_players` VALUES(409, 0, 3, 49, 37, 718, 1, 'HyPE|gdm', 0, 0, 38, 198, 0, 0, 14, 510, 234, 750, 0, 0, 878, 4488, 0, 0, 27, 515, 139, 665);
INSERT INTO `ss_meta_players` VALUES(409, 1, 15, 49, 36, 1163, 1, '.:HsOs:.Zarkan', 2, 100, 11, 54, 65, 1560, 101, 3945, 0, 0, 0, 0, 0, 0, 0, 0, 60, 624, 21, 38);
INSERT INTO `ss_meta_players` VALUES(409, 2, 6, 40, 49, 651, 0, '{BoB}Mise[T]', 11, 0, 9, 72, 13, 300, 69, 2455, 0, 0, 0, 0, 631, 2664, 0, 0, 12, 146, 0, 0);
INSERT INTO `ss_meta_players` VALUES(409, 3, 2, 37, 49, 437, 0, '*Fawkes', 0, 0, 93, 576, 0, 0, 0, 0, 0, 0, 133, 4560, 0, 0, 0, 0, 16, 209, 68, 418);
INSERT INTO `ss_meta_players` VALUES(410, 0, 0, 0, 0, 0, 4, 'Brutality|W$N|', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(410, 1, 0, 6, 3, 70, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 56, 255, 0, 0, 38, 240, 0, 0, 1, 104, 0, 0);
INSERT INTO `ss_meta_players` VALUES(410, 2, 5, 27, 34, 629, 1, 'Twister', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 160, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(410, 3, 0, 0, 3, -12, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(410, 4, 4, 31, 33, 720, 0, 'FD*elCr@ck!', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(410, 5, 5, 39, 24, 973, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 75, 624, 0, 0, 4, 0, 26, 133);
INSERT INTO `ss_meta_players` VALUES(410, 6, 0, 0, 3, -12, 0, 'GroPENIIIIS', 0, 0, 4, 18, 0, 0, 0, 0, 0, 0, 4, 0, 14, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(410, 7, 2, 14, 34, 208, 0, 'cbo', 0, 0, 1, 18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0);
INSERT INTO `ss_meta_players` VALUES(410, 8, 2, 43, 33, 707, 1, 'MLP|BonBon', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 88, 576, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(410, 9, 0, 0, 1, -4, 1, 'blaster', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(410, 10, 0, 0, 0, 0, 4, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(410, 11, 4, 45, 35, 951, 0, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 59, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 0, 0, 1, 2, 7, 0, 'ixtra', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 1, 0, 2, 1, 16, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 2, 0, 0, 0, 0, 4, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 1, 1, 2, 1, 52, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 2, 0, 1, 0, 13, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 21, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 3, 0, 0, 1, -1, 0, 'wintergoat', 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 0, 0, 1, 2, 7, 0, 'ixtra', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 1, 0, 2, 1, 16, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 2, 0, 0, 0, 0, 4, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 1, 1, 2, 1, 52, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 2, 0, 1, 0, 13, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 21, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 3, 0, 0, 1, -1, 0, 'wintergoat', 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 0, 0, 1, 2, 7, 0, 'ixtra', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 1, 0, 2, 1, 16, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 2, 0, 0, 0, 0, 4, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 1, 1, 2, 1, 52, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 2, 0, 1, 0, 13, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 21, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 3, 0, 0, 1, -1, 0, 'wintergoat', 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 0, 0, 1, 2, 7, 0, 'ixtra', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 1, 0, 2, 1, 16, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 2, 0, 0, 0, 0, 4, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 1, 1, 2, 1, 52, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 2, 0, 1, 0, 13, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 21, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 3, 0, 0, 1, -1, 0, 'wintergoat', 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 0, 0, 1, 2, 7, 0, 'ixtra', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 1, 0, 2, 1, 16, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 2, 0, 0, 0, 0, 4, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 1, 1, 2, 1, 52, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 2, 0, 1, 0, 13, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 21, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 3, 0, 0, 1, -1, 0, 'wintergoat', 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 0, 0, 1, 2, 7, 0, 'ixtra', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 1, 0, 2, 1, 16, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 2, 0, 0, 0, 0, 4, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(422, 0, 0, 5, 0, 75, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 138, 675, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(422, 1, 1, 8, 6, 117, 1, 'iOD|Slip4ever', 0, 0, 8, 54, 0, 0, 0, 0, 0, 0, 15, 960, 0, 0, 0, 0, 16, 198, 0, 0);
INSERT INTO `ss_meta_players` VALUES(422, 2, 0, 5, 2, 76, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 21, 105, 0, 0, 120, 600, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(422, 3, 2, 0, 6, 38, 0, 'wintergoat', 0, 0, 0, 0, 0, 0, 7, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(422, 4, 0, 0, 3, -12, 0, 'bess', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 5, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(423, 0, 0, 8, 1, 113, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 222, 1065, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(423, 1, 1, 12, 7, 158, 1, 'iOD|Slip4ever', 1, 0, 10, 54, 0, 0, 0, 0, 0, 0, 19, 1360, 0, 0, 0, 0, 18, 299, 0, 0);
INSERT INTO `ss_meta_players` VALUES(423, 2, 0, 7, 6, 100, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 21, 105, 0, 0, 179, 1056, 0, 0, 4, 21, 0, 0);
INSERT INTO `ss_meta_players` VALUES(423, 3, 2, 0, 7, 34, 0, 'wintergoat', 0, 0, 0, 0, 0, 0, 7, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(423, 4, 0, 0, 4, -6, 0, 'bess', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 6, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(424, 0, 0, 12, 5, 173, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 389, 1575, 0, 0, 0, 0, 0, 0, 8, 42, 0, 0);
INSERT INTO `ss_meta_players` VALUES(424, 1, 1, 17, 10, 219, 1, 'iOD|Slip4ever', 2, 0, 57, 288, 0, 0, 0, 0, 0, 0, 29, 1840, 0, 0, 0, 0, 22, 299, 0, 0);
INSERT INTO `ss_meta_players` VALUES(424, 2, 0, 13, 8, 178, 0, 'HyPE|gdm', 0, 0, 2, 18, 0, 0, 0, 0, 21, 105, 0, 0, 270, 1680, 0, 0, 9, 21, 0, 0);
INSERT INTO `ss_meta_players` VALUES(424, 3, 3, 0, 11, 60, 0, 'wintergoat', 0, 0, 0, 0, 0, 0, 14, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(424, 4, 1, 2, 7, 51, 0, 'bess', 2, 0, 23, 72, 0, 0, 0, 0, 33, 135, 12, 480, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(424, 5, 0, 0, 1, -4, 1, '008', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 1, 1, 2, 1, 52, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 2, 0, 1, 0, 13, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 21, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(412, 3, 0, 0, 1, -1, 0, 'wintergoat', 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 0, 0, 1, 2, 7, 0, 'ixtra', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 1, 0, 2, 1, 16, 1, 'iOD|Slip4ever', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(411, 2, 0, 0, 0, 0, 4, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(427, 0, 0, 0, 0, 0, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(428, 0, 1, 0, 1, 44, 0, 'Sky90', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(428, 1, 0, 2, 3, 28, 0, 'JEcOb101', 0, 0, 0, 0, 0, 0, 1, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(428, 2, 0, 3, 1, 55, 1, 'Macedon', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(428, 3, 0, 0, 2, 5, 0, 'clesio', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(428, 4, 1, 2, 2, 73, 1, 'Vlad78', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(428, 5, 0, 0, 0, 0, 4, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(429, 0, 1, 0, 2, 40, 0, 'Sky90', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 216, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(429, 1, 0, 2, 4, 24, 0, 'JEcOb101', 0, 0, 0, 0, 0, 0, 1, 90, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(429, 2, 0, 3, 1, 55, 1, 'Macedon', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(429, 3, 0, 0, 2, 5, 0, 'clesio', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(429, 4, 1, 3, 2, 89, 1, 'Vlad78', 0, 0, 0, 0, 0, 0, 4, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(429, 5, 0, 1, 0, 10, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(430, 0, 1, 1, 4, 46, 0, 'Sky90', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 36, 408, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(430, 1, 0, 2, 4, 24, 0, 'JEcOb101', 0, 0, 0, 0, 0, 0, 1, 90, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(430, 2, 0, 4, 1, 55, 1, 'Macedon', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(430, 3, 0, 0, 3, 1, 0, 'clesio', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(430, 4, 1, 3, 3, 85, 1, 'Vlad78', 0, 0, 0, 0, 0, 0, 6, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(430, 5, 0, 3, 0, 41, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 39, 288, 0, 0, 0, 0, 28, 114);
INSERT INTO `ss_meta_players` VALUES(431, 0, 0, 0, 0, 0, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 0, 0, 11, 0, 100, 1, 'mmmpf', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 1, 0, 1, 0, 22, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 2, 0, 4, 3, 50, 0, 'Jihard', 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 3, 0, 3, 9, 32, 0, 'Mickey', 0, 0, 0, 0, 0, 0, 3, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 4, 0, 3, 5, 23, 1, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 2, 37, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 5, 0, 3, 5, 66, 1, '[ED]S.O.D.', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 6, 0, 4, 2, 114, 0, 'Harumune', 0, 0, 0, 0, 0, 0, 0, 0, 37, 195, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 7, 0, 1, 8, 12, 0, 'you', 0, 0, 0, 0, 0, 0, 0, 0, 18, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 8, 0, 3, 3, 35, 1, '008', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 9, 0, 0, 2, -8, 1, 'No.1Nooooob', 0, 0, 0, 0, 0, 0, 0, 0, 14, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 10, 0, 6, 4, 64, 1, 'KTomcso', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 11, 0, 0);
INSERT INTO `ss_meta_players` VALUES(432, 11, 0, 2, 3, 41, 0, 'DonChisciotte', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 0, 0, 13, 1, 150, 1, 'mmmpf', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 504, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 1, 0, 1, 0, 22, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 2, 0, 4, 5, 42, 0, 'Jihard', 0, 0, 0, 0, 9, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 3, 0, 4, 11, 46, 0, 'Mickey', 0, 0, 0, 0, 0, 0, 5, 185, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 4, 0, 6, 5, 48, 1, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 320, 0, 0, 0, 0, 4, 37, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 5, 0, 3, 6, 82, 1, '[ED]S.O.D.', 0, 0, 0, 0, 0, 0, 1, 95, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 6, 0, 4, 3, 106, 0, 'Harumune', 0, 0, 0, 0, 0, 0, 0, 0, 58, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 7, 0, 3, 10, 36, 0, 'you', 0, 0, 0, 0, 0, 0, 0, 0, 51, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 8, 0, 4, 4, 41, 1, '008', 0, 0, 0, 0, 0, 0, 0, 0, 34, 90, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 9, 0, 1, 3, -2, 1, 'No.1Nooooob', 0, 0, 0, 0, 0, 0, 0, 0, 40, 285, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 10, 0, 8, 5, 118, 1, 'KTomcso', 0, 0, 0, 0, 0, 0, 3, 200, 0, 0, 0, 0, 0, 0, 0, 0, 4, 11, 0, 0);
INSERT INTO `ss_meta_players` VALUES(433, 11, 0, 4, 4, 141, 0, 'DonChisciotte', 0, 0, 0, 0, 0, 0, 3, 280, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(434, 0, 1, 21, 2, 365, 1, 'mmmpf', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 116, 1248, 0, 0, 2, 0, 38, 323);
INSERT INTO `ss_meta_players` VALUES(434, 1, 1, 8, 2, 202, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 110, 792, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(434, 2, 0, 8, 12, 126, 0, 'Jihard', 0, 0, 0, 0, 28, 660, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(434, 3, 0, 5, 16, 72, 0, 'Mickey', 0, 0, 0, 0, 0, 0, 14, 370, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(434, 4, 0, 14, 9, 121, 1, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 1200, 0, 0, 0, 0, 10, 164, 0, 0);
INSERT INTO `ss_meta_players` VALUES(434, 5, 1, 8, 9, 277, 1, '[ED]S.O.D.', 0, 0, 0, 0, 0, 0, 16, 760, 0, 0, 0, 0, 0, 0, 0, 0, 12, 87, 0, 0);
INSERT INTO `ss_meta_players` VALUES(434, 6, 0, 8, 8, 150, 0, 'Harumune', 0, 0, 5, 54, 0, 0, 0, 0, 206, 795, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(434, 7, 0, 7, 16, 64, 0, 'you', 0, 0, 0, 0, 16, 480, 0, 0, 60, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(434, 8, 0, 7, 9, 51, 1, '008', 0, 0, 0, 0, 0, 0, 0, 0, 108, 495, 0, 0, 0, 0, 0, 0, 2, 85, 0, 0);
INSERT INTO `ss_meta_players` VALUES(434, 9, 0, 4, 8, 20, 1, 'No.1Nooooob', 0, 0, 0, 0, 0, 0, 0, 0, 117, 720, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(434, 10, 0, 12, 7, 178, 1, 'KTomcso', 0, 0, 0, 0, 0, 0, 15, 530, 0, 0, 0, 0, 0, 0, 0, 0, 8, 11, 12, 114);
INSERT INTO `ss_meta_players` VALUES(434, 11, 0, 4, 9, 133, 0, 'DonChisciotte', 0, 0, 0, 0, 0, 0, 15, 620, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(435, 0, 1, 22, 2, 399, 1, 'mmmpf', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 125, 1320, 0, 0, 4, 0, 38, 323);
INSERT INTO `ss_meta_players` VALUES(435, 1, 1, 9, 3, 237, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 132, 912, 0, 0, 5, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(435, 2, 0, 9, 12, 136, 0, 'Jihard', 0, 0, 0, 0, 28, 660, 0, 0, 20, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(435, 3, 0, 6, 17, 80, 0, 'Mickey', 0, 0, 0, 0, 0, 0, 15, 475, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(435, 4, 0, 15, 10, 127, 1, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19, 1280, 0, 0, 0, 0, 10, 164, 0, 0);
INSERT INTO `ss_meta_players` VALUES(435, 5, 1, 9, 9, 299, 1, '[ED]S.O.D.', 0, 0, 0, 0, 0, 0, 20, 915, 0, 0, 0, 0, 0, 0, 0, 0, 12, 87, 0, 0);
INSERT INTO `ss_meta_players` VALUES(435, 7, 0, 7, 18, 56, 0, 'you', 0, 0, 0, 0, 18, 480, 0, 0, 60, 255, 0, 0, 0, 0, 0, 0, 2, 91, 0, 0);
INSERT INTO `ss_meta_players` VALUES(435, 8, 0, 8, 10, 57, 1, '008', 0, 0, 0, 0, 0, 0, 0, 0, 128, 675, 0, 0, 0, 0, 0, 0, 2, 85, 0, 0);
INSERT INTO `ss_meta_players` VALUES(435, 9, 0, 4, 9, 16, 1, 'No.1Nooooob', 0, 0, 0, 0, 0, 0, 0, 0, 140, 810, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(435, 10, 0, 13, 7, 188, 1, 'KTomcso', 0, 0, 0, 0, 0, 0, 17, 635, 0, 0, 0, 0, 0, 0, 0, 0, 10, 11, 12, 114);
INSERT INTO `ss_meta_players` VALUES(435, 11, 0, 4, 9, 144, 0, 'DonChisciotte', 0, 0, 0, 0, 0, 0, 17, 625, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(436, 0, 1, 30, 3, 523, 1, 'mmmpf', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 251, 2208, 0, 0, 8, 0, 38, 323);
INSERT INTO `ss_meta_players` VALUES(436, 1, 1, 20, 6, 349, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 153, 705, 0, 0, 181, 1440, 0, 0, 7, 302, 0, 0);
INSERT INTO `ss_meta_players` VALUES(436, 2, 0, 11, 16, 177, 0, 'Jihard', 0, 0, 0, 0, 28, 660, 0, 0, 93, 375, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(436, 3, 0, 6, 22, 72, 0, 'Mickey', 0, 0, 0, 0, 0, 0, 23, 620, 0, 0, 0, 0, 0, 0, 0, 0, 10, 33, 0, 0);
INSERT INTO `ss_meta_players` VALUES(436, 4, 0, 17, 14, 155, 1, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 1760, 0, 0, 0, 0, 10, 164, 0, 0);
INSERT INTO `ss_meta_players` VALUES(436, 5, 0, 1, 1, 42, 1, 'Money$hot', 0, 0, 0, 0, 0, 0, 4, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(436, 6, 1, 1, 3, 113, 0, '\\\\..nike-shox../', 0, 0, 0, 0, 0, 0, 10, 185, 0, 0, 0, 0, 0, 0, 0, 0, 4, 43, 22, 152);
INSERT INTO `ss_meta_players` VALUES(436, 7, 0, 9, 22, 60, 0, 'you', 0, 0, 0, 0, 20, 540, 6, 250, 60, 255, 0, 0, 2, 24, 0, 0, 2, 91, 0, 0);
INSERT INTO `ss_meta_players` VALUES(436, 8, 0, 11, 14, 113, 1, '008', 0, 0, 0, 0, 0, 0, 0, 0, 206, 975, 0, 0, 0, 0, 0, 0, 6, 182, 0, 0);
INSERT INTO `ss_meta_players` VALUES(436, 9, 0, 6, 14, 41, 1, 'No.1Nooooob', 0, 0, 0, 0, 0, 0, 5, 170, 198, 1185, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(436, 10, 0, 17, 11, 239, 1, 'KTomcso', 0, 0, 0, 0, 0, 0, 30, 1390, 0, 0, 0, 0, 0, 0, 0, 0, 16, 11, 12, 114);
INSERT INTO `ss_meta_players` VALUES(436, 11, 0, 7, 12, 237, 0, 'DonChisciotte', 0, 0, 0, 0, 0, 0, 30, 1060, 0, 0, 0, 0, 0, 0, 0, 0, 6, 48, 0, 0);
INSERT INTO `ss_meta_players` VALUES(437, 0, 1, 32, 4, 555, 1, 'mmmpf', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 265, 2304, 0, 0, 12, 132, 38, 323);
INSERT INTO `ss_meta_players` VALUES(437, 1, 1, 22, 8, 361, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 170, 795, 0, 0, 181, 1440, 0, 0, 9, 588, 0, 0);
INSERT INTO `ss_meta_players` VALUES(437, 2, 0, 11, 17, 173, 0, 'Jihard', 0, 0, 0, 0, 28, 660, 0, 0, 112, 435, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(437, 3, 0, 6, 23, 71, 0, 'Mickey', 0, 0, 0, 0, 0, 0, 25, 665, 0, 0, 0, 0, 0, 0, 0, 0, 10, 33, 0, 0);
INSERT INTO `ss_meta_players` VALUES(437, 4, 0, 17, 14, 155, 1, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 1760, 0, 0, 0, 0, 10, 164, 0, 0);
INSERT INTO `ss_meta_players` VALUES(437, 5, 0, 3, 3, 57, 1, 'Money$hot', 0, 0, 0, 0, 0, 0, 9, 305, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(437, 6, 2, 4, 3, 257, 0, '\\\\..nike-shox../', 0, 0, 0, 0, 0, 0, 15, 475, 0, 0, 0, 0, 0, 0, 0, 0, 8, 43, 22, 152);
INSERT INTO `ss_meta_players` VALUES(437, 7, 0, 9, 24, 64, 0, 'you', 0, 0, 0, 0, 20, 540, 6, 250, 60, 255, 0, 0, 29, 168, 0, 0, 2, 91, 0, 0);
INSERT INTO `ss_meta_players` VALUES(437, 8, 0, 11, 18, 97, 1, '008', 0, 0, 0, 0, 0, 0, 0, 0, 245, 1125, 0, 0, 0, 0, 0, 0, 6, 182, 0, 0);
INSERT INTO `ss_meta_players` VALUES(437, 9, 0, 8, 15, 60, 1, 'No.1Nooooob', 0, 0, 0, 0, 0, 0, 8, 430, 198, 1185, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(437, 10, 0, 18, 12, 281, 1, 'KTomcso', 0, 0, 0, 0, 0, 0, 34, 1560, 0, 0, 0, 0, 0, 0, 0, 0, 18, 11, 12, 114);
INSERT INTO `ss_meta_players` VALUES(437, 11, 0, 11, 13, 300, 0, 'DonChisciotte', 0, 0, 0, 0, 0, 0, 37, 1330, 0, 0, 0, 0, 0, 0, 0, 0, 8, 95, 0, 0);
INSERT INTO `ss_meta_players` VALUES(438, 0, 0, 0, 0, 0, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(439, 1, 0, 2, 4, 4, 1, 'Jihard', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(439, 2, 0, 4, 0, 76, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 74, 405, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(439, 3, 0, 2, 1, 50, 1, '008', 0, 0, 0, 0, 0, 0, 0, 0, 56, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(439, 4, 0, 0, 1, -4, 1, '.45|Dam''s', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(439, 5, 0, 1, 5, -8, 0, 'Money$hot', 0, 0, 0, 0, 0, 0, 12, 375, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(439, 6, 1, 6, 1, 207, 1, '\\\\..nike-shox../', 0, 0, 0, 0, 0, 0, 1, 10, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 36, 133);
INSERT INTO `ss_meta_players` VALUES(439, 7, 0, 0, 2, -8, 0, 'eduardo', 0, 0, 0, 0, 3, 120, 0, 0, 0, 0, 0, 0, 1, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(439, 8, 0, 2, 0, 32, 1, 'ABUSADOR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(439, 9, 0, 0, 2, -8, 0, 'Th3_Scout', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(439, 10, 0, 1, 4, 8, 0, 'KTomcso', 0, 0, 0, 0, 0, 0, 4, 160, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(439, 11, 0, 3, 5, 47, 0, 'DonChisciotte', 0, 0, 0, 0, 0, 0, 4, 205, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(440, 1, 0, 3, 7, 2, 1, 'Jihard', 0, 0, 0, 0, 7, 120, 0, 0, 0, 0, 0, 0, 25, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(440, 2, 0, 7, 1, 143, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 127, 600, 0, 0, 12, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(440, 3, 0, 3, 3, 68, 1, '008', 0, 0, 0, 0, 0, 0, 0, 0, 124, 480, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(440, 4, 1, 2, 2, 91, 1, '.45|Dam''s', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 43, 480, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(440, 5, 0, 1, 9, -24, 0, 'Money$hot', 0, 0, 0, 0, 0, 0, 22, 670, 0, 0, 0, 0, 0, 0, 0, 0, 2, 41, 0, 0);
INSERT INTO `ss_meta_players` VALUES(440, 6, 1, 7, 4, 215, 1, '\\\\..nike-shox../', 0, 0, 0, 0, 0, 0, 7, 210, 0, 0, 0, 0, 0, 0, 0, 0, 10, 130, 36, 133);
INSERT INTO `ss_meta_players` VALUES(440, 7, 0, 2, 5, 0, 0, 'eduardo', 0, 0, 0, 0, 5, 120, 0, 0, 52, 165, 0, 0, 1, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(440, 8, 1, 2, 1, 101, 1, 'ABUSADOR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 61, 312, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(440, 9, 0, 0, 3, -2, 0, 'Th3_Scout', 0, 0, 0, 0, 10, 300, 0, 0, 0, 0, 0, 0, 13, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(440, 10, 0, 6, 6, 85, 0, 'KTomcso', 0, 0, 0, 0, 0, 0, 13, 770, 0, 0, 0, 0, 0, 0, 0, 0, 4, 18, 0, 0);
INSERT INTO `ss_meta_players` VALUES(441, 1, 0, 5, 7, 22, 1, 'Jihard', 0, 0, 0, 0, 10, 240, 0, 0, 0, 0, 0, 0, 25, 240, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(441, 2, 0, 7, 3, 135, 0, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 127, 600, 0, 0, 33, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(441, 3, 0, 4, 3, 78, 1, '008', 0, 0, 0, 0, 0, 0, 0, 0, 133, 525, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(441, 4, 1, 4, 2, 121, 1, '.45|Dam''s', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 720, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(441, 5, 0, 1, 9, -24, 0, 'Money$hot', 0, 0, 0, 0, 0, 0, 23, 690, 0, 0, 0, 0, 0, 0, 0, 0, 4, 41, 0, 0);
INSERT INTO `ss_meta_players` VALUES(441, 6, 1, 7, 5, 211, 1, '\\\\..nike-shox../', 0, 0, 0, 0, 0, 0, 8, 235, 0, 0, 0, 0, 0, 0, 0, 0, 12, 130, 36, 133);
INSERT INTO `ss_meta_players` VALUES(441, 7, 0, 2, 8, -12, 0, 'eduardo', 0, 0, 0, 0, 5, 120, 0, 0, 73, 210, 0, 0, 1, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(441, 8, 1, 4, 1, 121, 1, 'ABUSADOR', 0, 0, 0, 0, 0, 0, 6, 245, 0, 0, 0, 0, 61, 312, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(441, 10, 0, 7, 7, 91, 0, 'KTomcso', 0, 0, 0, 0, 0, 0, 18, 915, 0, 0, 0, 0, 0, 0, 0, 0, 4, 18, 0, 0);
INSERT INTO `ss_meta_players` VALUES(442, 0, 14, 68, 26, 1787, 0, '{BoB}OpTic', 0, 0, 0, 0, 0, 0, 0, 0, 39, 240, 0, 0, 0, 0, 0, 0, 2, 142, 0, 0);
INSERT INTO `ss_meta_players` VALUES(442, 1, 0, 0, 1, -4, 1, 'HyPE|gdm', 0, 0, 0, 0, 0, 0, 0, 0, 12, 45, 0, 0, 10, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(442, 2, 4, 12, 38, -19, 1, 'SlenderMan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(442, 3, 12, 49, 32, 896, 0, 'Rambo', 0, 0, 0, 0, 0, 0, 5, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(442, 4, 4, 30, 24, 666, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(442, 5, 7, 35, 44, 520, 0, 'a_smile', 0, 0, 0, 0, 0, 0, 4, 185, 0, 0, 0, 0, 0, 0, 0, 0, 2, 174, 0, 0);
INSERT INTO `ss_meta_players` VALUES(442, 6, 0, 9, 6, 90, 1, '#M|A#Damiahn', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(442, 7, 14, 33, 22, 973, 0, 'iAlgorithm|44|', 0, 0, 7, 18, 0, 0, 2, 95, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(442, 8, 9, 33, 38, 860, 1, 'TheAbominable', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(442, 9, 5, 29, 35, 606, 1, 'vsv.cz', 0, 0, 0, 0, 0, 0, 6, 195, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(442, 10, 0, 2, 14, -35, 0, '[GRF]VectorM12', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 16, 76);
INSERT INTO `ss_meta_players` VALUES(442, 11, 3, 11, 10, 332, 0, 'WalRuS10', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(443, 0, 0, 10, 4, 187, 0, '{BoB}OpTic', 0, 0, 0, 0, 0, 0, 0, 0, 95, 435, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(443, 1, 0, 5, 6, 85, 1, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 15, 90, 0, 0, 50, 264, 0, 0, 1, 47, 0, 0);
INSERT INTO `ss_meta_players` VALUES(443, 2, 0, 3, 9, 10, 1, 'SlenderMan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(443, 3, 0, 9, 7, 152, 0, 'Rambo', 0, 0, 0, 0, 6, 180, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(443, 4, 0, 11, 11, 110, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 58, 312, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(443, 5, 0, 1, 8, 14, 0, 'a_sick_old_guy', 1, 0, 3, 18, 0, 0, 0, 0, 43, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(443, 6, 1, 3, 4, 142, 1, '#M|A#Damiahn', 0, 0, 0, 0, 0, 0, 0, 0, 114, 465, 0, 0, 0, 0, 0, 0, 2, 77, 0, 0);
INSERT INTO `ss_meta_players` VALUES(443, 7, 0, 14, 2, 209, 0, 'iAlgorithm|44|', 0, 0, 0, 0, 0, 0, 0, 0, 62, 255, 0, 0, 0, 0, 0, 0, 2, 0, 55, 323);
INSERT INTO `ss_meta_players` VALUES(443, 8, 1, 5, 10, 225, 1, 'TheAbominable', 0, 0, 0, 0, 0, 0, 7, 325, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(443, 9, 0, 4, 6, 40, 1, 'vsv.cz', 0, 0, 0, 0, 0, 0, 6, 135, 0, 0, 0, 0, 0, 0, 0, 0, 2, 129, 0, 0);
INSERT INTO `ss_meta_players` VALUES(443, 10, 0, 4, 10, 83, 0, '[GRF]VectorM12', 2, 0, 0, 0, 6, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(443, 11, 0, 6, 2, 57, 0, 'WalRuS10', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 63, 504, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(444, 0, 0, 16, 7, 265, 0, '{BoB}OpTic', 0, 0, 0, 0, 0, 0, 0, 0, 231, 1140, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(444, 1, 0, 10, 8, 156, 1, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 60, 360, 0, 0, 75, 384, 0, 0, 2, 190, 16, 95);
INSERT INTO `ss_meta_players` VALUES(444, 2, 0, 3, 12, -2, 1, 'SlenderMan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 63, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(444, 3, 0, 11, 10, 186, 0, 'Rambo', 0, 0, 0, 0, 17, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(444, 4, 0, 11, 14, 110, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 107, 504, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(444, 5, 0, 2, 10, 16, 0, 'Yoda', 1, 0, 3, 18, 0, 0, 0, 0, 43, 105, 0, 0, 31, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(444, 6, 1, 5, 5, 195, 1, '#M|A#Damiahn', 0, 0, 0, 0, 0, 0, 0, 0, 184, 645, 0, 0, 0, 0, 0, 0, 2, 77, 0, 0);
INSERT INTO `ss_meta_players` VALUES(444, 7, 0, 17, 3, 259, 0, 'iAlgorithm|44|', 0, 0, 0, 0, 0, 0, 0, 0, 112, 495, 0, 0, 0, 0, 0, 0, 10, 0, 55, 323);
INSERT INTO `ss_meta_players` VALUES(444, 8, 1, 8, 13, 293, 1, 'TheAbominable', 0, 0, 0, 0, 0, 0, 15, 675, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(444, 9, 0, 5, 9, 38, 1, 'vsv.cz', 3, 0, 0, 0, 5, 120, 7, 135, 0, 0, 0, 0, 0, 0, 0, 0, 2, 129, 0, 0);
INSERT INTO `ss_meta_players` VALUES(444, 10, 0, 5, 11, 94, 0, '[GRF]VectorM12', 2, 0, 0, 0, 18, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 10, 0, 0);
INSERT INTO `ss_meta_players` VALUES(444, 11, 0, 8, 3, 121, 0, 'WalRuS10', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 91, 720, 0, 0, 10, 101, 0, 0);
INSERT INTO `ss_meta_players` VALUES(445, 0, 0, 18, 10, 278, 0, '{BoB}OpTic', 0, 0, 0, 0, 0, 0, 0, 0, 316, 1500, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(445, 1, 0, 13, 10, 178, 1, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 153, 645, 0, 0, 75, 384, 0, 0, 3, 297, 16, 95);
INSERT INTO `ss_meta_players` VALUES(445, 2, 0, 3, 14, -10, 1, 'SlenderMan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(445, 3, 0, 12, 12, 200, 0, 'Rambo', 0, 0, 0, 0, 25, 420, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(445, 4, 0, 15, 15, 175, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 181, 1104, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(445, 6, 1, 6, 5, 205, 1, '#M|A#Damiahn', 0, 0, 0, 0, 0, 0, 0, 0, 217, 780, 0, 0, 0, 0, 0, 0, 8, 77, 0, 0);
INSERT INTO `ss_meta_players` VALUES(445, 7, 0, 20, 5, 292, 0, 'iAlgorithm|44|', 0, 0, 0, 0, 0, 0, 0, 0, 189, 735, 0, 0, 0, 0, 0, 0, 12, 31, 55, 323);
INSERT INTO `ss_meta_players` VALUES(445, 8, 1, 9, 16, 320, 1, 'TheAbominable', 0, 0, 0, 0, 0, 0, 20, 830, 0, 0, 0, 0, 0, 0, 0, 0, 6, 137, 0, 0);
INSERT INTO `ss_meta_players` VALUES(445, 9, 0, 7, 11, 50, 1, 'vsv.cz', 3, 0, 0, 0, 14, 360, 7, 135, 0, 0, 0, 0, 0, 0, 0, 0, 2, 129, 0, 0);
INSERT INTO `ss_meta_players` VALUES(445, 10, 0, 7, 14, 115, 0, '[GRF]VectorM12', 2, 0, 0, 0, 26, 540, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 10, 0, 0);
INSERT INTO `ss_meta_players` VALUES(445, 11, 0, 8, 4, 117, 0, 'WalRuS10', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 104, 840, 0, 0, 10, 101, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 0, 0, 7, 7, 56, 1, '__BEGINNER__', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 1, 0, 1, 2, 14, 0, 'ko-da524', 0, 0, 0, 0, 4, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 2, 0, 8, 13, 125, 0, 'Barbekniv45', 0, 0, 0, 0, 0, 0, 0, 0, 57, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 3, 1, 13, 15, 304, 1, 'Rambo', 0, 0, 0, 0, 16, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 4, 1, 18, 10, 443, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 192, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 5, 4, 17, 7, 631, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 45, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 6, 1, 16, 14, 390, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 72, 285, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 7, 0, 2, 5, 24, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 8, 0, 4, 1, 111, 0, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 90, 510, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 9, 0, 7, 13, 80, 1, 'Soflete', 0, 0, 0, 0, 8, 180, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 10, 1, 6, 4, 184, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 0, 0, 15, 60, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(446, 11, 2, 8, 7, 231, 1, 'WalRuS10', 0, 0, 11, 18, 0, 0, 0, 0, 0, 0, 0, 0, 34, 192, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(447, 0, 0, 7, 7, 56, 1, '__BEGINNER__', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 78, 456, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(447, 1, 0, 2, 2, 25, 0, 'ko-da524', 0, 0, 0, 0, 6, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(447, 2, 0, 8, 14, 121, 0, 'Barbekniv45', 0, 0, 0, 0, 0, 0, 0, 0, 110, 225, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(447, 3, 1, 16, 17, 365, 1, 'Rambo', 0, 0, 0, 0, 29, 780, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(447, 4, 1, 19, 11, 461, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 240, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(447, 5, 4, 19, 9, 694, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 80, 432, 0, 0, 0, 0, 23, 114);
INSERT INTO `ss_meta_players` VALUES(447, 6, 1, 17, 15, 397, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 102, 405, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(447, 7, 0, 2, 5, 24, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(447, 8, 1, 5, 2, 239, 0, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 122, 600, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(447, 9, 0, 8, 14, 133, 1, 'Soflete', 0, 0, 0, 0, 14, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(447, 10, 1, 6, 5, 193, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 0, 0, 37, 165, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(447, 11, 2, 9, 8, 237, 1, 'WalRuS10', 0, 0, 11, 18, 0, 0, 0, 0, 0, 0, 0, 0, 57, 360, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(448, 0, 0, 8, 8, 68, 1, '__BEGINNER__', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 92, 600, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(448, 1, 0, 2, 3, 21, 0, 'ko-da524', 0, 0, 0, 0, 7, 180, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(448, 2, 0, 8, 15, 117, 0, 'Barbekniv45', 0, 0, 0, 0, 0, 0, 0, 0, 110, 225, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(448, 3, 1, 18, 18, 405, 1, 'Rambo', 0, 0, 0, 0, 32, 840, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 161, 0, 0);
INSERT INTO `ss_meta_players` VALUES(448, 4, 2, 19, 12, 544, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 76, 360, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(448, 5, 4, 22, 9, 726, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 115, 648, 0, 0, 0, 0, 23, 114);
INSERT INTO `ss_meta_players` VALUES(448, 6, 1, 17, 16, 393, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 108, 450, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(448, 7, 0, 2, 5, 24, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(448, 8, 1, 5, 3, 235, 0, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 122, 600, 0, 0, 13, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(448, 9, 0, 8, 14, 133, 1, 'Soflete', 0, 0, 0, 0, 14, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(448, 10, 1, 6, 5, 193, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 0, 0, 73, 210, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(448, 11, 2, 10, 8, 247, 1, 'WalRuS10', 0, 0, 11, 18, 0, 0, 0, 0, 0, 0, 0, 0, 61, 360, 0, 0, 4, 150, 0, 0);
INSERT INTO `ss_meta_players` VALUES(449, 0, 0, 12, 9, 153, 1, '__BEGINNER__', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 137, 840, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(449, 1, 0, 6, 5, 92, 0, 'ko-da524', 0, 0, 0, 0, 23, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(449, 2, 0, 9, 18, 120, 0, 'Barbekniv45', 0, 0, 0, 0, 0, 0, 0, 0, 189, 510, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(449, 3, 1, 21, 22, 431, 1, 'Rambo', 0, 0, 0, 0, 51, 1380, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 161, 0, 0);
INSERT INTO `ss_meta_players` VALUES(449, 4, 2, 22, 14, 592, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 140, 672, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(449, 5, 5, 25, 11, 853, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 155, 888, 0, 0, 0, 0, 23, 114);
INSERT INTO `ss_meta_players` VALUES(449, 6, 1, 18, 18, 395, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 168, 660, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(449, 7, 0, 3, 6, 30, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 17, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(449, 8, 1, 10, 4, 342, 0, 'HyPE|R', 0, 0, 1, 18, 0, 0, 0, 0, 122, 600, 0, 0, 54, 288, 0, 0, 2, 0, 49, 323);
INSERT INTO `ss_meta_players` VALUES(449, 9, 0, 8, 17, 121, 1, 'Soflete', 0, 0, 0, 0, 22, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(449, 10, 2, 6, 6, 277, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 1, 0, 76, 210, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(449, 11, 2, 10, 11, 247, 1, 'WalRuS10', 0, 0, 11, 18, 0, 0, 0, 0, 0, 0, 0, 0, 116, 720, 0, 0, 4, 150, 0, 0);
INSERT INTO `ss_meta_players` VALUES(450, 0, 0, 16, 14, 190, 1, '__BEGINNER__', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 205, 1368, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(450, 1, 0, 7, 10, 82, 0, 'ko-da524', 0, 0, 0, 0, 28, 720, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(450, 2, 0, 9, 21, 123, 0, 'Barbekniv45', 0, 0, 0, 0, 0, 0, 0, 0, 267, 840, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(450, 3, 1, 23, 28, 454, 1, 'Rambo', 0, 0, 0, 0, 76, 1740, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 161, 0, 0);
INSERT INTO `ss_meta_players` VALUES(450, 4, 2, 28, 17, 680, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 222, 1200, 0, 0, 12, 47, 0, 0);
INSERT INTO `ss_meta_players` VALUES(450, 5, 5, 34, 14, 990, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 252, 1776, 0, 0, 2, 0, 23, 114);
INSERT INTO `ss_meta_players` VALUES(450, 6, 1, 23, 21, 526, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 304, 1275, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(450, 7, 0, 4, 7, 36, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 56, 285, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(450, 8, 2, 15, 5, 452, 0, 'HyPE|R', 0, 0, 1, 18, 0, 0, 0, 0, 122, 600, 0, 0, 166, 1080, 0, 0, 3, 0, 49, 323);
INSERT INTO `ss_meta_players` VALUES(450, 9, 0, 12, 22, 177, 1, 'Soflete', 0, 0, 0, 0, 49, 1020, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(450, 10, 2, 7, 10, 271, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 9, 235, 76, 210, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(450, 11, 2, 11, 13, 276, 1, 'WalRuS10', 0, 0, 11, 18, 0, 0, 0, 0, 0, 0, 0, 0, 132, 816, 0, 0, 10, 240, 0, 0);
INSERT INTO `ss_meta_players` VALUES(451, 1, 0, 10, 15, 105, 0, 'ko-da524', 0, 0, 0, 0, 50, 1260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(451, 2, 1, 17, 26, 360, 0, 'Barbekniv45', 0, 0, 0, 0, 0, 0, 0, 0, 492, 1680, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(451, 3, 1, 26, 39, 467, 1, 'Rambo', 0, 0, 0, 0, 116, 2400, 3, 140, 0, 0, 0, 0, 0, 0, 0, 0, 4, 161, 0, 0);
INSERT INTO `ss_meta_players` VALUES(451, 4, 3, 36, 27, 843, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 430, 2592, 0, 0, 18, 47, 0, 0);
INSERT INTO `ss_meta_players` VALUES(451, 5, 8, 47, 15, 1445, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 470, 3360, 0, 0, 6, 287, 23, 114);
INSERT INTO `ss_meta_players` VALUES(451, 6, 1, 31, 24, 668, 0, 'DES|byrus', 2, 0, 0, 0, 0, 0, 0, 0, 525, 2220, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(451, 7, 0, 8, 11, 102, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 159, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(451, 8, 3, 26, 6, 750, 1, 'HyPE|R', 0, 0, 1, 18, 0, 0, 0, 0, 122, 600, 0, 0, 332, 1992, 0, 0, 5, 113, 49, 323);
INSERT INTO `ss_meta_players` VALUES(451, 9, 0, 15, 29, 253, 1, 'Soflete', 0, 0, 0, 0, 67, 1260, 0, 0, 0, 0, 4, 160, 0, 0, 0, 0, 8, 2, 0, 0);
INSERT INTO `ss_meta_players` VALUES(451, 10, 3, 16, 16, 527, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 22, 1220, 76, 210, 0, 0, 0, 0, 0, 0, 16, 142, 0, 0);
INSERT INTO `ss_meta_players` VALUES(451, 11, 0, 1, 8, -8, 1, 'mdks', 0, 0, 0, 0, 0, 0, 5, 120, 0, 0, 2, 0, 18, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(452, 1, 0, 10, 16, 101, 0, 'ko-da524', 0, 0, 0, 0, 50, 1260, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 13, 0, 0);
INSERT INTO `ss_meta_players` VALUES(452, 2, 1, 17, 27, 356, 0, 'Barbekniv45', 0, 0, 0, 0, 0, 0, 0, 0, 496, 1710, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(452, 3, 1, 26, 40, 463, 1, 'Rambo', 0, 0, 0, 0, 118, 2400, 3, 140, 0, 0, 0, 0, 0, 0, 0, 0, 4, 161, 0, 0);
INSERT INTO `ss_meta_players` VALUES(452, 4, 4, 37, 27, 939, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 457, 2616, 0, 0, 18, 47, 0, 0);
INSERT INTO `ss_meta_players` VALUES(452, 5, 8, 49, 16, 1461, 0, 'FD*elCr@ck!', 2, 100, 4, 18, 0, 0, 0, 0, 0, 0, 0, 0, 484, 3480, 0, 0, 6, 287, 23, 114);
INSERT INTO `ss_meta_players` VALUES(452, 6, 1, 34, 24, 699, 0, 'DES|byrus', 4, 100, 0, 0, 0, 0, 0, 0, 561, 2265, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(452, 7, 0, 8, 12, 98, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 159, 600, 0, 0, 0, 0, 0, 0, 2, 72, 0, 0);
INSERT INTO `ss_meta_players` VALUES(452, 8, 3, 26, 7, 746, 1, 'HyPE|R', 0, 0, 1, 18, 0, 0, 0, 0, 122, 600, 0, 0, 332, 1992, 0, 0, 5, 113, 49, 323);
INSERT INTO `ss_meta_players` VALUES(452, 9, 0, 16, 29, 275, 1, 'Soflete', 0, 0, 0, 0, 67, 1260, 0, 0, 0, 0, 5, 240, 0, 0, 0, 0, 8, 2, 0, 0);
INSERT INTO `ss_meta_players` VALUES(452, 10, 3, 17, 16, 541, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 23, 1325, 76, 210, 0, 0, 0, 0, 0, 0, 16, 142, 0, 0);
INSERT INTO `ss_meta_players` VALUES(452, 11, 0, 2, 9, 33, 1, 'mdks', 0, 0, 0, 0, 0, 0, 7, 225, 0, 0, 2, 0, 18, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(453, 0, 0, 0, 0, 0, 1, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(454, 0, 0, 0, 0, 0, 0, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(455, 0, 0, 0, 0, 0, 1, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(456, 0, 0, 0, 0, 0, 0, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(457, 0, 0, 0, 0, 0, 1, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(458, 0, 0, 0, 0, 0, 0, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(459, 0, 3, 10, 9, 354, 0, 'EX#C0MBATENTE', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 61, 216, 0, 0, 2, 73, 0, 0);
INSERT INTO `ss_meta_players` VALUES(459, 1, 1, 9, 16, 138, 0, 'ko-da524', 0, 0, 0, 0, 4, 180, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(459, 2, 1, 10, 4, 199, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 50, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(459, 3, 0, 0, 7, -11, 0, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 58, 210, 0, 0, 35, 288, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(459, 4, 0, 4, 2, 46, 1, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 67, 432, 0, 0, 2, 311, 0, 0);
INSERT INTO `ss_meta_players` VALUES(459, 5, 5, 30, 7, 771, 1, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 60, 168, 0, 0, 4, 35, 0, 0);
INSERT INTO `ss_meta_players` VALUES(459, 6, 1, 3, 2, 124, 4, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(459, 7, 0, 3, 9, -6, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(459, 9, 0, 8, 18, 75, 1, 'Soflete', 0, 0, 0, 0, 0, 0, 0, 0, 16, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(459, 10, 4, 11, 9, 446, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 2, 125, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(460, 0, 0, 0, 0, 0, 1, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 0, 4, 14, 14, 526, 0, 'EX#C0MBATENTE', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 1, 1, 11, 21, 228, 0, 'ko-da524', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 2, 1, 14, 8, 264, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 10, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 3, 0, 4, 2, 46, 4, 'HyPE|R', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 4, 0, 3, 2, 37, 0, 'No.1Nooooob', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 5, 5, 38, 10, 904, 1, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 6, 1, 7, 6, 162, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 7, 0, 4, 12, -8, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 8, 0, 6, 3, 66, 1, '{BoB}OpTic', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 9, 0, 12, 24, 74, 1, 'Soflete', 0, 0, 0, 0, 0, 0, 0, 0, 10, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 10, 5, 12, 12, 494, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(461, 11, 0, 1, 1, 18, 1, 'SlenderMan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(462, 0, 4, 13, 16, 498, 0, 'EX#C0MBATENTE', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 240, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(462, 1, 1, 11, 24, 235, 0, 'ko-da524', 0, 0, 0, 0, 8, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(462, 2, 1, 16, 10, 290, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 63, 225, 0, 0, 0, 0, 0, 0, 0, 0, 28, 209);
INSERT INTO `ss_meta_players` VALUES(462, 3, 0, 6, 5, 66, 0, 'HyPE|R', 0, 0, 7, 72, 0, 0, 0, 0, 0, 0, 4, 80, 30, 168, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(462, 4, 0, 5, 3, 56, 0, 'No.1Nooooob', 0, 0, 0, 0, 0, 0, 0, 0, 47, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(462, 5, 5, 41, 12, 1012, 1, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 38, 240, 0, 0, 4, 18, 0, 0);
INSERT INTO `ss_meta_players` VALUES(462, 6, 1, 13, 9, 242, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 107, 390, 0, 0, 0, 0, 0, 0, 4, 142, 0, 0);
INSERT INTO `ss_meta_players` VALUES(462, 7, 0, 4, 13, -2, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 48, 0, 0, 2, 135, 0, 0);
INSERT INTO `ss_meta_players` VALUES(462, 8, 0, 12, 6, 140, 1, '{BoB}OpTic', 0, 0, 26, 198, 0, 0, 0, 0, 0, 0, 9, 320, 0, 0, 0, 0, 2, 125, 0, 0);
INSERT INTO `ss_meta_players` VALUES(462, 9, 1, 12, 25, 183, 1, 'Soflete', 0, 0, 0, 0, 0, 0, 0, 0, 70, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(462, 10, 6, 12, 13, 602, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 1, 20, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(462, 11, 0, 1, 3, 10, 1, 'SlenderMan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(463, 0, 4, 16, 17, 542, 0, 'EX#C0MBATENTE', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 360, 0, 0, 6, 0, 26, 76);
INSERT INTO `ss_meta_players` VALUES(463, 1, 1, 13, 25, 281, 0, 'ko-da524', 0, 0, 0, 0, 20, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 28, 0, 0);
INSERT INTO `ss_meta_players` VALUES(463, 2, 1, 18, 12, 329, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 96, 420, 0, 0, 0, 0, 0, 0, 0, 0, 28, 209);
INSERT INTO `ss_meta_players` VALUES(463, 3, 0, 8, 6, 94, 0, 'HyPE|R', 0, 0, 7, 72, 0, 0, 0, 0, 0, 0, 4, 80, 74, 432, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(463, 4, 0, 7, 5, 92, 0, 'No.1Nooooob', 0, 0, 0, 0, 0, 0, 0, 0, 81, 345, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(463, 5, 5, 43, 14, 1065, 1, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 528, 0, 0, 4, 18, 0, 0);
INSERT INTO `ss_meta_players` VALUES(463, 6, 1, 15, 12, 255, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 175, 750, 0, 0, 0, 0, 0, 0, 4, 142, 0, 0);
INSERT INTO `ss_meta_players` VALUES(463, 7, 0, 4, 14, -6, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 120, 0, 0, 2, 135, 0, 0);
INSERT INTO `ss_meta_players` VALUES(463, 8, 0, 16, 7, 178, 1, '{BoB}OpTic', 0, 0, 33, 234, 0, 0, 0, 0, 0, 0, 15, 800, 0, 0, 0, 0, 8, 188, 0, 0);
INSERT INTO `ss_meta_players` VALUES(463, 10, 7, 12, 13, 717, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 1, 20, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(463, 11, 0, 1, 5, 2, 1, 'SlenderMan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 53, 216, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(464, 0, 4, 19, 20, 577, 0, 'EX#C0MBATENTE', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 114, 696, 0, 0, 8, 0, 42, 190);
INSERT INTO `ss_meta_players` VALUES(464, 1, 1, 13, 28, 269, 0, 'ko-da524', 0, 0, 0, 0, 27, 540, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 28, 0, 0);
INSERT INTO `ss_meta_players` VALUES(464, 2, 1, 21, 17, 383, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 182, 900, 0, 0, 0, 0, 0, 0, 0, 0, 28, 209);
INSERT INTO `ss_meta_players` VALUES(464, 3, 0, 12, 10, 145, 0, '<b>gdm</b>', 0, 0, 7, 72, 0, 0, 0, 0, 0, 0, 4, 80, 115, 768, 0, 0, 4, 170, 0, 0);
INSERT INTO `ss_meta_players` VALUES(464, 4, 0, 9, 8, 101, 0, 'No.1Nooooob', 0, 0, 0, 0, 0, 0, 0, 0, 132, 585, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(464, 5, 5, 48, 18, 1198, 1, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 205, 1200, 0, 0, 4, 18, 0, 0);
INSERT INTO `ss_meta_players` VALUES(464, 6, 1, 17, 15, 267, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 246, 1005, 0, 0, 0, 0, 0, 0, 10, 142, 0, 0);
INSERT INTO `ss_meta_players` VALUES(464, 7, 0, 6, 16, 6, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 70, 360, 0, 0, 2, 135, 0, 0);
INSERT INTO `ss_meta_players` VALUES(464, 8, 1, 25, 9, 361, 1, '{BoB}OpTic', 0, 0, 50, 396, 0, 0, 0, 0, 0, 0, 30, 1760, 0, 0, 0, 0, 12, 188, 12, 95);
INSERT INTO `ss_meta_players` VALUES(464, 10, 7, 14, 15, 747, 0, 'GingerSnaps', 0, 0, 0, 0, 0, 0, 5, 290, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(464, 11, 0, 1, 6, -2, 1, 'SlenderMan', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 0, 0, 6, 19, 8, 1, 'MYHFV', 0, 0, 0, 0, 0, 0, 1, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 1, 0, 1, 7, -38, 1, 'ewwwww', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 2, 0, 2, 2, 18, 0, '-Chester-', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 3, 0, 9, 4, 98, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 4, 0, 21, 20, 290, 1, 'Linus[BR]', 0, 0, 0, 0, 0, 0, 7, 290, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 5, 0, 9, 25, 32, 0, 'JEFERSON', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 6, 0, 9, 18, 88, 0, 'KROWMAN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 7, 0, 14, 15, 128, 0, 'd', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 8, 0, 12, 15, 115, 0, 'niuv', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 9, 1, 21, 20, 302, 1, 'b', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 10, 0, 12, 17, 177, 0, 'AVENTADOR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 11, 1, 9, 10, 196, 1, 'VideoMartyr', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 12, 0, 19, 19, 225, 0, 'Rambo', 0, 0, 0, 0, 0, 0, 3, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 13, 0, 13, 15, 168, 1, 'aquka', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 14, 0, 14, 13, 198, 1, 'sCrIpT_eRrOr', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 15, 0, 17, 14, 268, 0, 'MrSmiles', 0, 0, 0, 0, 0, 0, 3, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 16, 1, 25, 11, 379, 1, 'EX#C0MBATENTE', 0, 0, 0, 0, 0, 0, 0, 0, 25, 105, 0, 0, 0, 0, 0, 0, 2, 96, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 17, 0, 0, 0, -5, 1, '&lt;b&gt;gdm&lt;', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 18, 0, 11, 17, 35, 1, 'KingWolf', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(465, 19, 0, 2, 1, 26, 0, 'General_MIDI', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 0, 0, 0, 0, 0, 1, '&gt;DoS&lt;Haplo', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 1, 0, 1, 8, -42, 1, 'ewwwww', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 36, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 2, 0, 4, 7, 21, 0, '-Chester-', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 648, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 3, 0, 13, 8, 134, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 92, 360, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 4, 0, 26, 25, 342, 1, 'Linus[BR]', 0, 0, 0, 0, 0, 0, 20, 970, 0, 0, 0, 0, 0, 0, 0, 0, 4, 132, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 5, 0, 11, 31, 54, 0, 'JEFERSON', 0, 0, 0, 0, 0, 0, 8, 310, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 6, 0, 9, 22, 72, 0, 'KROWMAN', 0, 0, 0, 0, 0, 0, 5, 170, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 7, 0, 16, 17, 141, 0, 'd', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 54, 360, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 8, 0, 12, 19, 99, 0, 'niuv', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 672, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 9, 1, 26, 24, 349, 1, 'b', 0, 0, 0, 0, 0, 0, 14, 755, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 38);
INSERT INTO `ss_meta_players` VALUES(466, 10, 0, 14, 20, 180, 0, 'AVENTADOR', 0, 0, 0, 0, 0, 0, 5, 465, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 11, 1, 12, 15, 246, 1, 'VideoMartyr', 0, 0, 0, 0, 0, 0, 8, 490, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 12, 0, 24, 23, 292, 0, 'Rambo', 0, 0, 0, 0, 0, 0, 17, 940, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 13, 0, 13, 18, 148, 1, 'aquka', 0, 0, 0, 0, 0, 0, 4, 195, 0, 0, 0, 0, 28, 168, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 14, 0, 14, 16, 182, 1, 'sCrIpT_eRrOr', 0, 0, 0, 0, 0, 0, 0, 0, 94, 210, 0, 0, 11, 24, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 15, 0, 19, 14, 376, 0, 'MrSmiles', 0, 0, 0, 0, 0, 0, 9, 400, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 16, 1, 30, 11, 429, 1, 'EX#C0MBATENTE', 0, 0, 0, 0, 0, 0, 0, 0, 88, 390, 0, 0, 0, 0, 0, 0, 8, 256, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 17, 0, 9, 0, 119, 1, '&lt;b&gt;gdm&lt;', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 72, 624, 0, 0, 5, 331, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 18, 0, 16, 20, 73, 1, 'KingWolf', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 79, 696, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(466, 19, 0, 3, 7, 36, 0, 'General_MIDI', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 57, 432, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 0, 0, 3, 4, 16, 1, '&gt;DoS&lt;Haplo', 0, 0, 0, 0, 0, 0, 20, 460, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 1, 0, 1, 8, -42, 1, 'ewwwww', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 36, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 2, 0, 7, 9, 68, 0, '-Chester-', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120, 936, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 3, 0, 17, 12, 159, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 136, 570, 0, 0, 0, 0, 0, 0, 4, 168, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 4, 0, 29, 29, 384, 1, 'Linus[BR]', 0, 0, 0, 0, 0, 0, 35, 1405, 0, 0, 0, 0, 0, 0, 0, 0, 4, 132, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 5, 0, 12, 33, 47, 0, 'JEFERSON', 0, 0, 0, 0, 0, 0, 18, 820, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 6, 0, 11, 24, 101, 0, 'KROWMAN', 0, 0, 0, 0, 0, 0, 7, 380, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 7, 0, 16, 19, 133, 0, 'd', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 504, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 8, 0, 14, 21, 124, 0, 'niuv', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 141, 1080, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 9, 1, 31, 27, 393, 1, 'b', 0, 0, 0, 0, 0, 0, 26, 1495, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 38);
INSERT INTO `ss_meta_players` VALUES(467, 10, 0, 18, 23, 252, 0, 'AVENTADOR', 0, 0, 0, 0, 0, 0, 15, 1165, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 11, 1, 13, 20, 249, 1, 'VideoMartyr', 0, 0, 0, 0, 0, 0, 11, 570, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 38);
INSERT INTO `ss_meta_players` VALUES(467, 12, 0, 25, 26, 290, 0, 'Rambo', 0, 0, 0, 0, 3, 120, 22, 1070, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 13, 0, 14, 21, 146, 1, 'aquka', 0, 0, 0, 0, 0, 0, 4, 195, 0, 0, 0, 0, 44, 264, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 14, 0, 14, 18, 188, 1, 'sCrIpT_eRrOr', 0, 0, 0, 0, 0, 0, 0, 0, 123, 240, 0, 0, 11, 24, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 15, 0, 22, 14, 490, 0, 'MrSmiles', 0, 0, 0, 0, 0, 0, 16, 740, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 16, 1, 34, 13, 507, 1, 'EX#C0MBATENTE', 0, 0, 0, 0, 0, 0, 0, 0, 199, 840, 0, 0, 0, 0, 0, 0, 12, 361, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 17, 0, 11, 0, 163, 1, '&lt;b&gt;gdm&lt;', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 87, 720, 0, 0, 5, 331, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 18, 0, 18, 22, 85, 1, 'KingWolf', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 106, 984, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(467, 19, 0, 6, 10, 89, 0, 'General_MIDI', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 101, 696, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 1, 0, 1, 8, -42, 1, 'ewwwww', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 36, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 2, 0, 0, 0, 0, 4, 'Kunaifyre', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 3, 0, 18, 13, 165, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 179, 720, 0, 0, 0, 0, 0, 0, 4, 168, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 4, 0, 30, 31, 386, 1, 'Linus[BR]', 0, 0, 0, 0, 0, 0, 41, 1485, 0, 0, 0, 0, 0, 0, 0, 0, 4, 132, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 5, 0, 14, 37, 80, 0, 'JEFERSON', 0, 0, 0, 0, 0, 0, 24, 1080, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 6, 0, 12, 26, 106, 0, 'KROWMAN', 0, 0, 0, 0, 0, 0, 12, 590, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 7, 0, 16, 20, 129, 0, 'd', 0, 0, 7, 54, 0, 0, 0, 0, 0, 0, 0, 0, 122, 576, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 8, 0, 15, 22, 131, 0, 'niuv', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 167, 1272, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 9, 1, 34, 28, 436, 1, 'b', 0, 0, 0, 0, 0, 0, 31, 1735, 0, 0, 0, 0, 0, 0, 0, 0, 2, 164, 7, 38);
INSERT INTO `ss_meta_players` VALUES(468, 10, 0, 18, 23, 252, 0, 'AVENTADOR', 0, 0, 0, 0, 0, 0, 15, 1165, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 11, 1, 14, 23, 262, 1, 'VideoMartyr', 0, 0, 0, 0, 0, 0, 14, 675, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 38);
INSERT INTO `ss_meta_players` VALUES(468, 12, 0, 27, 27, 318, 0, 'Rambo', 0, 0, 0, 0, 3, 120, 22, 1070, 70, 240, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 13, 0, 16, 22, 204, 1, 'aquka', 0, 0, 0, 0, 0, 0, 11, 655, 0, 0, 0, 0, 44, 264, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 14, 0, 15, 19, 196, 1, 'sCrIpT_eRrOr', 0, 0, 0, 0, 0, 0, 7, 210, 136, 255, 0, 0, 11, 24, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 15, 0, 23, 15, 532, 0, 'MrSmiles', 0, 0, 0, 0, 0, 0, 24, 970, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 16, 1, 35, 13, 517, 1, 'EX#C0MBATENTE', 0, 0, 0, 0, 0, 0, 0, 0, 233, 960, 0, 0, 0, 0, 0, 0, 16, 361, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 17, 0, 14, 0, 198, 1, '&lt;b&gt;gdm&lt;', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 148, 1200, 0, 0, 6, 331, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 18, 0, 18, 23, 81, 1, 'KingWolf', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 115, 1080, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(468, 19, 0, 8, 13, 136, 0, 'General_MIDI', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 116, 888, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 0, 0, 4, 2, 56, 1, 'Nostalgia', 0, 0, 4, 18, 0, 0, 10, 510, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 1, 0, 1, 8, -42, 1, 'ewwwww', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 36, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 2, 0, 4, 1, 36, 0, 'Kunaifyre', 0, 0, 14, 72, 0, 0, 0, 0, 0, 0, 7, 240, 0, 0, 0, 0, 4, 155, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 3, 0, 21, 16, 190, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 256, 1185, 0, 0, 0, 0, 0, 0, 6, 168, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 4, 0, 32, 35, 392, 1, 'Linus[BR]', 0, 0, 0, 0, 0, 0, 57, 2010, 0, 0, 0, 0, 0, 0, 0, 0, 4, 132, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 5, 0, 15, 40, 78, 0, 'JEFERSON', 0, 0, 0, 0, 0, 0, 26, 1085, 0, 0, 0, 0, 5, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 6, 0, 14, 31, 109, 0, 'KROWMAN', 0, 0, 0, 0, 0, 0, 21, 845, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 7, 0, 18, 22, 132, 0, 'd', 0, 0, 15, 54, 0, 0, 0, 0, 0, 0, 0, 0, 164, 888, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 8, 0, 19, 24, 176, 0, 'niuv', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 234, 1896, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 9, 1, 34, 33, 416, 1, 'b', 0, 0, 0, 0, 0, 0, 38, 1905, 0, 0, 0, 0, 0, 0, 0, 0, 2, 164, 7, 38);
INSERT INTO `ss_meta_players` VALUES(469, 10, 0, 20, 26, 254, 0, 'AVENTADOR', 0, 0, 0, 0, 0, 0, 28, 1565, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 11, 1, 18, 27, 295, 1, 'VideoMartyr', 0, 0, 0, 0, 0, 0, 24, 1105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 38);
INSERT INTO `ss_meta_players` VALUES(469, 12, 0, 31, 29, 390, 0, 'Rambo', 0, 0, 0, 0, 3, 120, 22, 1070, 146, 525, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 13, 0, 18, 26, 212, 1, 'aquka', 0, 0, 0, 0, 0, 0, 20, 1120, 0, 0, 0, 0, 44, 264, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 14, 0, 16, 20, 203, 1, 'sCrIpT_eRrOr', 0, 0, 0, 0, 0, 0, 15, 365, 136, 255, 0, 0, 11, 24, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 15, 0, 23, 15, 544, 0, 'MrSmiles', 0, 0, 0, 0, 0, 0, 24, 970, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 16, 1, 39, 15, 549, 1, 'EX#C0MBATENTE', 0, 0, 0, 0, 0, 0, 0, 0, 337, 1335, 0, 0, 0, 0, 0, 0, 20, 399, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 17, 0, 18, 1, 234, 1, '&lt;b&gt;gdm&lt;', 0, 0, 3, 18, 0, 0, 0, 0, 0, 0, 0, 0, 185, 1488, 0, 0, 8, 458, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 18, 0, 19, 26, 83, 1, 'KingWolf', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 156, 1488, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(469, 19, 0, 10, 16, 144, 0, 'General_MIDI', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 182, 1344, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 0, 0, 6, 3, 73, 1, 'Nostalgia', 0, 0, 4, 18, 0, 0, 10, 510, 0, 0, 0, 0, 14, 96, 0, 0, 2, 170, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 1, 0, 1, 8, -42, 1, 'ewwwww', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 36, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 3, 0, 22, 18, 193, 0, 'DES|byrus', 0, 0, 0, 0, 0, 0, 0, 0, 291, 1365, 0, 0, 0, 0, 0, 0, 8, 168, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 4, 0, 35, 37, 419, 1, 'Linus[BR]', 0, 0, 0, 0, 0, 0, 66, 2510, 0, 0, 0, 0, 0, 0, 0, 0, 4, 132, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 5, 0, 16, 42, 80, 0, 'JEFERSON', 0, 0, 0, 0, 0, 0, 26, 1085, 0, 0, 0, 0, 17, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 6, 0, 14, 32, 105, 0, 'KROWMAN', 0, 0, 0, 0, 0, 0, 24, 865, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 7, 0, 19, 24, 144, 0, 'd', 0, 0, 20, 54, 0, 0, 0, 0, 0, 0, 0, 0, 208, 1152, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 8, 0, 19, 26, 158, 0, 'niuv', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 264, 2112, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 9, 1, 40, 34, 477, 1, 'b', 0, 0, 0, 0, 0, 0, 48, 2530, 0, 0, 0, 0, 0, 0, 0, 0, 2, 164, 7, 38);
INSERT INTO `ss_meta_players` VALUES(470, 10, 0, 20, 28, 246, 0, 'AVENTADOR', 0, 0, 0, 0, 0, 0, 30, 1565, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 11, 1, 20, 30, 305, 1, 'VideoMartyr', 0, 0, 0, 0, 0, 0, 28, 1310, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 9, 38);
INSERT INTO `ss_meta_players` VALUES(470, 12, 0, 31, 32, 378, 0, 'Rambo', 0, 0, 0, 0, 3, 120, 22, 1070, 178, 585, 0, 0, 0, 0, 0, 0, 2, 2, 30, 133);
INSERT INTO `ss_meta_players` VALUES(470, 13, 0, 19, 27, 218, 1, 'aquka', 0, 0, 0, 0, 0, 0, 24, 1345, 0, 0, 0, 0, 44, 264, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 14, 0, 19, 21, 231, 1, 'sCrIpT_eRrOr', 0, 0, 0, 0, 0, 0, 30, 730, 136, 255, 0, 0, 11, 24, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 15, 0, 23, 15, 544, 0, 'MrSmiles', 0, 0, 0, 0, 0, 0, 24, 970, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 16, 1, 40, 15, 554, 1, 'EX#C0MBATENTE', 0, 0, 0, 0, 0, 0, 0, 0, 403, 1515, 0, 0, 0, 0, 0, 0, 30, 524, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 17, 0, 19, 2, 240, 1, '&lt;b&gt;gdm&lt;', 0, 0, 3, 18, 0, 0, 0, 0, 24, 150, 0, 0, 185, 1488, 0, 0, 8, 458, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 18, 0, 19, 27, 75, 1, 'KingWolf', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 161, 1488, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(470, 19, 0, 13, 20, 160, 0, 'General_MIDI', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 219, 1656, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(471, 0, 0, 0, 0, 0, 0, '&lt;b&gt;gdm&lt;', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(472, 0, 0, 0, 1, -4, 1, 'Hutchy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(472, 1, 0, 0, 0, 0, 4, '&lt;b&gt;gdm&lt;/b&gt;', 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(472, 4, 6, 37, 3, 900, 0, 'pag', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(472, 5, 1, 7, 11, 130, 0, 'TheCheeseMan', 0, 0, 0, 0, 0, 0, 1, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(472, 6, 0, 0, 5, -11, 1, '.:HsOs:.W@RR3N', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(473, 0, 0, 0, 2, -8, 1, 'Hutchy', 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(473, 1, 0, 3, 4, 38, 1, '&lt;b&gt;gdm&lt;/b&gt;', 0, 0, 3, 36, 0, 0, 0, 0, 30, 120, 0, 0, 61, 432, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(473, 4, 6, 42, 4, 958, 0, 'pag', 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 84, 552, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(473, 5, 1, 7, 13, 131, 0, 'TheCheeseMan', 0, 0, 0, 0, 0, 0, 4, 310, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 8, 0);
INSERT INTO `ss_meta_players` VALUES(474, 1, 0, 3, 5, 34, 1, '&lt;b&gt;gdm&lt;/b&gt;', 0, 0, 3, 36, 0, 0, 0, 0, 30, 120, 0, 0, 85, 504, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(474, 4, 7, 43, 4, 1007, 0, 'pag', 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 122, 672, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(474, 5, 1, 7, 13, 135, 0, 'TheCheeseMan', 0, 0, 0, 0, 0, 0, 4, 310, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 8, 0);
INSERT INTO `ss_meta_players` VALUES(475, 0, 0, 0, 0, 0, 1, '&lt;b&gt;gdm&lt;/b&gt;', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(476, 0, 0, 0, 0, 0, 0, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(477, 0, 0, 0, 0, 0, 0, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(478, 0, 0, 0, 0, 0, 0, '&lt;b&gt;gdm&lt;/b&gt;', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 0, 1, 12, 3, 213, 1, 'Woolly{TyD}', 0, 0, 0, 0, 0, 0, 0, 0, 11, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 1, 0, 20, 26, 276, 0, 'Liz-Taylor', 0, 0, 0, 0, 0, 0, 0, 0, 13, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 2, 1, 12, 20, 123, 0, 'FD*aNdy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 3, 0, 3, 12, 34, 0, 'meeniac', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 4, 0, 19, 23, 196, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 5, 0, 8, 20, 34, 0, '[ED]Javy_SoMPeR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 6, 0, 40, 13, 466, 1, '{BoB}Sacerock', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 7, 0, 26, 14, 285, 1, '#M|A#ZOG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 8, 0, 27, 21, 254, 1, 'robert', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 9, 1, 10, 28, 196, 1, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 10, 0, 0, 0, 0, 4, '&lt;b&gt;gdm&lt;/b&gt;', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(479, 11, 1, 25, 31, 286, 0, '[GRF]VectorM12', 0, 0, 0, 0, 1, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(480, 0, 1, 18, 3, 293, 1, 'Woolly{TyD}', 0, 0, 0, 0, 0, 0, 0, 0, 112, 510, 0, 0, 0, 0, 0, 0, 6, 132, 0, 0);
INSERT INTO `ss_meta_players` VALUES(480, 1, 0, 22, 30, 282, 0, 'Liz-Taylor', 0, 0, 0, 0, 0, 0, 0, 0, 66, 285, 0, 0, 0, 0, 0, 0, 0, 0, 13, 95);
INSERT INTO `ss_meta_players` VALUES(480, 2, 1, 13, 23, 111, 0, 'FD*aNdy', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 67, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(480, 3, 0, 5, 15, 42, 0, 'meeniac', 0, 0, 0, 0, 0, 0, 5, 205, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(480, 4, 0, 22, 23, 226, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 129, 165, 0, 0, 0, 0, 0, 0, 6, 352, 0, 0);
INSERT INTO `ss_meta_players` VALUES(480, 5, 0, 9, 23, 32, 0, '[ED]Javy_SoMPeR', 0, 0, 0, 0, 0, 0, 0, 0, 77, 195, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(480, 6, 0, 45, 16, 510, 1, '{BoB}Sacerock', 0, 0, 0, 0, 0, 0, 0, 0, 81, 465, 0, 0, 0, 0, 0, 0, 2, 98, 0, 0);
INSERT INTO `ss_meta_players` VALUES(480, 7, 0, 30, 15, 323, 1, '#M|A#ZOG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 76, 480, 0, 0, 2, 103, 0, 0);
INSERT INTO `ss_meta_players` VALUES(480, 8, 0, 28, 24, 252, 1, 'robert', 0, 0, 4, 18, 0, 0, 0, 0, 72, 195, 0, 0, 0, 0, 0, 0, 4, 27, 0, 0);
INSERT INTO `ss_meta_players` VALUES(480, 9, 1, 11, 31, 194, 1, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 69, 165, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(480, 10, 0, 2, 4, 5, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 59, 312, 0, 0, 2, 61, 0, 0);
INSERT INTO `ss_meta_players` VALUES(480, 11, 1, 25, 36, 299, 0, '[GRF]VectorM12', 0, 0, 0, 0, 9, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 83, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 0, 0, 7, 5, 90, 0, 'meeniac', 0, 0, 0, 0, 0, 0, 4, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 1, 0, 1, 22, -48, 1, 'francisco', 0, 0, 2, 0, 0, 0, 0, 0, 13, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 2, 0, 18, 27, 132, 1, 'LuisFernando_\\\\|', 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 3, 2, 28, 24, 607, 0, 'ILAS', 0, 0, 0, 0, 0, 0, 6, 190, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 4, 0, 33, 14, 317, 1, 'Money$hot', 0, 0, 0, 0, 11, 480, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 5, 0, 10, 25, 112, 0, 'RINALDO', 0, 0, 0, 0, 0, 0, 0, 0, 23, 135, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 6, 0, 2, 5, 36, 1, '|40+|Juuu*', 0, 0, 0, 0, 0, 0, 0, 0, 33, 225, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 7, 1, 28, 26, 379, 0, 'zxcv', 4, 0, 11, 36, 0, 0, 0, 0, 0, 0, 4, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 8, 0, 23, 23, 198, 0, 'ATP', 0, 0, 0, 0, 0, 0, 4, 150, 0, 0, 0, 0, 0, 0, 0, 0, 2, 37, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 9, 0, 12, 16, 67, 0, 'Ammellya', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 10, 0, 11, 25, 121, 1, '+TriiNaRanJus-', 0, 0, 0, 0, 0, 0, 0, 0, 54, 255, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 11, 1, 27, 19, 353, 1, 'TEAMKILLER', 0, 0, 0, 0, 0, 0, 9, 210, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 12, 0, 14, 20, 86, 0, 'arnas', 0, 0, 0, 0, 6, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 13, 0, 17, 10, 304, 0, 'SarahConnor', 0, 0, 0, 0, 0, 0, 0, 0, 26, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 14, 0, 7, 3, 86, 1, 'OMG!spoons', 0, 0, 0, 0, 0, 0, 0, 0, 73, 285, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 15, 0, 6, 7, 45, 0, 'Metalcore', 0, 0, 0, 0, 0, 0, 0, 0, 31, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 16, 0, 35, 22, 430, 1, 'poutine', 0, 0, 0, 0, 0, 0, 5, 285, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 17, 0, 7, 14, 38, 1, 'TeVez', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 18, 0, 5, 11, 31, 1, 'thanksman', 1, 0, 0, 0, 0, 0, 2, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(481, 19, 0, 7, 1, 71, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 552, 0, 0, 1, 135, 28, 152);
INSERT INTO `ss_meta_players` VALUES(482, 0, 1, 24, 11, 364, 0, 'dadadad', 0, 0, 21, 144, 0, 0, 0, 0, 0, 0, 6, 320, 0, 0, 0, 0, 10, 30, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 1, 0, 22, 15, 231, 0, '[ED]Simon', 0, 0, 0, 0, 0, 0, 12, 530, 101, 210, 0, 0, 0, 0, 0, 0, 6, 71, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 2, 0, 7, 23, 22, 1, 'creepergames', 0, 0, 0, 0, 4, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 190);
INSERT INTO `ss_meta_players` VALUES(482, 3, 0, 5, 11, 94, 1, 'quot;LIMPY''S_REVENGE&quot', 0, 0, 0, 0, 0, 0, 3, 85, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 4, 0, 1, 12, -20, 0, 'the-gibber', 0, 0, 0, 0, 0, 0, 5, 210, 0, 0, 0, 0, 0, 0, 0, 0, 16, 453, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 5, 0, -2, 12, -144, 0, 'I-am-Noob', 0, 0, 0, 0, 0, 0, 2, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 6, 0, 16, 21, 133, 1, 'YourWife', 0, 0, 0, 0, 0, 0, 8, 260, 0, 0, 0, 0, 0, 0, 0, 0, 4, 120, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 8, 0, 22, 37, 238, 1, 'WSSSA', 0, 0, 0, 0, 0, 0, 21, 980, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 9, 0, 11, 10, 82, 0, 'sCrIpT_eRrOr', 0, 0, 6, 18, 0, 0, 0, 0, 0, 0, 0, 0, 112, 384, 0, 0, 4, 141, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 10, 0, 11, 16, 124, 1, 'Bronson', 0, 0, 0, 0, 0, 0, 9, 295, 0, 0, 0, 0, 20, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 11, 0, 18, 25, 139, 0, 'thejackalope', 0, 0, 0, 0, 11, 240, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 91, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 12, 0, 0, 3, -12, 0, 'Lord_Painal', 0, 0, 0, 0, 4, 60, 1, 0, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 13, 0, 13, 5, 235, 1, 'Koch', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 14, 0, 4, 18, -28, 1, 'EJK', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 192, 0, 0, 10, 224, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 16, 0, 10, 7, 47, 0, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 240, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(482, 18, 0, 14, 2, 202, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 202, 1464, 0, 0, 2, 78, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 0, 1, 28, 16, 384, 0, 'dadadad', 0, 0, 21, 144, 0, 0, 0, 0, 89, 390, 6, 320, 0, 0, 0, 0, 12, 30, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 1, 0, 27, 20, 274, 0, '[ED]Simon', 0, 0, 0, 0, 0, 0, 12, 530, 298, 945, 0, 0, 0, 0, 0, 0, 6, 71, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 2, 0, 7, 28, 2, 1, 'creepergames', 0, 0, 10, 18, 7, 120, 0, 0, 41, 60, 0, 0, 0, 0, 0, 0, 0, 0, 27, 304);
INSERT INTO `ss_meta_players` VALUES(483, 3, 0, 6, 12, 100, 1, 'quot;LIMPY''S_REVENGE&quot', 0, 0, 0, 0, 0, 0, 6, 215, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 4, 0, 4, 18, 0, 0, 'the-gibber', 0, 0, 0, 0, 0, 0, 11, 525, 0, 0, 0, 0, 0, 0, 0, 0, 36, 599, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 5, 0, 0, 16, -136, 0, 'I-am-Noob', 0, 0, 12, 54, 0, 0, 9, 385, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 6, 0, 22, 26, 175, 1, 'YourWife', 0, 0, 0, 0, 0, 0, 28, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 14, 149, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 7, 0, 0, 0, 0, 1, 'MrTrukiny', 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 8, 0, 26, 45, 245, 1, 'WSSSA', 0, 0, 0, 0, 0, 0, 48, 1785, 0, 0, 0, 0, 26, 96, 0, 0, 2, 27, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 9, 0, 14, 13, 124, 0, 'sCrIpT_eRrOr', 0, 0, 6, 18, 0, 0, 0, 0, 0, 0, 0, 0, 229, 744, 0, 0, 10, 141, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 10, 0, 14, 22, 142, 1, 'Bronson', 0, 0, 0, 0, 0, 0, 31, 820, 0, 0, 0, 0, 20, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 11, 0, 19, 29, 125, 0, 'thejackalope', 0, 0, 0, 0, 34, 780, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 352, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 12, 0, 10, 10, 67, 0, 'Lord_Painal', 0, 0, 0, 0, 16, 420, 20, 1190, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 13, 0, 14, 5, 245, 1, 'Koch', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 59, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 14, 0, 7, 25, -9, 1, 'EJK', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 82, 360, 0, 0, 20, 393, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 15, 0, 0, 0, 0, 4, 'narabocchi', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 16, 0, 12, 12, 47, 0, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 26, 960, 0, 0, 0, 0, 10, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(483, 18, 0, 31, 4, 380, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 203, 990, 0, 0, 257, 1920, 0, 0, 3, 78, 59, 399);
INSERT INTO `ss_meta_players` VALUES(484, 0, 0, 10, 5, 100, 0, 'I-am-Noob', 0, 0, 5, 54, 0, 0, 4, 285, 0, 0, 0, 0, 0, 0, 0, 0, 2, 48, 11, 114);
INSERT INTO `ss_meta_players` VALUES(484, 1, 3, 27, 15, 358, 0, '[ED]Simon', 0, 0, 0, 0, 0, 0, 0, 0, 599, 2760, 0, 0, 85, 696, 0, 0, 12, 0, 15, 76);
INSERT INTO `ss_meta_players` VALUES(484, 3, 0, 1, 20, -80, 0, 'quot;LIMPY''S_REVENGE&quot', 0, 0, 0, 0, 8, 60, 8, 280, 48, 75, 0, 0, 63, 360, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(484, 6, 0, 16, 21, 77, 1, 'Sonoftheb...', 0, 0, 0, 0, 0, 0, 24, 730, 319, 1560, 0, 0, 0, 0, 0, 0, 24, 261, 9, 57);
INSERT INTO `ss_meta_players` VALUES(484, 7, 0, 10, 25, -4, 1, 'MrTrukiny', 7, 50, 32, 216, 15, 600, 19, 380, 0, 0, 0, 0, 11, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(484, 10, 3, 7, 28, 52, 1, 'Bronson', 0, 0, 0, 0, 0, 0, 60, 1435, 0, 0, 0, 0, 0, 0, 0, 0, 4, 45, 0, 0);
INSERT INTO `ss_meta_players` VALUES(484, 11, 1, 30, 12, 275, 0, 'thejackalope', 0, 0, 0, 0, 106, 3900, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 199, 0, 0);
INSERT INTO `ss_meta_players` VALUES(484, 12, 8, 5, 9, 273, 0, 'sCrIpT_eRrOr', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 254, 936, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(484, 18, 7, 34, 9, 566, 1, 'HyPE|GDM', 0, 0, 14, 72, 0, 0, 0, 0, 278, 1230, 0, 0, 319, 2424, 0, 0, 6, 0, 36, 209);
INSERT INTO `ss_meta_players` VALUES(485, 0, 0, 14, 9, 139, 1, 'I-am-Noob', 2, 50, 11, 72, 0, 0, 12, 685, 0, 0, 0, 0, 0, 0, 0, 0, 6, 194, 11, 114);
INSERT INTO `ss_meta_players` VALUES(485, 1, 3, 28, 20, 353, 0, '[ED]Simon', 0, 0, 0, 0, 0, 0, 0, 0, 599, 2760, 0, 0, 138, 984, 0, 0, 14, 0, 15, 76);
INSERT INTO `ss_meta_players` VALUES(485, 3, 0, 1, 23, -92, 0, 'quot;LIMPY''S_REVENGE&quot', 0, 0, 0, 0, 8, 60, 15, 435, 48, 75, 0, 0, 63, 360, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(485, 6, 0, 23, 24, 148, 1, 'Sonoftheb...', 0, 0, 0, 0, 0, 0, 24, 730, 511, 2505, 0, 0, 0, 0, 0, 0, 28, 358, 9, 57);
INSERT INTO `ss_meta_players` VALUES(485, 7, 0, 11, 27, 3, 1, 'MrTrukiny', 7, 50, 63, 360, 15, 600, 20, 380, 0, 0, 0, 0, 11, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(485, 11, 1, 35, 15, 315, 0, 'thejackalope', 0, 0, 0, 0, 119, 4440, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 199, 0, 0);
INSERT INTO `ss_meta_players` VALUES(485, 12, 11, 5, 12, 345, 0, 'sCrIpT_eRrOr', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 312, 1032, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(485, 18, 7, 42, 11, 648, 1, 'HyPE|GDM', 0, 0, 14, 72, 0, 0, 0, 0, 278, 1230, 0, 0, 406, 3048, 0, 0, 8, 78, 71, 380);
INSERT INTO `ss_meta_players` VALUES(486, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(487, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(488, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(489, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(490, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(491, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(492, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(493, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(494, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(495, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(496, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 0, 0, 10, 9, 121, 1, 'mannino', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 81, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 1, 0, 6, 15, 12, 1, 'paula', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 192, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 2, 0, 9, 13, 64, 0, 'stocazzo', 0, 0, 0, 0, 0, 0, 15, 445, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 3, 0, 22, 11, 323, 0, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 12, 450, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 4, 0, 1, 4, -16, 1, 'GioRD30', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 37, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 5, 1, 3, 2, 85, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 528, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 6, 0, 1, 1, 30, 1, '1920', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 7, 1, 9, 10, 153, 0, 'SuperMAZZA', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 264, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 9, 0, 7, 12, 108, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 9, 370, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 10, 2, 10, 9, 312, 0, '+TriiNaRanJus-', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 160, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 11, 1, 16, 6, 290, 0, '.aK|FLUZAO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120, 456, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 12, 0, 9, 7, 134, 0, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 160, 0, 0, 0, 0, 2, 80, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 15, 0, 12, 9, 132, 0, 'sCr3W=', 0, 0, 7, 18, 0, 0, 0, 0, 0, 0, 8, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 17, 0, 9, 13, 79, 1, 'Killer', 0, 0, 0, 0, 0, 0, 4, 170, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 18, 2, 9, 9, 261, 1, 'PORTUGAL-KILLER', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, 432, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(497, 19, 0, 8, 11, 102, 1, 'SarahConnor', 0, 0, 0, 0, 0, 0, 0, 0, 94, 375, 0, 0, 0, 0, 0, 0, 2, 62, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 0, 3, 63, 42, 1338, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 5, 170, 0, 0, 0, 0, 0, 0, 0, 0, 2, 46, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 1, 1, 6, 7, 120, 1, '#M|A#Atrimos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 80, 0, 0, 0, 0, 2, 53, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 2, 4, 46, 34, 1031, 0, '{BoB}Sacerock', 0, 0, 0, 0, 0, 0, 0, 0, 106, 465, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 3, 1, 14, 25, 165, 1, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 4, 0, 4, 4, 57, 1, 'DiamondCassie', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 5, 0, 4, 1, 40, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 288, 0, 0, 2, 131, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 6, 1, 6, 5, 129, 1, '#M|A#ZOG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 7, 4, 43, 44, 1156, 1, 'BARCELONASC', 1, 50, 0, 0, 0, 0, 0, 0, 85, 480, 0, 0, 0, 0, 0, 0, 2, 155, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 8, 2, 35, 44, 778, 1, 'shuffle', 0, 0, 0, 0, 0, 0, 0, 0, 53, 210, 0, 0, 0, 0, 0, 0, 2, 6, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 9, 0, 17, 37, 84, 0, 'samesame2013', 0, 0, 0, 0, 0, 0, 10, 305, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 10, 0, 48, 49, 549, 0, 'guayasamin', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 144, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(498, 11, 2, 33, 34, 717, 0, '.:HsOs:.Nest', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 240, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(499, 0, 0, 1, 2, 35, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 11, 540, 0, 0, 0, 0, 0, 0, 0, 0, 2, 103, 0, 0);
INSERT INTO `ss_meta_players` VALUES(499, 1, 0, 3, 4, 49, 1, '#M|A#Atrimos', 0, 0, 0, 0, 0, 0, 0, 0, 70, 255, 6, 320, 0, 0, 0, 0, 2, 138, 0, 0);
INSERT INTO `ss_meta_players` VALUES(499, 2, 0, 4, 1, 45, 0, '{BoB}Sacerock', 1, 50, 0, 0, 0, 0, 0, 0, 55, 240, 0, 0, 0, 0, 0, 0, 4, 0, 55, 209);
INSERT INTO `ss_meta_players` VALUES(499, 3, 0, 0, 3, -12, 1, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(499, 4, 0, 1, 1, 6, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(499, 5, 0, 4, 3, 33, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 57, 195, 0, 0, 22, 216, 0, 0, 3, 121, 0, 0);
INSERT INTO `ss_meta_players` VALUES(499, 6, 0, 4, 3, 68, 1, '#M|A#ZOG', 0, 0, 0, 0, 0, 0, 0, 0, 119, 630, 0, 0, 16, 48, 0, 0, 2, 128, 0, 0);
INSERT INTO `ss_meta_players` VALUES(499, 7, 0, 1, 2, 4, 1, 'He_man_Sam', 0, 0, 0, 0, 0, 0, 5, 115, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(499, 9, 0, 2, 4, 4, 0, 'samesame2013', 0, 0, 0, 0, 0, 0, 11, 405, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(499, 11, 1, 1, 2, 78, 0, '.:HsOs:.Nest', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 240, 0, 0, 2, 169, 0, 0);
INSERT INTO `ss_meta_players` VALUES(500, 0, 0, 1, 2, 35, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 11, 540, 0, 0, 0, 0, 0, 0, 0, 0, 2, 103, 0, 0);
INSERT INTO `ss_meta_players` VALUES(500, 1, 0, 3, 5, 49, 1, '#M|A#Atrimos', 0, 0, 0, 0, 0, 0, 0, 0, 82, 330, 6, 320, 0, 0, 0, 0, 2, 138, 0, 0);
INSERT INTO `ss_meta_players` VALUES(500, 2, 0, 4, 1, 45, 0, '{BoB}Sacerock', 1, 50, 0, 0, 0, 0, 0, 0, 55, 240, 0, 0, 0, 0, 0, 0, 4, 0, 55, 209);
INSERT INTO `ss_meta_players` VALUES(500, 3, 0, 0, 3, -12, 1, 'Mot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(500, 4, 0, 1, 1, 6, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 120, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(500, 5, 0, 4, 3, 33, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 57, 195, 0, 0, 22, 216, 0, 0, 3, 121, 0, 0);
INSERT INTO `ss_meta_players` VALUES(500, 6, 0, 4, 3, 68, 1, '#M|A#ZOG', 0, 0, 0, 0, 0, 0, 0, 0, 119, 630, 0, 0, 16, 48, 0, 0, 2, 128, 0, 0);
INSERT INTO `ss_meta_players` VALUES(500, 7, 0, 1, 2, 4, 1, 'He_man_Sam', 0, 0, 0, 0, 0, 0, 5, 115, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(500, 9, 0, 2, 4, 4, 0, 'samesame2013', 0, 0, 0, 0, 0, 0, 11, 405, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(500, 11, 1, 2, 2, 78, 0, '.:HsOs:.Nest', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 42, 336, 0, 0, 2, 169, 0, 0);
INSERT INTO `ss_meta_players` VALUES(501, 0, 0, 10, 9, 140, 0, 'DK', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(501, 1, 1, 22, 9, 295, 1, 'SrPER$IAN', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(501, 2, 1, 15, 8, 204, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(501, 3, 1, 9, 16, 130, 0, 'Yacu', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(501, 4, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(501, 6, 0, 6, 9, 98, 0, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(501, 7, 0, 8, 11, 89, 1, 'B}evanzo23', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(501, 8, 0, 19, 14, 196, 0, 'ElCre#M|A#', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(501, 9, 0, 8, 16, 108, 0, 'St4rKiller', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(501, 10, 1, 8, 10, 174, 1, 'Django', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(502, 0, 0, 14, 15, 222, 0, 'DK', 0, 0, 8, 18, 0, 0, 0, 0, 0, 0, 0, 0, 125, 480, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(502, 1, 1, 27, 15, 384, 1, 'SrPER$IAN', 1, 50, 31, 108, 0, 0, 0, 0, 0, 0, 19, 640, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(502, 2, 1, 20, 12, 254, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 112, 624, 0, 0, 8, 106, 0, 0);
INSERT INTO `ss_meta_players` VALUES(502, 3, 1, 10, 22, 167, 0, 'Yacu', 0, 0, 0, 0, 0, 0, 23, 610, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(502, 4, 0, 10, 2, 173, 1, 'HyPE|GDM', 0, 0, 2, 18, 0, 0, 0, 0, 205, 915, 0, 0, 0, 0, 0, 0, 2, 66, 31, 133);
INSERT INTO `ss_meta_players` VALUES(502, 5, 0, 0, 0, 0, 1, 'thanksman', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(502, 6, 0, 11, 15, 173, 0, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 188, 645, 0, 0, 0, 0, 0, 0, 6, 29, 0, 0);
INSERT INTO `ss_meta_players` VALUES(502, 7, 1, 13, 15, 333, 1, 'B}evanzo23', 0, 0, 0, 0, 0, 0, 10, 405, 13, 120, 0, 0, 0, 0, 0, 0, 6, 95, 0, 0);
INSERT INTO `ss_meta_players` VALUES(502, 8, 0, 24, 20, 317, 0, 'ElCre#M|A#', 6, 100, 0, 0, 0, 0, 0, 0, 0, 0, 9, 720, 0, 0, 0, 0, 4, 18, 0, 0);
INSERT INTO `ss_meta_players` VALUES(502, 9, 1, 10, 23, 201, 0, 'St4rKiller', 0, 0, 0, 0, 0, 0, 14, 705, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(502, 10, 1, 13, 15, 215, 1, 'Django', 0, 0, 0, 0, 0, 0, 0, 0, 165, 555, 0, 0, 0, 0, 0, 0, 6, 70, 0, 0);
INSERT INTO `ss_meta_players` VALUES(502, 11, 0, 2, 3, 77, 0, 'MAULET', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 45, 192, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(503, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 0, 0, 0, 1, -4, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 1, 0, 1, 0, 10, 0, 'SrPER$IAN', 2, 0, 6, 36, 0, 0, 0, 0, 0, 0, 3, 80, 0, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 2, 0, 0, 2, -8, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 3, 0, 1, 0, 10, 0, 'Yacu', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 4, 0, 2, 0, 20, 0, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 1, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 5, 0, 0, 2, -8, 1, 'PetraMaffay', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 6, 0, 2, 1, 16, 0, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 26, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 7, 0, 1, 1, 50, 1, 'B}evanzo23', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 8, 0, 1, 1, 6, 1, 'wtfisthisgame', 0, 0, 0, 0, 0, 0, 0, 0, 19, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 9, 0, 0, 1, 22, 0, 'St4rKiller', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 10, 0, 0, 0, 0, 4, 'Destroyer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(504, 11, 0, 1, 0, 10, 0, 'MAULET', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(505, 0, 0, 14, 7, 230, 0, 'HyPE|GDM', 0, 0, 3, 36, 0, 0, 0, 0, 292, 1320, 0, 0, 49, 432, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(505, 1, 0, 2, 2, 36, 0, 'Cookiexnmilk', 0, 0, 0, 0, 0, 0, 8, 285, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(505, 2, 0, 6, 9, 111, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 189, 912, 0, 0, 8, 116, 0, 0);
INSERT INTO `ss_meta_players` VALUES(505, 3, 1, 10, 5, 263, 0, 'Yacu', 0, 0, 0, 0, 0, 0, 24, 1455, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(505, 4, 0, 9, 7, 98, 0, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 18, 785, 0, 0, 0, 0, 0, 0, 0, 0, 6, 138, 0, 0);
INSERT INTO `ss_meta_players` VALUES(505, 5, 1, 10, 6, 265, 1, 'PetraMaffay', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 199, 1200, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(505, 6, 0, 5, 10, 52, 0, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 307, 780, 0, 0, 0, 0, 0, 0, 8, 22, 0, 0);
INSERT INTO `ss_meta_players` VALUES(505, 7, 1, 8, 8, 187, 1, 'B}evanzo23', 5, 50, 0, 0, 0, 0, 0, 0, 0, 0, 6, 160, 88, 552, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(505, 8, 0, 7, 9, 105, 1, 'wtfisthisgame', 0, 0, 0, 0, 0, 0, 0, 0, 227, 690, 0, 0, 0, 0, 0, 0, 18, 372, 0, 0);
INSERT INTO `ss_meta_players` VALUES(505, 9, 0, 4, 9, 73, 0, 'St4rKiller', 1, 0, 8, 36, 0, 0, 0, 0, 150, 390, 0, 0, 0, 0, 0, 0, 12, 6, 14, 0);
INSERT INTO `ss_meta_players` VALUES(505, 10, 0, 3, 5, 36, 1, 'Destroyer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 408, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(505, 11, 0, 1, 1, 6, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 23, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(506, 0, 0, 23, 9, 391, 0, 'HyPE|GDM', 0, 0, 6, 36, 0, 0, 0, 0, 183, 975, 0, 0, 0, 0, 0, 0, 1, 1, 31, 247);
INSERT INTO `ss_meta_players` VALUES(506, 1, 1, 9, 6, 233, 0, 'Cookiexnmilk', 0, 0, 0, 0, 0, 0, 17, 470, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(506, 2, 0, 13, 16, 186, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 112, 888, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(506, 3, 1, 14, 10, 329, 1, 'Yacu', 0, 0, 0, 0, 0, 0, 16, 605, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(506, 4, 0, 16, 12, 289, 0, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 20, 580, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(506, 5, 1, 17, 10, 338, 1, 'PetraMaffay', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 110, 720, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(506, 6, 0, 10, 20, 141, 0, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 192, 615, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(506, 7, 0, 4, 0, 116, 1, 'J&amp;A', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 45, 312, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(506, 8, 1, 8, 16, 214, 1, 'wtfisthisgame', 0, 0, 0, 0, 0, 0, 0, 0, 89, 285, 0, 0, 0, 0, 0, 0, 12, 181, 0, 0);
INSERT INTO `ss_meta_players` VALUES(506, 9, 0, 4, 11, 37, 0, 'MAULET', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 58, 192, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(506, 11, 0, 7, 8, 89, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 149, 585, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(507, 0, 0, 26, 9, 433, 0, 'HyPE|GDM', 0, 0, 6, 36, 0, 0, 0, 0, 280, 1290, 0, 0, 0, 0, 0, 0, 1, 1, 31, 247);
INSERT INTO `ss_meta_players` VALUES(507, 1, 1, 10, 9, 231, 0, 'Cookiexnmilk', 0, 0, 0, 0, 0, 0, 23, 670, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(507, 2, 0, 0, 0, 0, 4, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(507, 3, 1, 15, 13, 327, 1, 'Yacu', 0, 0, 0, 0, 0, 0, 23, 700, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(507, 4, 0, 17, 14, 291, 0, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 30, 775, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(507, 5, 1, 18, 12, 344, 1, 'PetraMaffay', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 152, 912, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(507, 6, 0, 14, 22, 164, 0, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 290, 915, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(507, 7, 1, 6, 1, 237, 1, 'J&amp;A', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 78, 552, 0, 0, 8, 26, 0, 0);
INSERT INTO `ss_meta_players` VALUES(507, 8, 1, 11, 19, 265, 1, 'wtfisthisgame', 0, 0, 0, 0, 0, 0, 0, 0, 180, 630, 0, 0, 0, 0, 0, 0, 15, 243, 0, 0);
INSERT INTO `ss_meta_players` VALUES(507, 9, 0, 6, 14, 60, 0, 'MAULET', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 408, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(507, 10, 0, 0, 0, 0, 4, 'AssasinsGD', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(507, 11, 1, 9, 9, 205, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 230, 885, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(508, 0, 0, 33, 10, 508, 0, 'HyPE|GDM', 0, 0, 6, 36, 0, 0, 0, 0, 501, 2025, 0, 0, 0, 0, 0, 0, 2, 1, 31, 247);
INSERT INTO `ss_meta_players` VALUES(508, 1, 0, 1, 0, 11, 0, 'GENGUNNER02', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(508, 2, 0, 3, 3, 41, 0, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 456, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(508, 3, 1, 15, 17, 311, 1, 'Yacu', 0, 0, 0, 0, 0, 0, 32, 885, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(508, 4, 0, 24, 18, 369, 0, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 54, 1645, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(508, 5, 1, 22, 16, 389, 1, 'PetraMaffay', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 227, 1344, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(508, 6, 0, 14, 27, 167, 1, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 394, 1170, 0, 0, 0, 0, 0, 0, 8, 113, 0, 0);
INSERT INTO `ss_meta_players` VALUES(508, 7, 2, 9, 5, 353, 0, 'J&amp;A', 3, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 188, 1128, 0, 0, 10, 26, 0, 0);
INSERT INTO `ss_meta_players` VALUES(508, 8, 1, 15, 26, 314, 1, 'wtfisthisgame', 0, 0, 0, 0, 0, 0, 0, 0, 318, 1215, 0, 0, 0, 0, 0, 0, 22, 483, 0, 0);
INSERT INTO `ss_meta_players` VALUES(508, 9, 0, 8, 20, 56, 0, 'MAULET', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 183, 960, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(508, 11, 1, 16, 12, 366, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 357, 1410, 0, 0, 0, 0, 0, 0, 14, 38, 26, 152);
INSERT INTO `ss_meta_players` VALUES(509, 0, 2, 54, 15, 967, 0, 'HyPE|GDM', 0, 0, 6, 36, 0, 0, 0, 0, 1030, 4140, 0, 0, 0, 0, 0, 0, 8, 625, 31, 247);
INSERT INTO `ss_meta_players` VALUES(509, 1, 0, 4, 12, 5, 0, 'GENGUNNER02', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 147, 600, 0, 0, 0, 0, 5, 19);
INSERT INTO `ss_meta_players` VALUES(509, 2, 0, 11, 7, 106, 0, 'HyPE|JoeSmith', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 0, 0, 234, 1848, 0, 0, 9, 153, 0, 0);
INSERT INTO `ss_meta_players` VALUES(509, 3, 1, 18, 32, 303, 1, 'Yacu', 0, 0, 0, 0, 0, 0, 62, 1735, 1, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(509, 4, 0, 34, 24, 541, 0, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 97, 2960, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(509, 5, 1, 28, 32, 419, 1, 'PetraMaffay', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 402, 2520, 0, 0, 4, 63, 0, 0);
INSERT INTO `ss_meta_players` VALUES(509, 6, 0, 21, 42, 239, 1, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 700, 2025, 0, 0, 0, 0, 0, 0, 10, 113, 0, 0);
INSERT INTO `ss_meta_players` VALUES(509, 7, 3, 34, 10, 880, 0, 'J&amp;A', 3, 50, 4, 36, 0, 0, 0, 0, 0, 0, 0, 0, 525, 3456, 0, 0, 12, 26, 0, 0);
INSERT INTO `ss_meta_players` VALUES(509, 8, 1, 27, 42, 475, 1, 'wtfisthisgame', 0, 0, 0, 0, 0, 0, 0, 0, 771, 2730, 0, 0, 0, 0, 0, 0, 34, 657, 0, 0);
INSERT INTO `ss_meta_players` VALUES(509, 9, 0, 8, 30, 51, 0, 'MAULET', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 300, 1536, 0, 0, 12, 13, 16, 76);
INSERT INTO `ss_meta_players` VALUES(509, 10, 0, 0, 0, 0, 4, 'Fo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(509, 11, 1, 24, 22, 474, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 571, 2190, 0, 0, 0, 0, 0, 0, 26, 440, 29, 152);
INSERT INTO `ss_meta_players` VALUES(510, 0, 2, 63, 18, 1123, 0, 'HyPE|GDM', 1, 0, 6, 36, 0, 0, 0, 0, 1202, 5025, 0, 0, 0, 0, 0, 0, 10, 817, 31, 247);
INSERT INTO `ss_meta_players` VALUES(510, 1, 0, 0, 0, 0, 4, 'DiamondCassie', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(510, 2, 0, 14, 9, 164, 0, 'HyPE|JoeSmith', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 0, 0, 301, 2256, 0, 0, 16, 153, 0, 0);
INSERT INTO `ss_meta_players` VALUES(510, 3, 1, 19, 38, 309, 1, 'Yacu', 0, 0, 0, 0, 0, 0, 62, 1735, 68, 135, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(510, 4, 0, 39, 27, 685, 0, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 115, 3625, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(510, 5, 1, 34, 37, 516, 1, 'PetraMaffay', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 524, 3312, 0, 0, 4, 63, 0, 0);
INSERT INTO `ss_meta_players` VALUES(510, 6, 0, 22, 48, 247, 1, 'quicktime', 0, 0, 0, 0, 0, 0, 0, 0, 844, 2265, 0, 0, 0, 0, 0, 0, 14, 113, 0, 0);
INSERT INTO `ss_meta_players` VALUES(510, 7, 4, 41, 13, 1040, 0, 'J&amp;A', 3, 50, 4, 36, 0, 0, 0, 0, 0, 0, 0, 0, 649, 4368, 0, 0, 14, 26, 0, 0);
INSERT INTO `ss_meta_players` VALUES(510, 8, 2, 30, 45, 599, 1, 'wtfisthisgame', 0, 0, 0, 0, 0, 0, 0, 0, 849, 2970, 0, 0, 0, 0, 0, 0, 44, 773, 0, 0);
INSERT INTO `ss_meta_players` VALUES(510, 9, 0, 10, 35, 64, 0, 'MAULET', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 381, 1872, 0, 0, 14, 13, 16, 76);
INSERT INTO `ss_meta_players` VALUES(510, 10, 0, 3, 4, 30, 1, 'Fo', 0, 0, 0, 0, 0, 0, 15, 455, 0, 0, 0, 0, 0, 0, 0, 0, 2, 98, 16, 19);
INSERT INTO `ss_meta_players` VALUES(510, 11, 1, 26, 24, 548, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 666, 2490, 0, 0, 0, 0, 0, 0, 32, 440, 29, 152);
INSERT INTO `ss_meta_players` VALUES(511, 0, 2, 23, 12, 402, 0, 'HyPE|GDM', 0, 0, 17, 126, 0, 0, 0, 0, 51, 180, 0, 0, 398, 2376, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(511, 1, 1, 29, 17, 492, 0, 'J&amp;A', 0, 0, 8, 36, 0, 0, 0, 0, 545, 2130, 0, 0, 27, 144, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(511, 2, 0, 11, 23, 101, 1, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 334, 1410, 0, 0, 0, 0, 0, 0, 12, 179, 12, 114);
INSERT INTO `ss_meta_players` VALUES(511, 3, 1, 11, 21, 157, 0, 'St4rKiller', 0, 0, 0, 0, 0, 0, 30, 895, 147, 435, 0, 0, 57, 456, 0, 0, 0, 0, 24, 57);
INSERT INTO `ss_meta_players` VALUES(511, 4, 0, 22, 22, 212, 1, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 18, 905, 0, 0, 0, 0, 217, 1440, 0, 0, 16, 371, 36, 247);
INSERT INTO `ss_meta_players` VALUES(511, 5, 2, 22, 21, 418, 1, '[ED]Carlos', 0, 0, 14, 18, 0, 0, 0, 0, 0, 0, 0, 0, 378, 2256, 0, 0, 4, 145, 0, 0);
INSERT INTO `ss_meta_players` VALUES(511, 6, 0, 8, 12, 139, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 129, 696, 0, 0, 10, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(511, 7, 0, 0, 10, -40, 0, 'rodrigo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(511, 8, 0, 11, 5, 163, 0, '1Cap', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 205, 1344, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(511, 9, 0, 0, 4, -16, 1, '2003johnp', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(511, 10, 0, 0, 0, 0, 4, 'warrior', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(511, 11, 0, 2, 1, 38, 0, 'ElCre#M|A#', 0, 0, 0, 0, 0, 0, 0, 0, 36, 165, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(512, 0, 2, 23, 12, 402, 0, 'HyPE|GDM', 0, 0, 17, 126, 0, 0, 0, 0, 51, 180, 0, 0, 398, 2376, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(512, 1, 1, 30, 18, 498, 0, 'J&amp;A', 0, 0, 8, 36, 0, 0, 0, 0, 578, 2280, 0, 0, 27, 144, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(512, 2, 0, 12, 24, 107, 1, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 343, 1425, 0, 0, 0, 0, 0, 0, 12, 179, 12, 114);
INSERT INTO `ss_meta_players` VALUES(512, 3, 1, 11, 21, 157, 0, 'St4rKiller', 0, 0, 0, 0, 0, 0, 30, 895, 147, 435, 0, 0, 57, 456, 0, 0, 1, 0, 24, 57);
INSERT INTO `ss_meta_players` VALUES(512, 4, 0, 22, 23, 208, 1, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 19, 905, 0, 0, 0, 0, 217, 1440, 0, 0, 16, 371, 36, 247);
INSERT INTO `ss_meta_players` VALUES(512, 5, 2, 23, 21, 429, 1, '[ED]Carlos', 0, 0, 14, 18, 0, 0, 0, 0, 0, 0, 0, 0, 396, 2400, 0, 0, 4, 145, 0, 0);
INSERT INTO `ss_meta_players` VALUES(512, 6, 0, 8, 12, 139, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 134, 696, 0, 0, 10, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(512, 7, 0, 0, 10, -40, 0, 'rodrigo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(512, 8, 0, 12, 6, 169, 0, '1Cap', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 219, 1464, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(512, 9, 0, 0, 4, -16, 1, '2003johnp', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(512, 10, 0, 0, 0, 0, 4, 'warrior', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(512, 11, 0, 2, 1, 38, 0, 'ElCre#M|A#', 0, 0, 0, 0, 0, 0, 0, 0, 41, 195, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(513, 0, 2, 27, 13, 438, 0, 'HyPE|GDM', 0, 0, 17, 126, 0, 0, 0, 0, 51, 180, 0, 0, 437, 2760, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(513, 1, 1, 31, 19, 509, 0, 'J&amp;A', 0, 0, 8, 36, 0, 0, 0, 0, 632, 2550, 0, 0, 27, 144, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(513, 2, 0, 12, 27, 95, 1, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 343, 1425, 0, 0, 20, 216, 0, 0, 12, 179, 12, 114);
INSERT INTO `ss_meta_players` VALUES(513, 3, 2, 10, 23, 205, 0, 'St4rKiller', 0, 0, 0, 0, 0, 0, 32, 945, 147, 435, 0, 0, 57, 456, 0, 0, 2, 63, 24, 57);
INSERT INTO `ss_meta_players` VALUES(513, 4, 0, 24, 25, 221, 1, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 25, 1075, 0, 0, 0, 0, 217, 1440, 0, 0, 16, 371, 36, 247);
INSERT INTO `ss_meta_players` VALUES(513, 5, 2, 25, 24, 438, 1, '[ED]Carlos', 0, 0, 14, 18, 0, 0, 0, 0, 0, 0, 0, 0, 427, 2592, 0, 0, 4, 145, 0, 0);
INSERT INTO `ss_meta_players` VALUES(513, 6, 0, 8, 13, 135, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 136, 696, 0, 0, 12, 33, 0, 0);
INSERT INTO `ss_meta_players` VALUES(513, 7, 0, 0, 11, -44, 0, 'rodrigo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(513, 8, 1, 14, 6, 274, 0, '1Cap', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 261, 1656, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(513, 10, 0, 0, 0, 0, 4, 'warrior', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(513, 11, 0, 4, 1, 59, 0, 'ElCre#M|A#', 0, 0, 0, 0, 0, 0, 0, 0, 76, 360, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(514, 0, 2, 31, 14, 488, 1, 'HyPE|GDM', 0, 0, 17, 126, 0, 0, 0, 0, 51, 180, 0, 0, 473, 3144, 0, 0, 3, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(514, 1, 1, 33, 22, 518, 0, 'J&amp;A', 0, 0, 8, 36, 0, 0, 0, 0, 717, 2835, 0, 0, 27, 144, 0, 0, 8, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(514, 2, 0, 13, 29, 109, 0, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 343, 1425, 0, 0, 33, 360, 0, 0, 12, 179, 12, 114);
INSERT INTO `ss_meta_players` VALUES(514, 3, 2, 10, 26, 193, 0, 'St4rKiller', 0, 0, 0, 0, 0, 0, 35, 1010, 147, 435, 2, 0, 57, 456, 0, 0, 2, 63, 24, 57);
INSERT INTO `ss_meta_players` VALUES(514, 4, 0, 26, 27, 245, 1, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 34, 1355, 0, 0, 0, 0, 217, 1440, 0, 0, 16, 371, 36, 247);
INSERT INTO `ss_meta_players` VALUES(514, 5, 2, 28, 27, 458, 1, '[ED]Carlos', 0, 0, 14, 18, 0, 0, 0, 0, 0, 0, 0, 0, 476, 3024, 0, 0, 6, 145, 0, 0);
INSERT INTO `ss_meta_players` VALUES(514, 6, 0, 10, 13, 155, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 174, 888, 0, 0, 14, 33, 0, 0);
INSERT INTO `ss_meta_players` VALUES(514, 7, 0, 0, 12, -48, 0, 'rodrigo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(514, 8, 1, 16, 8, 286, 0, '1Cap', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 295, 1920, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(514, 9, 0, 0, 0, 0, 4, 'Lon3r', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(514, 10, 0, 0, 1, -4, 1, 'lisa', 0, 0, 4, 36, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(514, 11, 0, 8, 3, 122, 0, 'ElCre#M|A#', 0, 0, 0, 0, 0, 0, 0, 0, 128, 705, 0, 0, 0, 0, 0, 0, 4, 0, 12, 57);
INSERT INTO `ss_meta_players` VALUES(515, 0, 2, 35, 16, 550, 1, 'HyPE|GDM', 0, 0, 17, 126, 0, 0, 0, 0, 51, 180, 0, 0, 527, 3528, 0, 0, 5, 132, 0, 0);
INSERT INTO `ss_meta_players` VALUES(515, 1, 1, 35, 25, 558, 0, 'J&amp;A', 0, 0, 8, 36, 0, 0, 0, 0, 824, 3195, 0, 0, 27, 144, 0, 0, 10, 53, 0, 0);
INSERT INTO `ss_meta_players` VALUES(515, 2, 1, 14, 31, 196, 0, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 0, 0, 343, 1425, 0, 0, 76, 552, 0, 0, 12, 179, 12, 114);
INSERT INTO `ss_meta_players` VALUES(515, 3, 2, 11, 26, 215, 0, 'St4rKiller', 0, 0, 0, 0, 0, 0, 35, 1010, 147, 435, 7, 80, 57, 456, 0, 0, 2, 63, 24, 57);
INSERT INTO `ss_meta_players` VALUES(515, 4, 0, 27, 30, 243, 1, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 44, 1760, 0, 0, 0, 0, 217, 1440, 0, 0, 16, 371, 36, 247);
INSERT INTO `ss_meta_players` VALUES(515, 5, 2, 31, 28, 485, 1, '[ED]Carlos', 0, 0, 14, 18, 0, 0, 0, 0, 0, 0, 0, 0, 522, 3288, 0, 0, 12, 254, 0, 0);
INSERT INTO `ss_meta_players` VALUES(515, 6, 0, 11, 16, 154, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 209, 1152, 0, 0, 20, 100, 0, 0);
INSERT INTO `ss_meta_players` VALUES(515, 7, 0, 0, 14, -56, 0, 'rodrigo', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(515, 8, 1, 18, 12, 321, 0, '1Cap', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 341, 2352, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(515, 9, 0, 0, 0, 0, 1, 'Lon3r', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(515, 10, 0, 4, 3, 48, 1, 'lisa', 0, 0, 7, 36, 0, 0, 0, 0, 0, 0, 7, 400, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(515, 11, 0, 12, 5, 161, 0, 'ElCre#M|A#', 0, 0, 0, 0, 0, 0, 0, 0, 222, 1110, 0, 0, 0, 0, 0, 0, 9, 0, 12, 57);
INSERT INTO `ss_meta_players` VALUES(516, 0, 2, 42, 20, 667, 1, 'HyPE|GDM', 0, 0, 17, 126, 0, 0, 0, 0, 78, 300, 0, 0, 622, 4104, 0, 0, 6, 132, 0, 0);
INSERT INTO `ss_meta_players` VALUES(516, 1, 1, 42, 29, 637, 0, 'J&amp;A', 1, 50, 19, 90, 0, 0, 0, 0, 965, 3930, 0, 0, 27, 144, 0, 0, 10, 53, 0, 0);
INSERT INTO `ss_meta_players` VALUES(516, 2, 1, 17, 33, 220, 0, 'HyPE|JoeSmith', 0, 0, 0, 0, 0, 0, 5, 185, 343, 1425, 0, 0, 95, 696, 0, 0, 12, 179, 12, 114);
INSERT INTO `ss_meta_players` VALUES(516, 3, 2, 11, 32, 191, 0, 'St4rKiller', 0, 0, 0, 0, 0, 0, 44, 1060, 147, 435, 8, 80, 57, 456, 0, 0, 2, 63, 24, 57);
INSERT INTO `ss_meta_players` VALUES(516, 4, 0, 29, 34, 272, 1, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 60, 2165, 0, 0, 0, 0, 217, 1440, 0, 0, 20, 371, 36, 247);
INSERT INTO `ss_meta_players` VALUES(516, 5, 2, 38, 31, 561, 1, '[ED]Carlos', 0, 0, 26, 72, 0, 0, 0, 0, 0, 0, 0, 0, 611, 3840, 0, 0, 14, 254, 0, 0);
INSERT INTO `ss_meta_players` VALUES(516, 6, 0, 14, 18, 179, 1, '[ED]iluminatiox', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 243, 1368, 0, 0, 22, 100, 0, 0);
INSERT INTO `ss_meta_players` VALUES(516, 7, 0, 0, 17, -68, 0, 'rodrigo', 0, 0, 6, 18, 0, 0, 0, 0, 0, 0, 13, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(516, 8, 1, 23, 17, 386, 0, '1Cap', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 429, 2808, 0, 0, 6, 0, 16, 57);
INSERT INTO `ss_meta_players` VALUES(516, 9, 0, 3, 4, 57, 1, 'Lon3r', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 456, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(516, 10, 0, 5, 5, 52, 1, 'lisa', 0, 0, 13, 36, 0, 0, 0, 0, 0, 0, 12, 640, 0, 0, 0, 0, 4, 160, 0, 0);
INSERT INTO `ss_meta_players` VALUES(516, 11, 0, 17, 8, 214, 0, 'ElCre#M|A#', 0, 0, 0, 0, 0, 0, 0, 0, 353, 1680, 0, 0, 0, 0, 0, 0, 14, 36, 12, 57);
INSERT INTO `ss_meta_players` VALUES(517, 0, 3, 57, 28, 914, 1, 'HyPE|GDM', 0, 0, 17, 126, 0, 0, 0, 0, 127, 495, 0, 0, 872, 5640, 0, 0, 9, 132, 0, 0);
INSERT INTO `ss_meta_players` VALUES(517, 1, 2, 59, 40, 922, 0, 'J&amp;A', 1, 50, 25, 108, 0, 0, 0, 0, 1391, 5805, 1, 240, 27, 144, 0, 0, 12, 53, 0, 0);
INSERT INTO `ss_meta_players` VALUES(517, 2, 0, 6, 8, 101, 0, '#M|A#Atrimos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 137, 888, 0, 0, 8, 36, 0, 0);
INSERT INTO `ss_meta_players` VALUES(517, 3, 2, 16, 45, 218, 0, 'St4rKiller', 0, 0, 0, 0, 5, 0, 49, 1235, 235, 720, 19, 320, 57, 456, 0, 0, 2, 63, 38, 76);
INSERT INTO `ss_meta_players` VALUES(517, 4, 0, 41, 44, 396, 1, 'Perfect_Black', 0, 0, 0, 0, 6, 180, 90, 3670, 0, 0, 0, 0, 222, 1440, 0, 0, 26, 483, 36, 247);
INSERT INTO `ss_meta_players` VALUES(517, 5, 2, 46, 40, 669, 1, '[ED]Carlos', 0, 0, 27, 72, 0, 0, 0, 0, 0, 0, 0, 0, 811, 4968, 0, 0, 26, 254, 0, 0);
INSERT INTO `ss_meta_players` VALUES(517, 6, 0, 1, 6, -2, 1, 'IKeepDying', 0, 0, 0, 0, 0, 0, 7, 155, 0, 0, 0, 0, 4, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(517, 7, 0, 2, 0, 45, 1, 'Cujum', 0, 0, 0, 0, 0, 0, 0, 0, 25, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(517, 8, 2, 29, 30, 581, 0, '1Cap', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 670, 3696, 0, 0, 10, 249, 16, 57);
INSERT INTO `ss_meta_players` VALUES(517, 9, 0, 16, 13, 167, 1, 'Lon3r', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 374, 2184, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(517, 10, 1, 3, 3, 108, 0, '#M|A#ZOG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 66, 408, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(517, 11, 0, 34, 13, 413, 0, 'ElCre#M|A#', 1, 0, 0, 0, 0, 0, 0, 0, 656, 2985, 0, 0, 0, 0, 0, 0, 26, 36, 42, 209);
INSERT INTO `ss_meta_players` VALUES(518, 0, 3, 62, 31, 1008, 1, 'HyPE|GDM', 0, 0, 17, 126, 0, 0, 0, 0, 161, 600, 0, 0, 914, 5856, 0, 0, 11, 132, 0, 0);
INSERT INTO `ss_meta_players` VALUES(518, 1, 2, 64, 42, 960, 0, 'J&amp;A', 1, 50, 25, 108, 0, 0, 0, 0, 1391, 5805, 11, 880, 27, 144, 0, 0, 12, 53, 0, 0);
INSERT INTO `ss_meta_players` VALUES(518, 2, 0, 0, 0, 0, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(518, 3, 2, 17, 46, 224, 0, 'St4rKiller', 0, 0, 0, 0, 5, 0, 49, 1235, 273, 795, 19, 320, 57, 456, 0, 0, 2, 63, 38, 76);
INSERT INTO `ss_meta_players` VALUES(518, 4, 0, 42, 46, 423, 1, 'Perfect_Black', 0, 0, 0, 0, 6, 180, 90, 3670, 0, 0, 0, 0, 255, 1752, 0, 0, 28, 483, 36, 247);
INSERT INTO `ss_meta_players` VALUES(518, 5, 2, 48, 42, 694, 1, '[ED]Carlos', 0, 0, 27, 72, 0, 0, 0, 0, 0, 0, 0, 0, 873, 5256, 0, 0, 28, 254, 0, 0);
INSERT INTO `ss_meta_players` VALUES(518, 6, 0, 2, 7, 4, 1, 'IKeepDying', 0, 0, 0, 0, 0, 0, 7, 155, 0, 0, 0, 0, 25, 216, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(518, 7, 0, 0, 0, 0, 4, 'aquka', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(518, 8, 2, 29, 33, 582, 0, '1Cap', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 708, 3768, 0, 0, 10, 249, 16, 57);
INSERT INTO `ss_meta_players` VALUES(518, 9, 0, 18, 15, 185, 1, 'Lon3r', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 452, 2448, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(518, 10, 1, 6, 5, 133, 0, '#M|A#ZOG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 92, 504, 0, 0, 4, 140, 2, 0);
INSERT INTO `ss_meta_players` VALUES(518, 11, 0, 38, 16, 462, 0, 'ElCre#M|A#', 1, 0, 0, 0, 0, 0, 0, 0, 745, 3405, 0, 0, 0, 0, 0, 0, 28, 118, 42, 209);
INSERT INTO `ss_meta_players` VALUES(519, 0, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(519, 1, 1, 3, 4, 100, 0, 'J&amp;A', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(519, 3, 0, 2, 3, 64, 0, 'St4rKiller', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(519, 4, 0, 4, 6, 43, 1, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(519, 5, 0, 6, 3, 48, 1, '[ED]Carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(519, 7, 0, 2, 9, 16, 0, 'aquka', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(519, 9, 0, 10, 4, 174, 1, 'Lon3r', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(519, 10, 0, 8, 5, 189, 0, '#M|A#ZOG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(520, 0, 0, 5, 2, 71, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 58, 432, 0, 0, 1, 102, 14, 114);
INSERT INTO `ss_meta_players` VALUES(520, 1, 1, 3, 9, 106, 0, 'J&amp;A', 0, 0, 4, 54, 0, 0, 0, 0, 0, 0, 4, 160, 0, 0, 0, 0, 8, 93, 0, 0);
INSERT INTO `ss_meta_players` VALUES(520, 3, 0, 2, 3, 64, 0, 'St4rKiller', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(520, 4, 0, 5, 9, 72, 1, 'Perfect_Black', 0, 0, 0, 0, 0, 0, 7, 210, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(520, 5, 1, 9, 3, 172, 1, '[ED]Carlos', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 59, 312, 0, 0, 6, 267, 0, 0);
INSERT INTO `ss_meta_players` VALUES(520, 7, 0, 3, 14, 6, 0, 'aquka', 0, 0, 0, 0, 0, 0, 11, 275, 0, 0, 0, 0, 0, 0, 0, 0, 2, 91, 0, 0);
INSERT INTO `ss_meta_players` VALUES(520, 9, 1, 12, 5, 254, 1, 'Lon3r', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 86, 384, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(520, 10, 0, 11, 8, 268, 0, '#M|A#ZOG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 60, 336, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(521, 0, 0, 8, 3, 112, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 73, 576, 0, 0, 2, 102, 36, 228);
INSERT INTO `ss_meta_players` VALUES(521, 1, 1, 4, 13, 116, 0, 'J&amp;A', 1, 0, 10, 90, 0, 0, 0, 0, 0, 0, 14, 480, 0, 0, 0, 0, 12, 93, 0, 0);
INSERT INTO `ss_meta_players` VALUES(521, 2, 0, 1, 2, 2, 1, '[ED]HGF-ARG', 0, 0, 0, 0, 0, 0, 0, 0, 38, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(521, 3, 0, 2, 0, 22, 1, 'manuelrex', 0, 0, 0, 0, 0, 0, 3, 190, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(521, 4, 0, 7, 6, 81, 0, 'unarmed', 0, 0, 0, 0, 0, 0, 0, 0, 37, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(521, 5, 2, 11, 4, 249, 1, '[ED]Carlos', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 119, 528, 0, 0, 8, 267, 0, 0);
INSERT INTO `ss_meta_players` VALUES(521, 7, 0, 3, 16, 2, 0, 'aquka', 0, 0, 0, 0, 0, 0, 15, 345, 0, 0, 0, 0, 0, 0, 0, 0, 4, 91, 0, 0);
INSERT INTO `ss_meta_players` VALUES(521, 9, 1, 13, 7, 266, 1, 'Lon3r', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 146, 696, 0, 0, 4, 153, 0, 0);
INSERT INTO `ss_meta_players` VALUES(522, 0, 0, 5, 10, 5, 1, 'Leks', 0, 0, 0, 0, 0, 0, 0, 0, 20, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(522, 1, 0, 13, 6, 107, 1, 'divine.markman1', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(522, 2, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(522, 3, 0, 4, 5, 26, 0, 'IKeepDying', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(522, 4, 1, 13, 15, 110, 0, 'STEVEHOLT!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(522, 5, 0, 0, 1, -4, 1, 'Polsky', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(522, 7, 0, 12, 14, 76, 1, 'aquka', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(522, 11, 15, 15, 4, 527, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(523, 0, 0, 0, 0, 0, 4, 'univers-is-mine', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(523, 1, 0, 16, 6, 137, 1, 'divine.markman1', 0, 0, 0, 0, 0, 0, 0, 0, 62, 315, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(523, 2, 0, 2, 1, 16, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 38, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(523, 3, 0, 5, 7, 28, 0, 'IKeepDying', 0, 0, 0, 0, 0, 0, 5, 205, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(523, 4, 1, 13, 17, 102, 0, 'STEVEHOLT!', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(523, 5, 0, 1, 2, 2, 1, 'Polsky', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(523, 7, 0, 13, 15, 84, 1, 'aquka', 0, 0, 0, 0, 0, 0, 3, 200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(523, 11, 16, 15, 4, 579, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 16, 19);
INSERT INTO `ss_meta_players` VALUES(524, 0, 0, 0, 0, 0, 4, 'univers-is-mine', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(524, 1, 0, 16, 6, 137, 1, 'divine.markman1', 0, 0, 0, 0, 0, 0, 0, 0, 62, 315, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(524, 2, 0, 2, 1, 16, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 38, 288, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(524, 3, 0, 5, 7, 28, 0, 'IKeepDying', 0, 0, 0, 0, 0, 0, 5, 205, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(524, 4, 1, 13, 17, 102, 0, 'STEVEHOLT!', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(524, 5, 0, 1, 2, 2, 1, 'Polsky', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 48, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(524, 7, 0, 13, 15, 84, 1, 'aquka', 0, 0, 0, 0, 0, 0, 3, 200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(524, 11, 17, 15, 4, 605, 0, 'FD*elCr@ck!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 16, 19);
INSERT INTO `ss_meta_players` VALUES(525, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(526, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(527, 0, 2, 11, 8, 168, 1, 'LocuraTotal', 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(527, 1, 2, 15, 9, 251, 0, 'quot;sCr3W#K4D4\\\\/#R''&quot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(527, 2, 0, 0, 0, 0, 4, 'Lon3r', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(527, 3, 1, 3, 8, 72, 1, 'TastyNO?', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(527, 4, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(527, 5, 0, 14, 11, 112, 0, 'divine.markman1', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(527, 6, 0, 0, 1, -4, 0, 'ArnoldLayne11', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(528, 0, 2, 13, 8, 188, 1, 'LocuraTotal', 0, 0, 0, 0, 0, 0, 0, 0, 42, 135, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(528, 1, 3, 15, 10, 279, 0, 'quot;sCr3W#K4D4\\\\/#R''&quot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(528, 2, 0, 0, 0, 0, 4, 'Lon3r', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(528, 3, 1, 3, 8, 72, 1, 'TastyNO?', 0, 0, 0, 0, 0, 0, 0, 0, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(528, 4, 0, 1, 1, 6, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 96, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(528, 5, 0, 15, 13, 121, 0, 'divine.markman1', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 80, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(528, 6, 0, 0, 1, -4, 0, 'ArnoldLayne11', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(529, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(530, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(531, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(532, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(533, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(534, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(535, 0, 0, 0, 0, 0, 4, 'LocuraTotal', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(535, 1, 0, 6, 18, -32, 1, 'TastyNO?', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(535, 2, 0, 0, 2, -8, 0, 'yang', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(535, 3, 0, 25, 17, 202, 1, '99%|Felix', 0, 0, 0, 0, 0, 0, 2, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(535, 4, 0, 12, 16, 63, 0, 'UserX', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(535, 5, 0, 3, 1, 18, 1, '|*MDA*|GREMIO', 0, 0, 0, 0, 0, 0, 1, 95, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(535, 6, 0, 0, 1, -4, 0, 'ArnoldLayne11', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(535, 7, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(536, 0, 1, 4, 5, 87, 1, '[ED]Carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(536, 1, 0, 6, 6, 47, 0, 'Divine', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(536, 2, 1, 6, 5, 108, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(536, 3, 0, 4, 4, 45, 0, 'AlLy^divine.[T]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(536, 4, 0, 0, 0, 0, 4, 'Spencer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(536, 5, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 61, 210, 0, 0, 0, 0, 0, 0, 1, 0, 62, 475);
INSERT INTO `ss_meta_players` VALUES(537, 0, 1, 4, 7, 79, 1, '[ED]Carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 72, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(537, 1, 1, 10, 6, 160, 0, 'Divine', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 79, 528, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(537, 2, 1, 7, 7, 155, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 20, 0, 0, 0, 2, 38, 0, 0);
INSERT INTO `ss_meta_players` VALUES(537, 3, 0, 5, 5, 76, 0, 'AlLy^divine.[T]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 37, 120, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(537, 4, 0, 0, 0, 0, 4, 'Spencer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(537, 5, 0, 0, 1, -4, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(538, 0, 1, 7, 12, 137, 1, '[ED]Carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128, 720, 0, 0, 2, 7, 0, 0);
INSERT INTO `ss_meta_players` VALUES(538, 1, 1, 15, 10, 226, 0, 'Divine', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 180, 1056, 0, 0, 14, 111, 0, 0);
INSERT INTO `ss_meta_players` VALUES(538, 2, 3, 10, 10, 271, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 113, 456, 0, 0, 4, 38, 0, 0);
INSERT INTO `ss_meta_players` VALUES(538, 3, 1, 8, 7, 154, 0, 'AlLy^divine.[T]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 115, 432, 0, 0, 14, 300, 0, 0);
INSERT INTO `ss_meta_players` VALUES(538, 4, 0, 0, 0, 0, 4, 'Spencer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(538, 5, 0, 0, 1, -4, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(539, 0, 1, 10, 17, 168, 1, '[ED]Carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 231, 1200, 0, 0, 2, 7, 0, 0);
INSERT INTO `ss_meta_players` VALUES(539, 1, 2, 19, 14, 304, 0, 'Divine', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 304, 1824, 0, 0, 22, 133, 0, 0);
INSERT INTO `ss_meta_players` VALUES(539, 2, 5, 12, 15, 401, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 237, 840, 0, 0, 6, 38, 0, 0);
INSERT INTO `ss_meta_players` VALUES(539, 3, 2, 14, 8, 314, 0, 'AlLy^divine.[T]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 254, 1032, 0, 0, 18, 300, 0, 0);
INSERT INTO `ss_meta_players` VALUES(539, 4, 0, 0, 0, 0, 4, 'Spencer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(539, 5, 0, 0, 1, -4, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(540, 0, 1, 10, 17, 174, 1, '[ED]Carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 250, 1296, 0, 0, 4, 7, 0, 0);
INSERT INTO `ss_meta_players` VALUES(540, 1, 2, 21, 15, 330, 0, 'Divine', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 330, 2064, 0, 0, 24, 133, 0, 0);
INSERT INTO `ss_meta_players` VALUES(540, 2, 5, 13, 18, 440, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 269, 1032, 0, 0, 8, 162, 0, 0);
INSERT INTO `ss_meta_players` VALUES(540, 3, 2, 14, 9, 316, 0, 'AlLy^divine.[T]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 267, 1104, 0, 0, 20, 300, 0, 0);
INSERT INTO `ss_meta_players` VALUES(540, 4, 0, 0, 0, 0, 4, 'Spencer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(540, 5, 0, 0, 1, -4, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(541, 0, 2, 10, 17, 225, 1, '[ED]Carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 250, 1296, 0, 0, 4, 7, 0, 0);
INSERT INTO `ss_meta_players` VALUES(541, 1, 2, 21, 15, 330, 0, 'Divine', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 345, 2160, 0, 0, 24, 133, 0, 0);
INSERT INTO `ss_meta_players` VALUES(541, 2, 5, 13, 18, 440, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 160, 284, 1104, 0, 0, 8, 162, 0, 0);
INSERT INTO `ss_meta_players` VALUES(541, 3, 2, 14, 9, 316, 0, 'AlLy^divine.[T]', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 267, 1104, 0, 0, 22, 300, 0, 0);
INSERT INTO `ss_meta_players` VALUES(541, 4, 0, 0, 0, 0, 4, 'Spencer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(541, 5, 0, 0, 1, -4, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(542, 0, 0, 17, 23, 197, 1, '[ED]Carlos', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 473, 3048, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(542, 2, 1, 18, 21, 256, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 345, 2304, 0, 0, 24, 322, 44, 190);
INSERT INTO `ss_meta_players` VALUES(542, 4, 1, 21, 20, 320, 0, 'Spencer', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 393, 2568, 0, 0, 24, 153, 25, 76);
INSERT INTO `ss_meta_players` VALUES(542, 5, 3, 23, 15, 407, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 384, 3048, 0, 0, 6, 0, 24, 228);
INSERT INTO `ss_meta_players` VALUES(543, 0, 0, 24, 34, 272, 1, '[ED]Carlos', 0, 0, 10, 90, 0, 0, 0, 0, 0, 0, 0, 0, 647, 4032, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(543, 2, 3, 23, 31, 362, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 506, 3096, 0, 0, 36, 558, 44, 190);
INSERT INTO `ss_meta_players` VALUES(543, 4, 3, 31, 26, 536, 0, 'Spencer', 0, 0, 0, 0, 0, 0, 23, 1230, 0, 0, 1, 0, 410, 2640, 0, 0, 30, 153, 46, 133);
INSERT INTO `ss_meta_players` VALUES(543, 5, 5, 34, 21, 599, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 599, 4728, 0, 0, 6, 0, 39, 342);
INSERT INTO `ss_meta_players` VALUES(544, 0, 0, 28, 42, 301, 1, '[ED]Carlos', 1, 0, 12, 126, 0, 0, 0, 0, 0, 0, 0, 0, 808, 4776, 0, 0, 10, 39, 0, 0);
INSERT INTO `ss_meta_players` VALUES(544, 2, 4, 29, 36, 461, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 630, 3744, 0, 0, 42, 634, 83, 285);
INSERT INTO `ss_meta_players` VALUES(544, 4, 4, 33, 30, 592, 0, 'Spencer', 0, 0, 0, 0, 0, 0, 25, 1370, 101, 315, 1, 0, 410, 2640, 0, 0, 40, 218, 46, 133);
INSERT INTO `ss_meta_players` VALUES(544, 5, 6, 45, 27, 773, 0, 'HyPE|GDM', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 0, 0, 790, 6120, 0, 0, 6, 0, 39, 342);
INSERT INTO `ss_meta_players` VALUES(545, 0, 0, 29, 47, 293, 1, '[ED]Carlos', 1, 0, 12, 126, 0, 0, 0, 0, 0, 0, 0, 0, 848, 5064, 0, 0, 14, 39, 0, 0);
INSERT INTO `ss_meta_players` VALUES(545, 2, 4, 31, 39, 476, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 669, 3960, 0, 0, 42, 634, 88, 380);
INSERT INTO `ss_meta_players` VALUES(545, 4, 4, 33, 31, 592, 0, 'Spencer', 0, 0, 0, 0, 0, 0, 25, 1370, 173, 570, 1, 0, 410, 2640, 0, 0, 44, 218, 46, 133);
INSERT INTO `ss_meta_players` VALUES(545, 5, 6, 53, 29, 861, 0, 'HyPE|GDM', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 0, 0, 873, 6840, 0, 0, 7, 0, 39, 342);
INSERT INTO `ss_meta_players` VALUES(546, 0, 0, 29, 47, 293, 1, '[ED]Carlos', 1, 0, 12, 126, 0, 0, 0, 0, 0, 0, 0, 0, 852, 5064, 0, 0, 14, 39, 0, 0);
INSERT INTO `ss_meta_players` VALUES(546, 2, 4, 31, 40, 472, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 676, 4080, 0, 0, 42, 634, 88, 380);
INSERT INTO `ss_meta_players` VALUES(546, 4, 5, 34, 31, 644, 0, 'Spencer', 0, 0, 0, 0, 0, 0, 25, 1370, 189, 705, 1, 0, 410, 2640, 0, 0, 44, 218, 46, 133);
INSERT INTO `ss_meta_players` VALUES(546, 5, 6, 53, 29, 861, 0, 'HyPE|GDM', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 0, 0, 874, 6840, 0, 0, 7, 0, 39, 342);
INSERT INTO `ss_meta_players` VALUES(547, 0, 0, 29, 47, 293, 1, '[ED]Carlos', 1, 0, 12, 126, 0, 0, 0, 0, 0, 0, 0, 0, 852, 5064, 0, 0, 14, 39, 0, 0);
INSERT INTO `ss_meta_players` VALUES(547, 2, 4, 31, 40, 472, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 676, 4080, 0, 0, 42, 634, 88, 380);
INSERT INTO `ss_meta_players` VALUES(547, 4, 5, 34, 31, 644, 0, 'Spencer', 0, 0, 0, 0, 0, 0, 25, 1370, 189, 705, 1, 0, 410, 2640, 0, 0, 44, 218, 46, 133);
INSERT INTO `ss_meta_players` VALUES(547, 5, 6, 53, 29, 861, 0, 'HyPE|GDM', 0, 0, 5, 36, 0, 0, 0, 0, 0, 0, 0, 0, 874, 6840, 0, 0, 7, 0, 39, 342);
INSERT INTO `ss_meta_players` VALUES(548, 0, 3, 34, 44, 448, 1, '[ED]Carlos', 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 920, 4896, 0, 0, 38, 306, 0, 0);
INSERT INTO `ss_meta_players` VALUES(548, 2, 3, 34, 39, 470, 1, '[ED]SEXOLOCO', 0, 0, 0, 0, 0, 0, 0, 0, 14, 45, 0, 0, 743, 5184, 0, 0, 30, 310, 25, 190);
INSERT INTO `ss_meta_players` VALUES(548, 4, 7, 41, 28, 771, 0, 'Spencer', 0, 0, 2, 0, 0, 0, 4, 235, 62, 240, 2, 80, 642, 4272, 0, 0, 10, 187, 0, 0);
INSERT INTO `ss_meta_players` VALUES(548, 5, 1, 41, 41, 470, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 512, 2130, 0, 0, 456, 2952, 0, 0, 18, 472, 99, 551);
INSERT INTO `ss_meta_players` VALUES(549, 0, 0, 0, 0, 0, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 0, 5, 26, 25, 585, 1, 'r0n', 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 1, 2, 5, 6, 135, 0, 'MG', 0, 0, 0, 0, 0, 0, 9, 370, 0, 0, 0, 0, 0, 0, 0, 0, 2, 135, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 2, 7, 12, 13, 303, 1, 'Darass', 0, 0, 8, 72, 0, 0, 6, 220, 0, 0, 4, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 3, 1, 21, 21, 324, 1, 'colesucksdick', 0, 0, 0, 0, 0, 0, 0, 0, 40, 300, 0, 0, 0, 0, 0, 0, 6, 224, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 4, 3, 10, 25, 122, 1, 'LuizShot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 264, 0, 0, 2, 123, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 5, 10, 39, 24, 958, 1, '[GRF]VectorM12', 0, 0, 3, 36, 0, 0, 0, 0, 0, 0, 0, 0, 60, 528, 0, 0, 2, 113, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 6, 3, 12, 30, 32, 0, 'cthrusand', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 67, 264, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 7, 3, 8, 1, 226, 0, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 121, 465, 0, 0, 0, 0, 0, 0, 3, 116, 60, 342);
INSERT INTO `ss_meta_players` VALUES(550, 8, 0, 0, 5, -20, 1, 'rhaldder', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 9, 1, 9, 12, 212, 1, 'diego1620', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 480, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 10, 6, 32, 17, 566, 0, 'GoRiNicH', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 86, 696, 0, 0, 3, 264, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 11, 0, 2, 3, -25, 0, 'seiunpippone', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 960, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 12, 2, 24, 26, 601, 1, 'Gwada', 0, 0, 0, 0, 0, 0, 7, 370, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 13, 0, 13, 7, 48, 0, 'unarmed', 1, 50, 0, 0, 0, 0, 0, 0, 32, 105, 6, 80, 0, 0, 0, 0, 2, 77, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 14, 4, 19, 31, 324, 0, 'T-MAN', 0, 0, 0, 0, 0, 0, 8, 375, 0, 0, 0, 0, 0, 0, 0, 0, 2, 77, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 15, 0, 3, 4, 59, 1, 'Lt_Mc_neil', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 16, 5, 28, 21, 551, 0, 'zxcv', 0, 0, 0, 0, 0, 0, 0, 0, 76, 345, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 17, 0, 0, 0, 0, 4, 'Mikelegeuh', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(550, 19, 1, 6, 23, 70, 0, 'zSebaGuaPro', 0, 0, 0, 0, 7, 0, 0, 0, 20, 135, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 0, 0, 7, 10, 20, 0, 'iddqd', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 1120, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 1, 0, 9, 15, 41, 1, 'MG', 0, 0, 0, 0, 0, 0, 14, 565, 0, 0, 0, 0, 77, 576, 0, 0, 6, 54, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 2, 0, 7, 6, 36, 1, 'FIZZLE187', 0, 0, 0, 0, 0, 0, 0, 0, 13, 75, 0, 0, 136, 1152, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 3, 0, 1, 2, 7, 1, 'unarmed', 0, 0, 0, 0, 0, 0, 3, 100, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 4, 0, -2, 8, -62, 1, 'LuizShot', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 77, 288, 0, 0, 21, 273, 16, 19);
INSERT INTO `ss_meta_players` VALUES(551, 5, 0, 18, 9, 149, 1, '[GRF]VectorM12', 0, 0, 18, 72, 0, 0, 0, 0, 0, 0, 0, 0, 175, 1608, 0, 0, 28, 658, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 6, 0, 8, 15, 40, 0, 'cthrusand', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 230, 1368, 0, 0, 6, 69, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 7, 0, 19, 4, 169, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 45, 225, 0, 0, 204, 1584, 0, 0, 7, 66, 9, 57);
INSERT INTO `ss_meta_players` VALUES(551, 8, 0, 3, 7, 4, 1, 'DURODEMATAR', 0, 0, 0, 0, 0, 0, 6, 470, 0, 0, 0, 0, 68, 408, 0, 0, 6, 130, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 9, 0, 2, 11, -24, 0, 'colesucksdick', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 10, 0, 15, 6, 131, 0, 'GoRiNicH', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 241, 1800, 0, 0, 18, 242, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 11, 0, 12, 13, 73, 0, 'seiunpippone', 0, 0, 0, 0, 0, 0, 0, 0, 319, 1485, 1, 0, 0, 0, 0, 0, 6, 0, 30, 209);
INSERT INTO `ss_meta_players` VALUES(551, 12, 0, 2, 1, 16, 0, 'SlayerNL', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19, 96, 0, 0, 2, 194, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 13, 0, 5, 10, 5, 0, 'unarmed', 0, 0, 11, 36, 0, 0, 0, 0, 14, 75, 12, 720, 0, 0, 0, 0, 6, 27, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 14, 0, 0, 0, 0, 1, 'JoseF', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 24, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 15, 0, 0, 0, 0, 0, 'Collinlicksbutt', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(551, 19, 0, 2, 8, -17, 0, 'zSebaGuaPro', 0, 0, 0, 0, 7, 60, 0, 0, 62, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 0, 0, 0, 0, 0, 4, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 1, 0, 7, 9, 26, 0, 'Roberto', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 2, 0, 8, 5, 57, 0, 'borec', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 3, 0, 27, 17, 192, 1, 'R2D2-BR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 4, 0, 28, 8, 254, 1, 'emilius', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 5, 0, 20, 27, 86, 0, 'NATOCRIMINAL', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 6, 0, 2, 4, 4, 1, 'SilverBullet', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 7, 0, 7, 9, 29, 1, 'N3YMAR!!!!!!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 8, 0, 21, 23, 117, 0, '{PT}MirekWo(PL)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 9, 0, 9, 10, 52, 0, 'Shart', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 10, 0, 14, 27, 28, 0, 'hatti', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 11, 0, 14, 27, 29, 0, 'Zeslehany', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 13, 0, 0, 0, 0, 1, 'vitor', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 14, 0, 35, 19, 254, 1, 'Skahdah', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 15, 0, 22, 26, 104, 0, 'Kvetinar', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 17, 0, 14, 16, 76, 1, 'nix', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 18, 0, 41, 17, 332, 1, 'Shooter', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(552, 19, 0, 3, 2, 22, 0, '.....', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 0, 0, 1, 1, 6, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 1, 0, 7, 11, 18, 0, 'Roberto', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 2, 0, 10, 7, 70, 0, 'borec', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 3, 0, 31, 18, 228, 1, 'R2D2-BR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 4, 0, 28, 9, 250, 1, 'emilius', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 5, 0, 21, 28, 92, 0, 'NATOCRIMINAL', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 6, 0, 2, 6, -4, 1, 'SilverBullet', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 7, 0, 9, 10, 45, 1, 'N3YMAR!!!!!!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 8, 0, 23, 25, 129, 0, '{PT}MirekWo(PL)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 9, 0, 10, 10, 62, 0, 'Shart', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 10, 0, 15, 29, 30, 0, 'hatti', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 11, 0, 14, 29, 21, 0, 'Zeslehany', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 13, 0, 2, 1, 16, 1, 'vitor', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 14, 0, 36, 21, 256, 1, 'Skahdah', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 15, 0, 25, 27, 132, 0, 'Kvetinar', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 17, 0, 14, 17, 72, 1, 'nix', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 18, 0, 43, 18, 348, 1, 'Shooter', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(553, 19, 0, 4, 2, 33, 0, '.....', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 0, 0, 6, 3, 48, 1, 'HyPE|GDM', 2, 50, 0, 0, 0, 0, 0, 0, 0, 0, 12, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 1, 0, 10, 14, 36, 0, 'Roberto', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 3, 0, 36, 19, 274, 1, 'R2D2-BR', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 720, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 4, 0, 30, 11, 262, 1, 'emilius', 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 5, 0, 25, 31, 122, 0, 'NATOCRIMINAL', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 6, 0, 3, 7, 2, 1, 'SilverBullet', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 7, 0, 9, 12, 37, 0, 'N3YMAR!!!!!!', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 160, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 8, 0, 25, 28, 139, 0, '{PT}MirekWo(PL)', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 320, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 9, 0, 14, 13, 91, 0, 'Shart', 8, 100, 0, 0, 0, 0, 0, 0, 0, 0, 8, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 10, 0, 15, 32, 18, 0, 'hatti', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 14, 0, 39, 23, 278, 1, 'Skahdah', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 400, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 17, 0, 15, 19, 74, 1, 'nix', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 80, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 18, 0, 49, 20, 400, 1, 'Shooter', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 640, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(554, 19, 0, 8, 5, 62, 0, '.....', 3, 50, 0, 0, 0, 0, 0, 0, 0, 0, 8, 240, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(555, 0, 0, 0, 0, 0, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(556, 0, 0, 14, 23, 109, 0, '1Bullet', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 279, 1368, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(556, 1, 0, 5, 5, 62, 0, 'unarmed.', 3, 0, 15, 0, 0, 0, 0, 0, 92, 390, 3, 80, 14, 96, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(556, 2, 0, 1, 1, 6, 0, 'Limansk', 0, 0, 0, 0, 0, 0, 0, 0, 36, 90, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(556, 3, 0, 22, 15, 353, 0, 'Liz-Taylor', 0, 0, 0, 0, 0, 0, 0, 0, 486, 2250, 0, 0, 0, 0, 0, 0, 6, 92, 11, 76);
INSERT INTO `ss_meta_players` VALUES(556, 4, 2, 25, 10, 471, 1, 'HyPE|GDM', 0, 0, 7, 36, 0, 0, 0, 0, 113, 525, 0, 0, 308, 2328, 0, 0, 7, 0, 48, 247);
INSERT INTO `ss_meta_players` VALUES(556, 5, 0, 3, 6, 18, 1, 'halim', 0, 0, 0, 0, 20, 300, 0, 0, 99, 285, 7, 240, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(556, 6, 0, 26, 30, 340, 1, 'DiDa~ism', 0, 0, 0, 0, 0, 0, 54, 1750, 0, 0, 0, 0, 0, 0, 0, 0, 2, 127, 0, 0);
INSERT INTO `ss_meta_players` VALUES(556, 7, 1, 8, 13, 229, 1, 'T.R.A.S.H.', 17, 0, 39, 162, 0, 0, 44, 1165, 0, 0, 0, 0, 0, 0, 0, 0, 28, 684, 0, 0);
INSERT INTO `ss_meta_players` VALUES(556, 8, 1, 12, 27, 282, 0, 'r0n', 0, 0, 11, 54, 0, 0, 38, 840, 0, 0, 0, 0, 0, 0, 0, 0, 18, 89, 12, 95);
INSERT INTO `ss_meta_players` VALUES(556, 9, 0, 2, 3, 45, 0, 'sfdpqk', 0, 0, 0, 0, 0, 0, 0, 0, 87, 240, 0, 0, 0, 0, 0, 0, 2, 123, 0, 0);
INSERT INTO `ss_meta_players` VALUES(556, 10, 0, 13, 5, 235, 1, 'Gwada', 0, 0, 0, 0, 0, 0, 36, 1515, 0, 0, 0, 0, 0, 0, 0, 0, 10, 143, 0, 0);
INSERT INTO `ss_meta_players` VALUES(556, 12, 0, -1, 4, -36, 1, 'unarmed', 0, 0, 11, 36, 0, 0, 0, 0, 0, 0, 0, 0, 59, 264, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(557, 0, 0, 14, 23, 109, 0, '1Bullet', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 315, 1416, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(557, 1, 0, 9, 6, 105, 0, 'unarmed.', 4, 0, 15, 0, 0, 0, 0, 0, 92, 390, 3, 80, 48, 480, 0, 0, 6, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(557, 2, 0, 2, 2, 36, 0, 'Limansk', 0, 0, 0, 0, 0, 0, 0, 0, 47, 105, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(557, 3, 0, 23, 16, 380, 0, 'Liz-Taylor', 0, 0, 0, 0, 0, 0, 0, 0, 524, 2415, 0, 0, 0, 0, 0, 0, 6, 92, 11, 76);
INSERT INTO `ss_meta_players` VALUES(557, 4, 2, 29, 11, 565, 1, 'HyPE|GDM', 0, 0, 12, 90, 0, 0, 0, 0, 113, 525, 0, 0, 372, 2832, 0, 0, 7, 0, 48, 247);
INSERT INTO `ss_meta_players` VALUES(557, 5, 0, 4, 8, 20, 1, 'halim', 0, 0, 0, 0, 20, 300, 0, 0, 130, 315, 7, 240, 0, 0, 0, 0, 2, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(557, 6, 0, 26, 31, 336, 1, 'DiDa~ism', 0, 0, 0, 0, 0, 0, 56, 1750, 0, 0, 0, 0, 0, 0, 0, 0, 2, 127, 0, 0);
INSERT INTO `ss_meta_players` VALUES(557, 7, 2, 8, 13, 319, 1, 'T.R.A.S.H.', 19, 0, 39, 162, 0, 0, 45, 1185, 0, 0, 0, 0, 0, 0, 0, 0, 30, 684, 0, 0);
INSERT INTO `ss_meta_players` VALUES(557, 8, 1, 12, 28, 278, 0, 'r0n', 0, 0, 15, 54, 0, 0, 41, 860, 0, 0, 0, 0, 0, 0, 0, 0, 20, 89, 12, 95);
INSERT INTO `ss_meta_players` VALUES(557, 9, 0, 2, 4, 41, 0, 'sfdpqk', 0, 0, 5, 18, 0, 0, 0, 0, 87, 240, 2, 80, 0, 0, 0, 0, 2, 123, 0, 0);
INSERT INTO `ss_meta_players` VALUES(557, 12, 0, -1, 5, -40, 1, 'unarmed', 0, 0, 11, 36, 0, 0, 0, 0, 0, 0, 0, 0, 73, 408, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(558, 0, 0, 2, 7, -8, 0, '1Bullet', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 75, 456, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(558, 2, 0, 2, 8, -12, 0, 'Limansk', 0, 0, 0, 0, 0, 0, 0, 0, 126, 270, 0, 0, 27, 168, 0, 0, 4, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(558, 3, 0, 10, 2, 92, 0, 'Liz-Taylor', 0, 0, 0, 0, 0, 0, 0, 0, 150, 750, 0, 0, 0, 0, 0, 0, 2, 0, 59, 342);
INSERT INTO `ss_meta_players` VALUES(558, 4, 0, 12, 2, 122, 1, 'HyPE|GDM', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 97, 816, 0, 0, 8, 742, 42, 209);
INSERT INTO `ss_meta_players` VALUES(558, 6, 0, 6, 6, 40, 1, 'DiDa~ism', 0, 0, 0, 0, 0, 0, 21, 800, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(558, 9, 0, 0, 1, -4, 0, 'sfdpqk', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `ss_meta_players` VALUES(558, 12, 0, 2, 4, 4, 1, 'mischief', 0, 0, 3, 36, 0, 0, 4, 130, 0, 0, 9, 320, 13, 72, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ss_meta_server`
--

DROP TABLE IF EXISTS `ss_meta_server`;
CREATE TABLE IF NOT EXISTS `ss_meta_server` (
  `ss_id` int(16) NOT NULL,
  `ip` varchar(64) collate utf8_bin NOT NULL,
  `port` varchar(5) collate utf8_bin NOT NULL,
  `hostname` varchar(253) collate utf8_bin NOT NULL,
  `map` varchar(128) collate utf8_bin NOT NULL,
  `mode_id` int(4) NOT NULL,
  `mastermode_id` int(4) NOT NULL,
  `minutes_remaining` int(4) NOT NULL,
  PRIMARY KEY  (`ss_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `ss_meta_server`
--

INSERT INTO `ss_meta_server` VALUES(185, '88.191.126.218', '6600', 'sd-22753.dedibox.fr', 'ac_arid', 0, 0, 5);
INSERT INTO `ss_meta_server` VALUES(186, '88.191.129.31', '28763', 'procrastin.at', 'ac_desert3', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(187, '62.75.210.97', '28763', 'ej3416.de', 'ac_complex', 2, 0, 3);
INSERT INTO `ss_meta_server` VALUES(188, '62.75.210.97', '28763', 'ej3416.de', 'ac_complex', 2, 0, 3);
INSERT INTO `ss_meta_server` VALUES(189, '', '', '', 'ac_outpost', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(190, '', '', '', 'ac_aqueous', 7, 0, 15);
INSERT INTO `ss_meta_server` VALUES(191, '', '', '', 'ac_aqueous', 7, 0, 15);
INSERT INTO `ss_meta_server` VALUES(192, '', '', '', 'ac_aqueous', 7, 0, 15);
INSERT INTO `ss_meta_server` VALUES(193, '78.46.116.16', '20030', 'de.mysick.tk', 'ac_desert3', 5, 0, 2);
INSERT INTO `ss_meta_server` VALUES(194, '78.46.116.16', '20030', 'de.mysick.tk', 'ac_desert3', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(195, '78.46.116.16', '20030', 'de.mysick.tk', 'ac_desert3', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(196, '78.46.116.16', '20030', 'de.mysick.tk', 'ac_desert3', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(197, '103.6.213.144', '22222', '103.6.213.144', 'ac_douze', 15, 0, 0);
INSERT INTO `ss_meta_server` VALUES(198, '103.6.213.144', '22222', '103.6.213.144', 'ac_elevation', 15, 0, 10);
INSERT INTO `ss_meta_server` VALUES(199, '66.148.72.137', '28763', 'fpe0501.vth0.net', 'ac_power', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(200, '64.120.169.181', '28763', 'xt69.clicnet.info', 'ac_desert3', 5, 0, 2);
INSERT INTO `ss_meta_server` VALUES(201, '64.120.169.181', '28763', 'xt69.clicnet.info', 'ac_desert3', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(202, '64.120.169.181', '28763', 'xt69.clicnet.info', 'ac_desert3', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(203, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_douze', 5, 0, 10);
INSERT INTO `ss_meta_server` VALUES(204, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_douze', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(205, '96.8.120.142', '26283', '142.120.8.96.host.nwnx.net', 'ac_snow', 10, 0, 0);
INSERT INTO `ss_meta_server` VALUES(206, '46.29.248.33', '28763', '46.29.248.33', 'ac_lainio', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(207, '96.8.120.142', '26283', '142.120.8.96.host.nwnx.net', 'ac_ingress', 13, 0, 0);
INSERT INTO `ss_meta_server` VALUES(208, '96.8.120.142', '26283', '142.120.8.96.host.nwnx.net', 'ac_desert3', 13, 0, 0);
INSERT INTO `ss_meta_server` VALUES(209, '96.8.120.142', '26283', '142.120.8.96.host.nwnx.net', 'ac_desert3', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(210, '96.8.120.142', '26283', '142.120.8.96.host.nwnx.net', 'ac_arabian', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(211, '96.8.120.142', '26283', '142.120.8.96.host.nwnx.net', 'ac_komplex', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(212, '96.8.120.142', '26283', '142.120.8.96.host.nwnx.net', 'ac_shortway', 4, 0, 0);
INSERT INTO `ss_meta_server` VALUES(213, '96.8.120.142', '26283', '142.120.8.96.host.nwnx.net', 'ac_shine', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(214, '96.8.120.142', '26283', '142.120.8.96.host.nwnx.net', 'apollo_castle', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(215, '198.144.189.55', '4444', 'host.colocrossing.com', 'ac_mines', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(216, '198.144.189.55', '4444', 'host.colocrossing.com', 'ac_shine', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(217, '198.144.189.55', '4444', 'host.colocrossing.com', 'ac_ingress', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(218, '199.167.199.233', '7999', '199.167.199.233', 'ac_desert', 0, 0, 4);
INSERT INTO `ss_meta_server` VALUES(219, '199.167.199.233', '7999', '199.167.199.233', 'ac_desert', 0, 2, 0);
INSERT INTO `ss_meta_server` VALUES(220, '178.82.217.175', '22222', '178-82-217-175.dynamic.hispeed.ch', 'ac_ingress', 5, 2, 4);
INSERT INTO `ss_meta_server` VALUES(221, '178.82.217.175', '22222', '178-82-217-175.dynamic.hispeed.ch', 'ac_ingress', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(222, '178.82.217.175', '22222', '178-82-217-175.dynamic.hispeed.ch', 'ac_depot', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(223, '108.166.174.214', '28763', 'cust-108-166-174-214.corexchange.com', 'ac_desert3', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(224, '70.42.74.212', '28775', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_douze', 10, 0, 0);
INSERT INTO `ss_meta_server` VALUES(225, '96.8.120.142', '26283', '142.120.8.96.host.nwnx.net', 'ac_depot', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(226, '96.8.120.142', '26283', '142.120.8.96.host.nwnx.net', 'ac_ingress', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(227, '198.144.189.55', '5555', 'host.colocrossing.com', 'ac_power', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(228, '69.85.88.168', '28751', '69.85.88.168', 'ac_shine', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(229, '69.85.88.168', '28751', '69.85.88.168', 'ac_shine', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(230, '64.85.165.123', '28763', '64.85.165.123', 'ac_desert', 11, 0, 2);
INSERT INTO `ss_meta_server` VALUES(231, '64.85.165.123', '28763', '64.85.165.123', 'ac_desert', 11, 0, 0);
INSERT INTO `ss_meta_server` VALUES(232, '', '', '', 'ac_elevation', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(233, '', '', '', 'ac_shine', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(234, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_zanka', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(235, '', '', '', 'ac_gothic', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(236, '', '', '', 'ac_desert2', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(237, '', '', '', 'ac_shine', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(238, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_nuuk', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(239, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_nuuk', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(240, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_nuuk', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(241, '', '', '', 'ac_mines', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(242, '64.85.165.123', '28765', '64.85.165.123', 'ac_desert3', 13, 0, 12);
INSERT INTO `ss_meta_server` VALUES(243, '64.85.165.123', '28765', '64.85.165.123', 'ac_desert3', 13, 0, 11);
INSERT INTO `ss_meta_server` VALUES(244, '64.85.165.123', '28765', '64.85.165.123', 'ac_desert3', 13, 0, 8);
INSERT INTO `ss_meta_server` VALUES(245, '64.85.165.123', '28765', '64.85.165.123', 'ac_desert3', 13, 0, 7);
INSERT INTO `ss_meta_server` VALUES(246, '64.85.165.123', '28765', '64.85.165.123', 'ac_desert3', 13, 0, 7);
INSERT INTO `ss_meta_server` VALUES(247, '64.85.165.123', '28765', '64.85.165.123', 'ac_desert3', 13, 0, 5);
INSERT INTO `ss_meta_server` VALUES(248, '64.85.165.123', '28765', '64.85.165.123', 'ac_desert3', 13, 0, 4);
INSERT INTO `ss_meta_server` VALUES(249, '64.85.165.123', '28765', '64.85.165.123', 'ac_desert3', 13, 0, 4);
INSERT INTO `ss_meta_server` VALUES(250, '78.46.50.34', '28767', 'itavd.org', 'ac_sunset', 5, 0, 10);
INSERT INTO `ss_meta_server` VALUES(251, '78.46.50.34', '28767', 'itavd.org', 'ac_sunset', 5, 0, 10);
INSERT INTO `ss_meta_server` VALUES(252, '78.46.50.34', '28767', 'itavd.org', 'ac_sunset', 5, 0, 9);
INSERT INTO `ss_meta_server` VALUES(253, '78.46.50.34', '28767', 'itavd.org', 'ac_sunset', 5, 0, 9);
INSERT INTO `ss_meta_server` VALUES(254, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(255, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(256, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(257, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 3);
INSERT INTO `ss_meta_server` VALUES(258, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(259, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(260, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 14);
INSERT INTO `ss_meta_server` VALUES(261, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 14);
INSERT INTO `ss_meta_server` VALUES(262, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 14);
INSERT INTO `ss_meta_server` VALUES(263, '', '', '', 'ac_desert2', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(264, '', '', '', 'ac_elevation', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(265, '176.31.6.212', '28765', '176.31.6.212', 'ac_power', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(266, '176.31.6.212', '28765', '176.31.6.212', 'ac_power', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(267, '184.82.187.56', '18620', '184-82-187-56.static.hostnoc.net', 'ac_desert3', 5, 0, 13);
INSERT INTO `ss_meta_server` VALUES(268, '184.82.187.56', '18620', '184-82-187-56.static.hostnoc.net', 'ac_desert3', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(269, '184.82.187.56', '18620', '184-82-187-56.static.hostnoc.net', 'ac_desert3', 5, 0, 9);
INSERT INTO `ss_meta_server` VALUES(270, '184.82.187.56', '18620', '184-82-187-56.static.hostnoc.net', 'ac_desert3', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(271, '184.82.187.56', '18620', '184-82-187-56.static.hostnoc.net', 'ac_desert3', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(272, '184.82.187.56', '18620', '184-82-187-56.static.hostnoc.net', 'ac_desert3', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(273, '86.6.119.110', '28794', 'cpc3-cosh9-0-0-cust877.6-1.cable.virginmedia.com', 'ac_desert3', 5, 0, 7);
INSERT INTO `ss_meta_server` VALUES(274, '195.3.138.250', '9999', '195.3.138.250', 'ac_douze', 0, 2, 0);
INSERT INTO `ss_meta_server` VALUES(275, '195.3.138.250', '9999', '195.3.138.250', 'ac_douze', 0, 2, 0);
INSERT INTO `ss_meta_server` VALUES(276, '195.3.138.250', '9999', '195.3.138.250', 'ac_arid', 5, 2, 14);
INSERT INTO `ss_meta_server` VALUES(277, '195.3.138.250', '9999', '195.3.138.250', 'ac_arid', 5, 2, 13);
INSERT INTO `ss_meta_server` VALUES(278, '195.3.138.250', '9999', '195.3.138.250', 'ac_arid', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(279, '195.3.138.250', '9999', '195.3.138.250', 'ac_gothic', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(280, '195.3.138.250', '9999', '195.3.138.250', 'ac_gothic', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(281, '195.3.138.250', '9999', '195.3.138.250', 'ac_desert3', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(282, '', '', '', 'ac_outpost', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(283, '', '', '', 'ac_desert', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(284, '62.75.235.225', '3892', 'xray429.server4you.de', 'ac_desert', 11, 0, 12);
INSERT INTO `ss_meta_server` VALUES(285, '62.75.235.225', '3892', 'xray429.server4you.de', 'ac_desert', 11, 0, 12);
INSERT INTO `ss_meta_server` VALUES(286, '62.75.235.225', '3892', 'xray429.server4you.de', 'ac_desert', 11, 0, 11);
INSERT INTO `ss_meta_server` VALUES(287, '62.75.235.225', '3892', 'xray429.server4you.de', 'ac_desert', 11, 0, 11);
INSERT INTO `ss_meta_server` VALUES(288, '', '', '', 'ac_elevation', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(289, '', '', '', 'ac_depot', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(290, '64.85.165.123', '28765', '64.85.165.123', 'ac_mines', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(291, '', '', '', 'ac_desert3', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(292, '', '', '', 'ac_arid', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(293, '', '', '', 'ac_power', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(294, '', '', '', 'ac_mines', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(295, '', '', '', 'ac_desert', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(296, '', '', '', 'ac_mines', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(297, '', '', '', 'ac_complex', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(298, '', '', '', 'ac_keller', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(299, '', '', '', 'ac_scaffold', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(300, '', '', '', 'ac_werk', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(301, '', '', '', 'ac_outpost', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(302, '', '', '', 'ac_keller', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(303, '', '', '', 'ac_shine', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(304, '', '', '', 'ac_shine', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(305, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(306, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 3);
INSERT INTO `ss_meta_server` VALUES(307, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 3);
INSERT INTO `ss_meta_server` VALUES(308, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 2);
INSERT INTO `ss_meta_server` VALUES(309, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(310, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(311, '64.85.165.123', '28765', '64.85.165.123', 'ac_shine', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(312, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 14);
INSERT INTO `ss_meta_server` VALUES(313, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 14);
INSERT INTO `ss_meta_server` VALUES(314, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 14);
INSERT INTO `ss_meta_server` VALUES(315, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 14);
INSERT INTO `ss_meta_server` VALUES(316, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 14);
INSERT INTO `ss_meta_server` VALUES(317, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 13);
INSERT INTO `ss_meta_server` VALUES(318, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 13);
INSERT INTO `ss_meta_server` VALUES(319, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(320, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(321, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(322, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(323, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(324, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(325, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(326, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(327, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(328, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(329, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(330, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(331, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(332, '64.85.165.123', '28765', '64.85.165.123', 'ac_sunset', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(333, '', '', '', 'ac_ingress', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(334, '', '', '', 'ac_depot', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(335, '', '', '', 'ac_shine', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(336, '', '', '', 'ac_arabian', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(337, '', '', '', 'ac_arabian', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(338, '', '', '', 'ac_arabian', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(339, '', '', '', 'ac_arabian', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(340, '62.75.235.225', '3841', 'xray429.server4you.de', 'ac_depot', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(341, '62.75.235.225', '3841', 'xray429.server4you.de', 'ac_depot', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(342, '62.75.235.225', '3841', 'xray429.server4you.de', 'ac_depot', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(343, '62.75.235.225', '3841', 'xray429.server4you.de', 'ac_depot', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(344, '64.85.165.123', '28765', '64.85.165.123', 'ac_depot', 5, 0, 10);
INSERT INTO `ss_meta_server` VALUES(345, '64.85.165.123', '28765', '64.85.165.123', 'ac_depot', 5, 0, 9);
INSERT INTO `ss_meta_server` VALUES(346, '176.31.6.212', '28765', '176.31.6.212', 'ac_sunset', 5, 0, 7);
INSERT INTO `ss_meta_server` VALUES(347, '62.75.235.225', '3892', 'xray429.server4you.de', 'ac_shine', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(348, '71.233.186.148', '65030', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_desert3', 5, 0, 3);
INSERT INTO `ss_meta_server` VALUES(349, '71.233.186.148', '65030', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_desert3', 5, 0, 2);
INSERT INTO `ss_meta_server` VALUES(350, '62.75.235.225', '3892', 'xray429.server4you.de', 'ac_arabian', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(351, '62.75.235.225', '3892', 'xray429.server4you.de', 'ac_arabian', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(352, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_desert3', 5, 0, 14);
INSERT INTO `ss_meta_server` VALUES(353, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_desert3', 5, 0, 13);
INSERT INTO `ss_meta_server` VALUES(354, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_desert3', 5, 0, 13);
INSERT INTO `ss_meta_server` VALUES(355, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_desert3', 5, 0, 13);
INSERT INTO `ss_meta_server` VALUES(356, '', '', '', 'ac_toxic', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(357, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_desert3', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(358, '', '', '', 'ac_douze', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(359, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_village2', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(360, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_douze', 11, 0, 14);
INSERT INTO `ss_meta_server` VALUES(361, '213.81.159.226', '28763', 'bip-static-226.213-81-159.telecom.sk', 'ac_desert3', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(362, '213.81.159.226', '28763', 'bip-static-226.213-81-159.telecom.sk', 'ac_desert3', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(363, '213.81.159.226', '28763', 'bip-static-226.213-81-159.telecom.sk', 'ac_desert3', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(364, '213.81.159.226', '28763', 'bip-static-226.213-81-159.telecom.sk', 'ac_power', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(365, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_shine', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(366, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_shine', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(367, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_shine', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(368, '69.28.54.27', '28763', 'chinacache.la.xtom.com', 'ac_power', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(369, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_werk', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(370, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_werk', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(371, '', '', '', 'ac_desert', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(372, '', '', '', 'ac_desert', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(373, '69.28.54.27', '28763', 'chinacache.la.xtom.com', 'ac_power', 5, 0, 9);
INSERT INTO `ss_meta_server` VALUES(374, '69.28.54.27', '28763', 'chinacache.la.xtom.com', 'ac_power', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(375, '69.28.54.27', '28763', 'chinacache.la.xtom.com', 'ac_power', 5, 0, 7);
INSERT INTO `ss_meta_server` VALUES(376, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_mines', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(377, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_mines', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(378, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_mines', 5, 0, 2);
INSERT INTO `ss_meta_server` VALUES(379, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_mines', 5, 0, 2);
INSERT INTO `ss_meta_server` VALUES(380, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_mines', 5, 0, 2);
INSERT INTO `ss_meta_server` VALUES(381, '89.107.19.233', '8888', '89.107.19.233', 'ac_desert3', 5, 0, 7);
INSERT INTO `ss_meta_server` VALUES(382, '89.107.19.233', '8888', '89.107.19.233', 'ac_desert3', 5, 0, 5);
INSERT INTO `ss_meta_server` VALUES(383, '89.107.19.233', '8888', '89.107.19.233', 'ac_desert3', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(384, '89.107.19.233', '8888', '89.107.19.233', 'ac_desert3', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(385, '', '', '', 'ac_ingress', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(386, '78.46.50.34', '28765', 'itavd.org', 'ac_mines', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(387, '78.46.50.34', '28765', 'itavd.org', 'ac_mines', 5, 0, 10);
INSERT INTO `ss_meta_server` VALUES(388, '195.3.138.250', '8999', '195.3.138.250', 'Gema-10-by-Phoenix.94', 5, 0, 15);
INSERT INTO `ss_meta_server` VALUES(389, '195.3.138.250', '8999', '195.3.138.250', 'ac_aqueous', 0, 0, 14);
INSERT INTO `ss_meta_server` VALUES(390, '199.167.196.59', '7999', '199.167.196.59', 'ac_aqueous', 0, 2, 13);
INSERT INTO `ss_meta_server` VALUES(391, '199.167.196.59', '7999', '199.167.196.59', 'ac_aqueous', 0, 2, 0);
INSERT INTO `ss_meta_server` VALUES(392, '199.167.196.59', '7999', '199.167.196.59', 'ac_desert3', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(393, '199.167.196.59', '7999', '199.167.196.59', 'ac_ingress', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(394, '199.167.196.59', '7999', '199.167.196.59', 'ac_ingress', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(395, '199.167.196.59', '7999', '199.167.196.59', 'ac_ingress', 5, 0, 2);
INSERT INTO `ss_meta_server` VALUES(396, '199.167.196.59', '7999', '199.167.196.59', 'ac_ingress', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(397, '199.167.196.59', '7999', '199.167.196.59', 'ac_ingress', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(398, '199.167.196.59', '7999', '199.167.196.59', 'ac_ingress', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(399, '199.167.196.59', '7999', '199.167.196.59', 'ac_shine', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(400, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_gothic', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(401, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_gothic', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(402, '69.85.88.168', '38769', '69.85.88.168', 'ac_depot_classic', 5, 0, 15);
INSERT INTO `ss_meta_server` VALUES(403, '46.29.248.33', '28763', '46.29.248.33', 'ac_desert2', 13, 0, 5);
INSERT INTO `ss_meta_server` VALUES(404, '46.29.248.33', '28763', '46.29.248.33', 'ac_desert2', 13, 0, 4);
INSERT INTO `ss_meta_server` VALUES(405, '46.29.248.33', '28763', '46.29.248.33', 'ac_desert2', 13, 0, 3);
INSERT INTO `ss_meta_server` VALUES(406, '46.29.248.33', '28763', '46.29.248.33', 'ac_desert2', 13, 0, 0);
INSERT INTO `ss_meta_server` VALUES(407, '46.29.248.33', '28763', '46.29.248.33', 'ac_sunset', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(408, '195.3.138.250', '7999', '195.3.138.250', 'ac_gothic', 5, 2, 9);
INSERT INTO `ss_meta_server` VALUES(409, '195.3.138.250', '7999', '195.3.138.250', 'ac_gothic', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(410, '70.42.74.212', '28775', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_gothic', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(411, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_shine', 5, 0, 15);
INSERT INTO `ss_meta_server` VALUES(412, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_shine', 5, 0, 14);
INSERT INTO `ss_meta_server` VALUES(422, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_shine', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(423, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_shine', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(424, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_shine', 5, 0, 10);
INSERT INTO `ss_meta_server` VALUES(427, '', '', '', 'ac_outpost', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(428, '46.163.111.98', '34100', 'wvps46-163-111-98.dedicated.hosteurope.de', 'ac_power', 5, 0, 10);
INSERT INTO `ss_meta_server` VALUES(429, '46.163.111.98', '34100', 'wvps46-163-111-98.dedicated.hosteurope.de', 'ac_power', 5, 0, 10);
INSERT INTO `ss_meta_server` VALUES(430, '46.163.111.98', '34100', 'wvps46-163-111-98.dedicated.hosteurope.de', 'ac_power', 5, 0, 9);
INSERT INTO `ss_meta_server` VALUES(431, '', '', '', 'ac_rattrap', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(432, '70.42.74.212', '28775', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_power', 5, 0, 10);
INSERT INTO `ss_meta_server` VALUES(433, '70.42.74.212', '28775', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_power', 5, 0, 9);
INSERT INTO `ss_meta_server` VALUES(434, '70.42.74.212', '28775', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_power', 5, 0, 7);
INSERT INTO `ss_meta_server` VALUES(435, '70.42.74.212', '28775', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_power', 5, 0, 7);
INSERT INTO `ss_meta_server` VALUES(436, '70.42.74.212', '28775', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_power', 5, 0, 5);
INSERT INTO `ss_meta_server` VALUES(437, '70.42.74.212', '28775', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_power', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(438, '', '', '', 'ac_scaffold', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(439, '70.42.74.212', '28775', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_shine', 5, 0, 13);
INSERT INTO `ss_meta_server` VALUES(440, '70.42.74.212', '28775', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_shine', 5, 0, 13);
INSERT INTO `ss_meta_server` VALUES(441, '70.42.74.212', '28775', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_shine', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(442, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_desert2', 13, 0, 0);
INSERT INTO `ss_meta_server` VALUES(443, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_sunset', 5, 0, 9);
INSERT INTO `ss_meta_server` VALUES(444, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_sunset', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(445, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_sunset', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(446, '198.23.134.111', '28765', 'host.colocrossing.com', 'apollo_abbey', 5, 0, 7);
INSERT INTO `ss_meta_server` VALUES(447, '198.23.134.111', '28765', 'host.colocrossing.com', 'apollo_abbey', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(448, '198.23.134.111', '28765', 'host.colocrossing.com', 'apollo_abbey', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(449, '198.23.134.111', '28765', 'host.colocrossing.com', 'apollo_abbey', 5, 0, 5);
INSERT INTO `ss_meta_server` VALUES(450, '198.23.134.111', '28765', 'host.colocrossing.com', 'apollo_abbey', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(451, '198.23.134.111', '28765', 'host.colocrossing.com', 'apollo_abbey', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(452, '198.23.134.111', '28765', 'host.colocrossing.com', 'apollo_abbey', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(453, '', '', '', 'ac_arabian', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(454, '', '', '', 'ac_depot', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(455, '', '', '', 'ac_werk', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(456, '', '', '', 'ac_scaffold', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(457, '', '', '', 'ac_mines', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(458, '', '', '', 'ac_complex', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(459, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_power', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(460, '', '', '', 'ac_keller', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(461, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_power', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(462, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_power', 5, 0, 3);
INSERT INTO `ss_meta_server` VALUES(463, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_power', 5, 0, 2);
INSERT INTO `ss_meta_server` VALUES(464, '198.23.134.111', '28765', 'host.colocrossing.com', 'ac_power', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(465, '64.85.165.123', '28765', '64.85.165.123', 'ac_mines', 5, 0, 7);
INSERT INTO `ss_meta_server` VALUES(466, '64.85.165.123', '28765', '64.85.165.123', 'ac_mines', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(467, '64.85.165.123', '28765', '64.85.165.123', 'ac_mines', 5, 0, 5);
INSERT INTO `ss_meta_server` VALUES(468, '64.85.165.123', '28765', '64.85.165.123', 'ac_mines', 5, 0, 4);
INSERT INTO `ss_meta_server` VALUES(469, '64.85.165.123', '28765', '64.85.165.123', 'ac_mines', 5, 0, 3);
INSERT INTO `ss_meta_server` VALUES(470, '64.85.165.123', '28765', '64.85.165.123', 'ac_mines', 5, 0, 2);
INSERT INTO `ss_meta_server` VALUES(471, '', '', '', 'ac_scaffold', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(472, '103.6.213.144', '11111', '103.6.213.144', 'ac_desert3', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(473, '103.6.213.144', '11111', '103.6.213.144', 'ac_desert3', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(474, '103.6.213.144', '11111', '103.6.213.144', 'ac_desert3', 5, 0, 10);
INSERT INTO `ss_meta_server` VALUES(475, '', '', '', 'ac_iceroad', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(476, '', '', '', 'ac_power', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(477, '', '', '', 'ac_power', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(478, '', '', '', 'ac_ingress', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(479, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_sunset', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(480, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_sunset', 5, 0, 5);
INSERT INTO `ss_meta_server` VALUES(481, '184.82.187.56', '28763', '184-82-187-56.static.hostnoc.net', 'ac_desert3', 5, 0, 3);
INSERT INTO `ss_meta_server` VALUES(482, '88.191.153.35', '6600', 'sd-33823.dedibox.fr', 'ac_depot', 5, 0, 3);
INSERT INTO `ss_meta_server` VALUES(483, '88.191.153.35', '6600', 'sd-33823.dedibox.fr', 'ac_depot', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(484, '88.191.153.35', '6600', 'sd-33823.dedibox.fr', 'ac_desert3', 14, 0, 2);
INSERT INTO `ss_meta_server` VALUES(485, '88.191.153.35', '6600', 'sd-33823.dedibox.fr', 'ac_desert3', 14, 0, 0);
INSERT INTO `ss_meta_server` VALUES(486, '', '', '', 'ac_keller', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(487, '', '', '', 'ac_keller', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(488, '', '', '', 'ac_keller', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(489, '', '', '', 'ac_keller', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(490, '', '', '', 'ac_keller', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(491, '', '', '', 'ac_keller', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(492, '', '', '', 'ac_arctic', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(493, '', '', '', 'ac_arctic', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(494, '', '', '', 'ac_arctic', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(495, '', '', '', 'ac_arctic', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(496, '', '', '', 'ac_arctic', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(497, '184.82.187.56', '28763', '184-82-187-56.static.hostnoc.net', 'ac_desert3', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(498, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_shine', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(499, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_elevation', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(500, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_elevation', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(501, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_shine', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(502, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_shine', 5, 0, 9);
INSERT INTO `ss_meta_server` VALUES(503, '', '', '', 'ac_shine', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(504, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_sunset', 5, 0, 14);
INSERT INTO `ss_meta_server` VALUES(505, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_sunset', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(506, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_sunset', 5, 0, 9);
INSERT INTO `ss_meta_server` VALUES(507, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_sunset', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(508, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_sunset', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(509, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_sunset', 5, 0, 2);
INSERT INTO `ss_meta_server` VALUES(510, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_sunset', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(511, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_ingress', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(512, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_ingress', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(513, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_ingress', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(514, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_ingress', 5, 0, 7);
INSERT INTO `ss_meta_server` VALUES(515, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_ingress', 5, 0, 6);
INSERT INTO `ss_meta_server` VALUES(516, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_ingress', 5, 0, 5);
INSERT INTO `ss_meta_server` VALUES(517, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_ingress', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(518, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_ingress', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(519, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_shine', 5, 0, 13);
INSERT INTO `ss_meta_server` VALUES(520, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_shine', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(521, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_shine', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(522, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_riverdry', 14, 0, 7);
INSERT INTO `ss_meta_server` VALUES(523, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_riverdry', 14, 0, 6);
INSERT INTO `ss_meta_server` VALUES(524, '70.42.74.212', '28763', 'v-70-42-74-212.unman-vds.internap-nyc.nfoservers.com', 'ac_riverdry', 14, 0, 6);
INSERT INTO `ss_meta_server` VALUES(525, '', '', '', 'ac_urban', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(526, '', '', '', 'ac_desert2', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(527, '189.68.80.218', '28763', '189-68-80-218.dsl.telesp.net.br', 'ac_douze', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(528, '189.68.80.218', '28763', '189-68-80-218.dsl.telesp.net.br', 'ac_douze', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(529, '', '', '', 'ac_arctic', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(530, '', '', '', 'ac_arctic', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(531, '', '', '', 'ac_arid', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(532, '', '', '', 'ac_sunset', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(533, '', '', '', 'ac_complex', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(534, '', '', '', 'ac_arabian', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(535, '189.68.80.218', '28763', '189-68-80-218.dsl.telesp.net.br', 'ac_desert', 0, 0, 3);
INSERT INTO `ss_meta_server` VALUES(536, '195.3.138.250', '9999', '195.3.138.250', 'ac_shine', 5, 0, 13);
INSERT INTO `ss_meta_server` VALUES(537, '195.3.138.250', '9999', '195.3.138.250', 'ac_shine', 5, 0, 12);
INSERT INTO `ss_meta_server` VALUES(538, '195.3.138.250', '9999', '195.3.138.250', 'ac_shine', 5, 0, 11);
INSERT INTO `ss_meta_server` VALUES(539, '195.3.138.250', '9999', '195.3.138.250', 'ac_shine', 5, 0, 9);
INSERT INTO `ss_meta_server` VALUES(540, '195.3.138.250', '9999', '195.3.138.250', 'ac_shine', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(541, '195.3.138.250', '9999', '195.3.138.250', 'ac_shine', 5, 0, 8);
INSERT INTO `ss_meta_server` VALUES(542, '195.3.138.250', '9999', '195.3.138.250', 'ac_desert3', 5, 2, 8);
INSERT INTO `ss_meta_server` VALUES(543, '195.3.138.250', '9999', '195.3.138.250', 'ac_desert3', 5, 2, 4);
INSERT INTO `ss_meta_server` VALUES(544, '195.3.138.250', '9999', '195.3.138.250', 'ac_desert3', 5, 2, 2);
INSERT INTO `ss_meta_server` VALUES(545, '195.3.138.250', '9999', '195.3.138.250', 'ac_desert3', 5, 2, 1);
INSERT INTO `ss_meta_server` VALUES(546, '195.3.138.250', '9999', '195.3.138.250', 'ac_desert3', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(547, '195.3.138.250', '9999', '195.3.138.250', 'ac_desert3', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(548, '195.3.138.250', '9999', '195.3.138.250', 'ac_sunset', 5, 2, 0);
INSERT INTO `ss_meta_server` VALUES(549, '', '', '', 'ac_depot', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(550, '62.75.235.225', '3841', 'xray429.server4you.de', 'ac_desert2', 13, 0, 0);
INSERT INTO `ss_meta_server` VALUES(551, '62.75.235.225', '3841', 'xray429.server4you.de', 'ac_arid', 0, 0, 7);
INSERT INTO `ss_meta_server` VALUES(552, '88.191.153.35', '6600', 'sd-33823.dedibox.fr', 'ac_desert', 11, 0, 3);
INSERT INTO `ss_meta_server` VALUES(553, '88.191.153.35', '6600', 'sd-33823.dedibox.fr', 'ac_desert', 11, 0, 3);
INSERT INTO `ss_meta_server` VALUES(554, '88.191.153.35', '6600', 'sd-33823.dedibox.fr', 'ac_desert', 11, 0, 1);
INSERT INTO `ss_meta_server` VALUES(555, '', '', '', 'ac_depot', 0, 0, 0);
INSERT INTO `ss_meta_server` VALUES(556, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_sunset', 5, 0, 1);
INSERT INTO `ss_meta_server` VALUES(557, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_sunset', 5, 0, 0);
INSERT INTO `ss_meta_server` VALUES(558, '71.233.186.148', '65010', 'c-71-233-186-148.hsd1.ct.comcast.net', 'ac_complex', 0, 0, 8);

-- --------------------------------------------------------

--
-- Table structure for table `ss_meta_tagged`
--

DROP TABLE IF EXISTS `ss_meta_tagged`;
CREATE TABLE IF NOT EXISTS `ss_meta_tagged` (
  `ss_id` int(16) NOT NULL,
  `tag_id` int(16) NOT NULL,
  UNIQUE KEY `ss_id` (`ss_id`,`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `ss_meta_tagged`
--


-- --------------------------------------------------------

--
-- Table structure for table `ss_tags`
--

DROP TABLE IF EXISTS `ss_tags`;
CREATE TABLE IF NOT EXISTS `ss_tags` (
  `tag_id` int(16) NOT NULL auto_increment,
  `text` varchar(64) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`tag_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=8 ;

--
-- Dumping data for table `ss_tags`
--

INSERT INTO `ss_tags` VALUES(7, 'blacklist');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) NOT NULL auto_increment,
  `nick` varchar(255) collate utf8_bin NOT NULL,
  `email` varchar(128) collate utf8_bin NOT NULL,
  `password_hash` varchar(60) collate utf8_bin NOT NULL,
  `salt` varchar(5) collate utf8_bin NOT NULL,
  `activation_key` varchar(32) collate utf8_bin NOT NULL,
  `activated` tinyint(1) NOT NULL default '0',
  `upload_key` varchar(8) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `nick` (`nick`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=58 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES(20, 'gdm', 'gdm.jerboa@gmail.com', '$2a$08$RAz5TiyWvsbuamnfK6iF6.dDf7qb7EZonqnetJ4rid83SYiAXlzYS', '402f2', 'ohfylxGqZG01GGukKZKDYToamCxhf78X', 1, 'IWgvMAy8');
INSERT INTO `users` VALUES(31, 'Verse', 'versesquared@gmail.com', '$2a$08$CfSQ4lLZV6/nHySl/MtRF.ezak1L0sPSK4CBaRLLnG22aWLa76WUy', 'f4ab7', '7xX6hkLFzt5J68jSs1BePla1676uT72Z', 1, 'lWp1ZI0F');
INSERT INTO `users` VALUES(32, 'Orynge', 'orynge@live.com', '$2a$08$9IrbprwRUDbmBkpEKvU6pes80DQfF4jZksPT0g//ad9kP9BsFCtCi', '60113', 'ph2MBN0ZhJ3A0jZK9BMB2p2wbEZ7Hpg', 1, 'qMtLdJ2T');
INSERT INTO `users` VALUES(33, 'Lateralus', 'shauny_be_good@yahoo.com', '$2a$08$7l16wSQ808IRmi4bxmisc.ZbAzyEgAo9.U4HPR4QZJe.5wRY95PCG', '46c64', 'J0hnn4oQaPq1OZggCh8vl49Qoitk960d', 1, 'YtjRUhcL');
INSERT INTO `users` VALUES(35, 'Joe Smith', 'jtsjoe@gmail.com', '$2a$08$Imwk9TEk2AZmO/EIUqhlIekQE2AGozWzgUkkD6TTIhLipvEcpnwku', '6b5b7', 'QaQzPtvMLIxWRuN15l3ZZkd9AZovXu6P', 1, 'yg3dZXSi');
INSERT INTO `users` VALUES(46, 'ikljo', 'hype.ikljo@gmail.com', '$2a$08$AMWewCVHblFOFpt5gylfIO3EMGiatEVxpszhd5KlG2iRDdnZZGhE.', 'cd4ce', '2JtyxXAwjjxesk2aCfebmSGTaAKC2mc', 0, 'cndRLr6');

-- --------------------------------------------------------

--
-- Table structure for table `x_answers`
--

DROP TABLE IF EXISTS `x_answers`;
CREATE TABLE IF NOT EXISTS `x_answers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `topic_id` int(10) NOT NULL,
  `answer` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `x_answers`
--


-- --------------------------------------------------------

--
-- Table structure for table `x_attach_files`
--

DROP TABLE IF EXISTS `x_attach_files`;
CREATE TABLE IF NOT EXISTS `x_attach_files` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `owner_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  `topic_id` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `file_ext` varchar(64) NOT NULL,
  `file_mime_type` varchar(64) NOT NULL,
  `file_path` text NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `download_counter` int(10) unsigned NOT NULL default '0',
  `uploaded_at` int(10) unsigned NOT NULL,
  `secure_str` varchar(32) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `x_attach_files`
--


-- --------------------------------------------------------

--
-- Table structure for table `x_bans`
--

DROP TABLE IF EXISTS `x_bans`;
CREATE TABLE IF NOT EXISTS `x_bans` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(200) default NULL,
  `ip` varchar(255) default NULL,
  `email` varchar(80) default NULL,
  `message` varchar(255) default NULL,
  `expire` int(10) unsigned default NULL,
  `ban_creator` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `x_bans`
--


-- --------------------------------------------------------

--
-- Table structure for table `x_categories`
--

DROP TABLE IF EXISTS `x_categories`;
CREATE TABLE IF NOT EXISTS `x_categories` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cat_name` varchar(80) NOT NULL default 'New Category',
  `disp_position` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `x_categories`
--

INSERT INTO `x_categories` VALUES(2, 'Feedback', 2);
INSERT INTO `x_categories` VALUES(3, 'News', 3);
INSERT INTO `x_categories` VALUES(5, 'Help', 1);

-- --------------------------------------------------------

--
-- Table structure for table `x_censoring`
--

DROP TABLE IF EXISTS `x_censoring`;
CREATE TABLE IF NOT EXISTS `x_censoring` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `search_for` varchar(60) NOT NULL default '',
  `replace_with` varchar(60) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `x_censoring`
--


-- --------------------------------------------------------

--
-- Table structure for table `x_config`
--

DROP TABLE IF EXISTS `x_config`;
CREATE TABLE IF NOT EXISTS `x_config` (
  `conf_name` varchar(255) NOT NULL default '',
  `conf_value` text,
  PRIMARY KEY  (`conf_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_config`
--

INSERT INTO `x_config` VALUES('o_cur_version', '1.4.2');
INSERT INTO `x_config` VALUES('o_database_revision', '5');
INSERT INTO `x_config` VALUES('o_board_title', 'Eye of AC');
INSERT INTO `x_config` VALUES('o_board_desc', 'AssaultCube Screenshot Sharing');
INSERT INTO `x_config` VALUES('p_pun_poll_enable_read', '0');
INSERT INTO `x_config` VALUES('o_default_timezone', '0');
INSERT INTO `x_config` VALUES('o_time_format', 'H:i:s');
INSERT INTO `x_config` VALUES('o_date_format', 'Y-m-d');
INSERT INTO `x_config` VALUES('o_check_for_updates', '1');
INSERT INTO `x_config` VALUES('o_check_for_versions', '1');
INSERT INTO `x_config` VALUES('o_timeout_visit', '5400');
INSERT INTO `x_config` VALUES('o_timeout_online', '300');
INSERT INTO `x_config` VALUES('o_redirect_delay', '0');
INSERT INTO `x_config` VALUES('o_show_version', '0');
INSERT INTO `x_config` VALUES('o_show_user_info', '1');
INSERT INTO `x_config` VALUES('o_show_post_count', '1');
INSERT INTO `x_config` VALUES('o_signatures', '1');
INSERT INTO `x_config` VALUES('o_smilies', '1');
INSERT INTO `x_config` VALUES('o_smilies_sig', '1');
INSERT INTO `x_config` VALUES('o_make_links', '0');
INSERT INTO `x_config` VALUES('o_default_lang', 'English');
INSERT INTO `x_config` VALUES('o_default_style', 'Oxygen');
INSERT INTO `x_config` VALUES('o_default_user_group', '3');
INSERT INTO `x_config` VALUES('o_topic_review', '15');
INSERT INTO `x_config` VALUES('o_disp_topics_default', '30');
INSERT INTO `x_config` VALUES('o_disp_posts_default', '25');
INSERT INTO `x_config` VALUES('o_indent_num_spaces', '4');
INSERT INTO `x_config` VALUES('o_quote_depth', '5');
INSERT INTO `x_config` VALUES('o_quickpost', '1');
INSERT INTO `x_config` VALUES('o_users_online', '1');
INSERT INTO `x_config` VALUES('o_censoring', '0');
INSERT INTO `x_config` VALUES('o_ranks', '0');
INSERT INTO `x_config` VALUES('o_show_dot', '0');
INSERT INTO `x_config` VALUES('o_topic_views', '1');
INSERT INTO `x_config` VALUES('o_quickjump', '0');
INSERT INTO `x_config` VALUES('o_gzip', '1');
INSERT INTO `x_config` VALUES('o_additional_navlinks', '');
INSERT INTO `x_config` VALUES('o_report_method', '0');
INSERT INTO `x_config` VALUES('o_regs_report', '0');
INSERT INTO `x_config` VALUES('o_default_email_setting', '1');
INSERT INTO `x_config` VALUES('o_mailing_list', 'eye.of.ac@gmail.com');
INSERT INTO `x_config` VALUES('o_avatars', '1');
INSERT INTO `x_config` VALUES('o_avatars_dir', 'img/avatars');
INSERT INTO `x_config` VALUES('o_avatars_width', '60');
INSERT INTO `x_config` VALUES('o_avatars_height', '60');
INSERT INTO `x_config` VALUES('o_avatars_size', '15360');
INSERT INTO `x_config` VALUES('o_search_all_forums', '1');
INSERT INTO `x_config` VALUES('o_sef', 'Default');
INSERT INTO `x_config` VALUES('o_admin_email', 'eye.of.ac@gmail.com');
INSERT INTO `x_config` VALUES('o_webmaster_email', 'eye.of.ac@gmail.com');
INSERT INTO `x_config` VALUES('o_subscriptions', '1');
INSERT INTO `x_config` VALUES('o_smtp_host', NULL);
INSERT INTO `x_config` VALUES('o_smtp_user', NULL);
INSERT INTO `x_config` VALUES('o_smtp_pass', NULL);
INSERT INTO `x_config` VALUES('o_smtp_ssl', '0');
INSERT INTO `x_config` VALUES('o_regs_allow', '0');
INSERT INTO `x_config` VALUES('o_regs_verify', '1');
INSERT INTO `x_config` VALUES('o_announcement', '0');
INSERT INTO `x_config` VALUES('o_announcement_heading', 'Sample announcement');
INSERT INTO `x_config` VALUES('o_announcement_message', '<p>Enter your announcement here.</p>');
INSERT INTO `x_config` VALUES('o_rules', '0');
INSERT INTO `x_config` VALUES('o_rules_message', 'Enter your rules here.');
INSERT INTO `x_config` VALUES('o_maintenance', '0');
INSERT INTO `x_config` VALUES('o_maintenance_message', 'The forums are temporarily down for maintenance. Please try again in a few minutes.<br /><br />Administrator');
INSERT INTO `x_config` VALUES('o_default_dst', '0');
INSERT INTO `x_config` VALUES('p_message_bbcode', '1');
INSERT INTO `x_config` VALUES('p_message_img_tag', '1');
INSERT INTO `x_config` VALUES('p_message_all_caps', '0');
INSERT INTO `x_config` VALUES('p_subject_all_caps', '0');
INSERT INTO `x_config` VALUES('p_sig_all_caps', '1');
INSERT INTO `x_config` VALUES('p_sig_bbcode', '1');
INSERT INTO `x_config` VALUES('p_sig_img_tag', '0');
INSERT INTO `x_config` VALUES('p_sig_length', '400');
INSERT INTO `x_config` VALUES('p_sig_lines', '4');
INSERT INTO `x_config` VALUES('p_allow_banned_email', '0');
INSERT INTO `x_config` VALUES('p_allow_dupe_email', '0');
INSERT INTO `x_config` VALUES('p_force_guest_email', '1');
INSERT INTO `x_config` VALUES('o_show_moderators', '1');
INSERT INTO `x_config` VALUES('o_mask_passwords', '1');
INSERT INTO `x_config` VALUES('p_pun_poll_enable_revote', '1');
INSERT INTO `x_config` VALUES('p_pun_poll_max_answers', '2');
INSERT INTO `x_config` VALUES('attach_always_deny', 'html,htm,php,php3,php4,exe,com,bat,doc,pdf,wav,mp3,ogg,avi,mpg,mpeg');
INSERT INTO `x_config` VALUES('attach_basefolder', 'extensions/pun_attachment/attachments/');
INSERT INTO `x_config` VALUES('attach_create_orphans', '0');
INSERT INTO `x_config` VALUES('attach_icon_folder', 'http://hype-clan.com/eyeofac/forum/extensions/pun_attachment/img/');
INSERT INTO `x_config` VALUES('attach_icon_extension', 'txt,doc,pdf,wav,mp3,ogg,avi,mpg,mpeg,png,jpg,jpeg,gif');
INSERT INTO `x_config` VALUES('attach_icon_name', 'text.png,doc.png,doc.png,audio.png,audio.png,audio.png,video.png,video.png,video.png,image.png,image.png,image.png,image.png');
INSERT INTO `x_config` VALUES('attach_subfolder', 'f9324e813d0d5bbf332991f19d1cff68');
INSERT INTO `x_config` VALUES('attach_use_icon', '1');
INSERT INTO `x_config` VALUES('attach_disp_small', '1');
INSERT INTO `x_config` VALUES('attach_small_height', '60');
INSERT INTO `x_config` VALUES('attach_small_width', '60');
INSERT INTO `x_config` VALUES('attach_disable_attach', '0');

-- --------------------------------------------------------

--
-- Table structure for table `x_extensions`
--

DROP TABLE IF EXISTS `x_extensions`;
CREATE TABLE IF NOT EXISTS `x_extensions` (
  `id` varchar(150) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `version` varchar(25) NOT NULL default '',
  `description` text,
  `author` varchar(50) NOT NULL default '',
  `uninstall` text,
  `uninstall_note` text,
  `disabled` tinyint(1) NOT NULL default '0',
  `dependencies` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_extensions`
--

INSERT INTO `x_extensions` VALUES('pun_poll', 'Pun poll', '2.3', 'Adds polls feature for topics.', 'PunBB Development team', '$forum_db->drop_table(''questions'');\n		$forum_db->drop_table(''answers'');\n		$forum_db->drop_table(''voting'');\n		$forum_db->drop_field(''groups'', ''g_poll_add'');\n\n		forum_config_remove(array(''p_pun_poll_enable_read'', ''p_pun_poll_enable_revote'', ''p_pun_poll_max_answers''));', NULL, 0, '||');
INSERT INTO `x_extensions` VALUES('pun_attachment', 'Attachment', '1.1.19', 'Allows users to attach files to posts.', 'PunBB Development Team', '$attached_files = scandir(FORUM_ROOT.$forum_config[''attach_basefolder''].$forum_config[''attach_subfolder''].DIRECTORY_SEPARATOR);\n		foreach ($attached_files as $file)\n			if ($file != ''.'' && $file != ''..'')\n				unlink(FORUM_ROOT.$forum_config[''attach_basefolder''].$forum_config[''attach_subfolder''].DIRECTORY_SEPARATOR.$file);\n		rmdir(FORUM_ROOT.$forum_config[''attach_basefolder''].$forum_config[''attach_subfolder'']);\n\n		$forum_db->drop_table(''attach_files'');\n		$forum_db->drop_field(''groups'', ''g_pun_attachment_allow_download'');\n		$forum_db->drop_field(''groups'', ''g_pun_attachment_allow_upload'');\n		$forum_db->drop_field(''groups'', ''g_pun_attachment_allow_delete'');\n		$forum_db->drop_field(''groups'', ''g_pun_attachment_allow_delete_own'');\n		$forum_db->drop_field(''groups'', ''g_pun_attachment_upload_max_size'');\n		$forum_db->drop_field(''groups'', ''g_pun_attachment_files_per_post'');\n		$forum_db->drop_field(''groups'', ''g_pun_attachment_disallowed_extensions'');\n\n		forum_config_remove(array(''attach_always_deny'', ''attach_basefolder'', ''attach_create_orphans'', ''attach_cur_version'', ''attach_icon_folder'', ''attach_icon_extension'', ''attach_icon_name'', ''attach_subfolder'', ''attach_disable_attach'', ''attach_disp_small'', ''attach_small_height'', ''attach_small_width'', ''attach_use_icon''));', 'WARNING: all users'' attachments will be removed during the uninstallation process. It is recommended that you disable the "pun_attachment" extension instead, or upgrade it without uninstalling.', 0, '||');

-- --------------------------------------------------------

--
-- Table structure for table `x_extension_hooks`
--

DROP TABLE IF EXISTS `x_extension_hooks`;
CREATE TABLE IF NOT EXISTS `x_extension_hooks` (
  `id` varchar(150) NOT NULL default '',
  `extension_id` varchar(50) NOT NULL default '',
  `code` text,
  `installed` int(10) unsigned NOT NULL default '0',
  `priority` tinyint(1) unsigned NOT NULL default '5',
  PRIMARY KEY  (`id`,`extension_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_extension_hooks`
--

INSERT INTO `x_extension_hooks` VALUES('ed_start', 'pun_poll', 'if ($forum_user[''language''] !== ''English'' && file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n				include_once $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n			else\n				include_once $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n\n			include $ext_info[''path''].''/functions.php'';\n\n			if ($forum_user[''style''] !== ''Oxygen'' && file_exists($ext_info[''path''].''/css/''.$forum_user[''style''].''/pun_poll.min.css''))\n				$forum_loader->add_css($ext_info[''url''].''/css/''.$forum_user[''style''].''/pun_poll.min.css'', array(''type'' => ''url'', ''media'' => ''screen''));\n			else\n				$forum_loader->add_css($ext_info[''url''].''/css/Oxygen/pun_poll.min.css'', array(''type'' => ''url'', ''media'' => ''screen''));\n\n			// No script CSS\n			$forum_loader->add_css(''#pun_poll_switcher_block, #pun_poll_add_options_link { display: none; } #pun_poll_form_block, #pun_poll_update_block { display: block !important; }'', array(''type'' => ''inline'', ''noscript'' => true));\n\n			// JS\n			$forum_loader->add_js($ext_info[''url''].''/js/pun_poll.min.js'', array(''type'' => ''url'', ''async'' => true));', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('po_start', 'pun_poll', 'if ($forum_user[''language''] !== ''English'' && file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n				include_once $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n			else\n				include_once $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n\n			include $ext_info[''path''].''/functions.php'';\n\n			if ($forum_user[''style''] !== ''Oxygen'' && file_exists($ext_info[''path''].''/css/''.$forum_user[''style''].''/pun_poll.min.css''))\n				$forum_loader->add_css($ext_info[''url''].''/css/''.$forum_user[''style''].''/pun_poll.min.css'', array(''type'' => ''url'', ''media'' => ''screen''));\n			else\n				$forum_loader->add_css($ext_info[''url''].''/css/Oxygen/pun_poll.min.css'', array(''type'' => ''url'', ''media'' => ''screen''));\n\n			// No script CSS\n			$forum_loader->add_css(''#pun_poll_switcher_block, #pun_poll_add_options_link { display: none; } #pun_poll_form_block, #pun_poll_update_block { display: block !important; }'', array(''type'' => ''inline'', ''noscript'' => true));\n\n			// JS\n			$forum_loader->add_js($ext_info[''url''].''/js/pun_poll.min.js'', array(''type'' => ''url'', ''async'' => true));', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_post_selected', 'pun_poll', '$topic_poll = FALSE;\n			if ($can_edit_subject && ($forum_user[''group_id''] == FORUM_ADMIN || $forum_user[''g_poll_add''])) {\n				$pun_poll_query = array(\n					''SELECT''	=>	''question, read_unvote_users, revote, created, days_count, votes_count'',\n					''FROM''		=>	''questions'',\n					''WHERE''		=>	''topic_id = ''.$cur_post[''tid'']\n				);\n				$pun_poll_results = $forum_db->query_build($pun_poll_query) or error(__FILE__, __LINE__);\n\n				if ($row = $forum_db->fetch_row($pun_poll_results)) {\n					list($poll_question, $poll_read_unvote_users, $poll_revote, $poll_created, $poll_days_count, $poll_votes_count) = $row;\n					$topic_poll = TRUE;\n				}\n\n				if ($topic_poll) {\n					$pun_poll_query = array(\n						''SELECT''	=>	''answer'',\n						''FROM''		=>	''answers'',\n						''WHERE''		=>	''topic_id = ''.$cur_post[''tid''],\n						''ORDER BY''	=>	''id ASC''\n					);\n					$pun_poll_results = $forum_db->query_build($pun_poll_query) or error(__FILE__, __LINE__);\n\n					$poll_answers = array();\n					while ($cur_answer = $forum_db->fetch_assoc($pun_poll_results)) {\n						$poll_answers[] = $cur_answer[''answer''];\n					}\n\n					if (empty($poll_answers)) {\n						message($lang_common[''Bad request'']);\n					}\n				}\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_pre_header_load', 'pun_poll', '//\n			$forum_page[''hidden_fields''][''pun_poll_block_status''] = ''<input type="hidden" name="pun_poll_block_open" id="pun_poll_block_status" value="1" />'';', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_form_submitted', 'pun_poll', 'if (!isset($_POST[''preview'']) && $can_edit_subject && ($forum_user[''group_id''] == FORUM_ADMIN || $forum_user[''g_poll_add''])) {\n				$reset_poll = (isset($_POST[''reset_poll'']) && $_POST[''reset_poll''] == ''1'') ? true : false;\n				$remove_poll = (isset($_POST[''remove_poll'']) && $_POST[''remove_poll''] == ''1'') ? true : false;\n\n				// We need to reset poll\n				if ($reset_poll) {\n					Pun_poll::reset_poll($cur_post[''tid'']);\n				}\n\n				if ($remove_poll) {\n					Pun_poll::remove_poll($cur_post[''tid'']);\n				}\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_end_validation', 'pun_poll', 'if (!isset($_POST[''reset_poll'']) || $_POST[''reset_poll''] != ''1'') {\n\n				if (($forum_user[''group_id''] == FORUM_ADMIN && $can_edit_subject) || ($can_edit_subject && !$topic_poll)) {\n					// Get information about new poll.\n					$new_poll_question = isset($_POST[''question_of_poll'']) && !empty($_POST[''question_of_poll'']) ? $_POST[''question_of_poll''] : FALSE;\n					if (!empty($new_poll_question)) {\n						$new_poll_answers = isset($_POST[''poll_answer'']) && !empty($_POST[''poll_answer'']) ? $_POST[''poll_answer''] : FALSE;\n						$new_poll_days = isset($_POST[''allow_poll_days'']) && !empty($_POST[''allow_poll_days'']) ? $_POST[''allow_poll_days''] : FALSE;\n						$new_poll_votes = isset($_POST[''allow_poll_votes'']) && !empty($_POST[''allow_poll_votes'']) ? $_POST[''allow_poll_votes''] : FALSE;\n						$new_read_unvote_users = isset($_POST[''read_unvote_users'']) && !empty($_POST[''read_unvote_users'']) ? $_POST[''read_unvote_users''] : FALSE;\n						$new_revote = isset($_POST[''revouting'']) ? $_POST[''revouting''] : FALSE;\n\n						Pun_poll::data_validation($new_poll_question, $new_poll_answers, $new_poll_days, $new_poll_votes, $new_read_unvote_users, $new_revote);\n					}\n\n					if (isset($_POST[''update_poll''])) {\n						$new_poll_ans_count = isset($_POST[''poll_ans_count'']) && intval($_POST[''poll_ans_count'']) > 0 ? intval($_POST[''poll_ans_count'']) : FALSE;\n\n						if (!$new_poll_ans_count)\n							$errors[] = $lang_pun_poll[''Empty option count''];\n						if ($new_poll_ans_count < 2)\n						{\n							$errors[] = $lang_pun_poll[''Min cnt options''];\n							$new_poll_ans_count = 2;\n						}\n\n						if ($new_poll_ans_count > $forum_config[''p_pun_poll_max_answers''])\n						{\n							$errors[] = sprintf($lang_pun_poll[''Max cnt options''], $forum_config[''p_pun_poll_max_answers'']);\n							$new_poll_ans_count = $forum_config[''p_pun_poll_max_answers''];\n						}\n\n						$_POST[''preview''] = 1;\n					} else if ($new_poll_question !== FALSE && empty($errors) && !isset($_POST[''preview''])) {\n						if (!$topic_poll) {\n							Pun_poll::add_poll($cur_post[''tid''], $new_poll_question, $new_poll_answers, $new_poll_days !== FALSE ? $new_poll_days : ''NULL'', $new_poll_votes !== FALSE ? $new_poll_votes : ''NULL'', $new_read_unvote_users !== FALSE ? $new_read_unvote_users : ''0'', $new_revote !== FALSE ? $new_revote : ''0'');\n						} else {\n							Pun_poll::update_poll($cur_post[''tid''], $new_poll_question, $new_poll_answers, $new_poll_days !== FALSE ? $new_poll_days : null, $new_poll_votes !== FALSE ? $new_poll_votes : null, $new_read_unvote_users !== FALSE ? $new_read_unvote_users : ''0'', $new_revote !== FALSE ? $new_revote : ''0'', $poll_question, $poll_answers, $poll_days_count, $poll_votes_count, $poll_read_unvote_users, $poll_revote);\n						}\n					}\n\n				}\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_preview_pre_display', 'pun_poll', 'if ((($forum_user[''group_id''] == FORUM_ADMIN && $can_edit_subject) || ($can_edit_subject && !$topic_poll)) && empty($errors)) {\n				if (!empty($new_poll_question) && !empty($new_poll_answers)) {\n					$forum_page[''preview_message''] .= Pun_poll::poll_preview($new_poll_question, $new_poll_answers);\n				}\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_main_fieldset_end', 'pun_poll', 'if ($can_edit_subject && ($forum_user[''group_id''] == FORUM_ADMIN || $forum_user[''g_poll_add'']))\n			{\n				//Is there something?\n				if ($topic_poll) {\n					if ($forum_user[''group_id''] == FORUM_ADMIN) {\n						Pun_poll::show_form(isset($new_poll_question) ? $new_poll_question : $poll_question, isset($new_poll_answers) ? $new_poll_answers : $poll_answers, isset($new_poll_ans_count) ? $new_poll_ans_count : (isset($new_poll_answers) ? count($new_poll_answers) : count($poll_answers)), isset($new_poll_days) ? $new_poll_days : $poll_days_count, isset($new_poll_votes) ? $new_poll_votes : $poll_votes_count, isset($new_read_unvote_users) ? $new_read_unvote_users : $poll_read_unvote_users, isset($new_revote) ? $new_revote : $poll_revote, true);\n					}\n				} else {\n					Pun_poll::show_form(isset($new_poll_question) ? $new_poll_question : '''', isset($new_poll_answers) ? $new_poll_answers : '''', isset($new_poll_ans_count) ? $new_poll_ans_count : (isset($new_poll_answers) ? (count($new_poll_answers) > 2 ? count($new_poll_answers) : 2) : 2), isset($new_poll_days) ? $new_poll_days : FALSE, isset($new_poll_votes) ? $new_poll_votes : FALSE, $forum_config[''p_pun_poll_enable_read''] ? (isset($new_read_unvote_users) ? $new_read_unvote_users : ''0'') : FALSE, $forum_config[''p_pun_poll_enable_revote''] ? (isset($new_revote) ? $new_revote : ''0'') : FALSE);\n				}\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('po_form_submitted', 'pun_poll', 'if ($fid && ($forum_user[''group_id''] == FORUM_ADMIN || $forum_user[''g_poll_add'']))\n			{\n				$poll_question = isset($_POST[''question_of_poll'']) && !empty($_POST[''question_of_poll'']) ? $_POST[''question_of_poll''] : FALSE;\n				if (!empty($poll_question))\n				{\n					$poll_answers = isset($_POST[''poll_answer'']) && !empty($_POST[''poll_answer'']) ? $_POST[''poll_answer''] : FALSE;\n					$poll_days = isset($_POST[''allow_poll_days'']) && !empty($_POST[''allow_poll_days'']) ? $_POST[''allow_poll_days''] : FALSE;\n					$poll_votes = isset($_POST[''allow_poll_votes'']) && !empty($_POST[''allow_poll_votes'']) ? $_POST[''allow_poll_votes''] : FALSE;\n					$poll_read_unvote_users = isset($_POST[''read_unvote_users'']) && !empty($_POST[''read_unvote_users'']) ? $_POST[''read_unvote_users''] : FALSE;\n					$poll_revote = isset($_POST[''revouting'']) && !empty($_POST[''revouting'']) ? $_POST[''revouting''] : FALSE;\n\n					Pun_poll::data_validation($poll_question, $poll_answers, $poll_days, $poll_votes, $poll_read_unvote_users, $poll_revote);\n				}\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('po_end_validation', 'pun_poll', 'if ($fid && isset($_POST[''update_poll'']) && empty($errors))	{\n				$new_poll_ans_count = isset($_POST[''poll_ans_count'']) && intval($_POST[''poll_ans_count'']) > 0 ? intval($_POST[''poll_ans_count'']) : FALSE;\n\n				if (!$new_poll_ans_count)\n					$errors[] = $lang_pun_poll[''Empty option count''];\n\n				if ($new_poll_ans_count < 2)\n				{\n					$errors[] = $lang_pun_poll[''Min cnt options''];\n					$new_poll_ans_count = 2;\n				}\n\n				if ($new_poll_ans_count > $forum_config[''p_pun_poll_max_answers''])\n				{\n					$errors[] = sprintf($lang_pun_poll[''Max cnt options''], $forum_config[''p_pun_poll_max_answers'']);\n					$new_poll_ans_count = $forum_config[''p_pun_poll_max_answers''];\n				}\n\n				$_POST[''preview''] = ''pun_poll'';\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('po_pre_header_load', 'pun_poll', 'if ($fid && isset($_POST[''update_poll'']) && isset($_POST[''preview'']) && $_POST[''preview''] == ''pun_poll'') {\n				unset($_POST[''preview'']);\n			}\n\n			//\n			$forum_page[''hidden_fields''][''pun_poll_block_status''] = ''<input type="hidden" name="pun_poll_block_open" id="pun_poll_block_status" value="0" />'';', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('po_pre_redirect', 'pun_poll', 'if ($fid && ($forum_user[''group_id''] == FORUM_ADMIN || $forum_user[''g_poll_add'']) && $poll_question !== FALSE && empty($errors))\n			{\n				Pun_poll::add_poll($new_tid, $poll_question, $poll_answers, $poll_days !== FALSE ? $poll_days : ''NULL'', $poll_votes !== FALSE ? $poll_votes : ''NULL'', $poll_read_unvote_users === FALSE  ? ''0'' : $poll_read_unvote_users, $poll_revote === FALSE ? ''0'' : $poll_revote);\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('po_preview_pre_display', 'pun_poll', 'if ($fid && ($forum_user[''group_id''] == FORUM_ADMIN || $forum_user[''g_poll_add'']) && $poll_question !== FALSE && empty($errors)) {\n				$forum_page[''preview_message''] .= Pun_poll::poll_preview($poll_question, $poll_answers);\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('po_req_info_fieldset_end', 'pun_poll', 'if ($fid && ($forum_user[''group_id''] == FORUM_ADMIN || $forum_user[''g_poll_add'']))\n			{\n				$_poll_question = isset($poll_question) ? $poll_question : '''';\n				$_poll_answers = isset($poll_answers) ? $poll_answers : array();\n				$_poll_answers_num = isset($new_poll_ans_count) ? $new_poll_ans_count : ((isset($poll_answers) && count($poll_answers) > 1) ? count($poll_answers) : 2);\n\n				Pun_poll::show_form($_poll_question, $_poll_answers, $_poll_answers_num, !empty($poll_days) ? $poll_days : '''', !empty($poll_votes) ? $poll_votes : '''', isset($poll_read_unvote_users) ? $poll_read_unvote_users : ''0'', isset($poll_revote) ? $poll_revote : ''0'');\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('ca_fn_prune_qr_prune_topics', 'pun_poll', '$pun_poll_topic_ids = isset($topic_ids) ? $topic_ids : implode('','', $topics);\n			$query_poll = array(\n				''DELETE''	=>	''voting'',\n				''WHERE''		=>	''topic_id IN(''.$pun_poll_topic_ids.'')''\n			);\n			$forum_db->query_build($query_poll) or error(__FILE__, __LINE__);\n\n			$query_poll = array(\n				''DELETE''	=>	''questions'',\n				''WHERE''		=>	''topic_id IN(''.$pun_poll_topic_ids.'')''\n			);\n			$forum_db->query_build($query_poll) or error(__FILE__, __LINE__);\n\n			$query_poll = array(\n				''DELETE''	=>	''answers'',\n				''WHERE''		=>	''topic_id IN(''.$pun_poll_topic_ids.'')''\n			);\n			$forum_db->query_build($query_poll) or error(__FILE__, __LINE__);\n			unset($pun_poll_topic_ids);', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('mr_confirm_delete_topics_qr_delete_topics', 'pun_poll', '$pun_poll_topic_ids = isset($topic_ids) ? $topic_ids : implode('','', $topics);\n			$query_poll = array(\n				''DELETE''	=>	''voting'',\n				''WHERE''		=>	''topic_id IN(''.$pun_poll_topic_ids.'')''\n			);\n			$forum_db->query_build($query_poll) or error(__FILE__, __LINE__);\n\n			$query_poll = array(\n				''DELETE''	=>	''questions'',\n				''WHERE''		=>	''topic_id IN(''.$pun_poll_topic_ids.'')''\n			);\n			$forum_db->query_build($query_poll) or error(__FILE__, __LINE__);\n\n			$query_poll = array(\n				''DELETE''	=>	''answers'',\n				''WHERE''		=>	''topic_id IN(''.$pun_poll_topic_ids.'')''\n			);\n			$forum_db->query_build($query_poll) or error(__FILE__, __LINE__);\n			unset($pun_poll_topic_ids);', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('fn_delete_topic_qr_delete_topic', 'pun_poll', 'include_once $ext_info[''path''].''/functions.php'';\n\n			Pun_poll::remove_poll($topic_id);', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('mr_qr_get_forum_data', 'pun_poll', 'if (isset($_POST[''merge_topics'']) || isset($_POST[''merge_topics_comply'']))\n			{\n				$poll_topics = isset($_POST[''topics'']) && !empty($_POST[''topics'']) ? $_POST[''topics''] : array();\n				$poll_topics = array_map(''intval'', (is_array($poll_topics) ? $poll_topics : explode('','', $poll_topics)));\n\n				if (empty($poll_topics))\n					message($lang_misc[''No topics selected'']);\n\n				if (count($poll_topics) == 1)\n					message($lang_misc[''Merge error'']);\n\n				$query_poll = array(\n					''SELECT''	=>	''topic_id'',\n					''FROM''		=>	''questions'',\n					''WHERE''		=>	''topic_id IN(''.implode('','', $poll_topics).'')''\n				);\n				$result_pun_poll = $forum_db->query_build($query_poll) or error(__FILE__, __LINE__);\n\n				$polls = array();\n				while ($row = $forum_db->fetch_assoc($result_pun_poll)) {\n					$polls[] = $row[''topic_id''];\n				}\n\n				if (count($polls) > 1) {\n					if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n						include_once $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n					else\n						include_once $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n\n					message($lang_pun_poll[''Merge error'']);\n				} else if (count($polls) === 1) {\n					$question_id = $polls[0];\n				}\n\n				unset($num_polls, $polls);\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('mr_confirm_merge_topics_pre_redirect', 'pun_poll', 'if (isset($question_id) && $question_id != $merge_to_tid)\n			{\n				$query_poll = array(\n					''UPDATE''	=>	''questions'',\n					''SET''		=>	''topic_id = ''.$merge_to_tid,\n					''WHERE''		=>	''topic_id = ''.$question_id\n				);\n				$forum_db->query_build($query) or error(__FILE__, __LINE__);\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('vt_modify_topic_info', 'pun_poll', 'if (!$forum_user[''is_guest'']) {\n				//Get info about poll\n				$query_pun_poll = array(\n					''SELECT''	=>	''question, read_unvote_users, revote, created, days_count, votes_count AS max_votes_count'',\n					''FROM''		=>	''questions'',\n					''WHERE''		=>	''topic_id = ''.$id\n				);\n				$result_pun_poll = $forum_db->query_build($query_pun_poll) or error(__FILE__, __LINE__);\n				$pun_poll = $forum_db->fetch_assoc($result_pun_poll);\n\n				// Is there something?\n				if (!is_null($pun_poll) && $pun_poll !== false) {\n					if ($forum_user[''style''] !== ''Oxygen'' && file_exists($ext_info[''path''].''/css/''.$forum_user[''style''].''/pun_poll.min.css''))\n						$forum_loader->add_css($ext_info[''url''].''/css/''.$forum_user[''style''].''/pun_poll.min.css'', array(''type'' => ''url'', ''media'' => ''screen''));\n					else\n						$forum_loader->add_css($ext_info[''url''].''/css/Oxygen/pun_poll.min.css'', array(''type'' => ''url'', ''media'' => ''screen''));\n\n					// JS\n					$forum_loader->add_js($ext_info[''url''].''/js/pun_poll.min.js'', array(''type'' => ''url'', ''async'' => true));\n\n					$end_voting = false;\n					$pun_poll[''revote''] = ($forum_config[''p_pun_poll_enable_revote''] == ''1'') ? $pun_poll[''revote''] : 0;\n					$pun_poll[''read_unvote_users''] = ($forum_config[''p_pun_poll_enable_read''] == ''1'') ? $pun_poll[''read_unvote_users''] : 0;\n\n					// Check up for condition of end poll\n					if ($pun_poll[''days_count''] != 0 && time() > $pun_poll[''created''] + $pun_poll[''days_count''] * 86400) {\n						$end_voting = true;\n					} else if ($pun_poll[''max_votes_count''] != 0) {\n						// Get count of votes\n						$query_pun_poll = array(\n							''SELECT''	=>	''COUNT(id) AS vote_count'',\n							''FROM''		=>	''voting'',\n							''WHERE''		=>	''topic_id=''.$id\n						);\n						$result_pun_poll = $forum_db->query_build($query_pun_poll) or error(__FILE__, __LINE__);\n						$row = $forum_db->fetch_assoc($result_pun_poll);\n						$vote_count = $row[''vote_count''];\n\n						if ($vote_count >= $pun_poll[''max_votes_count'']) {\n							$end_voting = true;\n						}\n					}\n\n					if ($forum_user[''language''] != ''English'' && file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n						include_once $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n					else\n						include_once $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n\n					// Does user want to vote?\n					if (isset($_POST[''vote''])) {\n						if ($end_voting) {\n							message($lang_pun_poll[''End of vote'']);\n						}\n\n						$answer_id = isset($_POST[''answer'']) ? intval($_POST[''answer'']) : 0;\n						if ($answer_id < 1) {\n							message($lang_common[''Bad request'']);\n						}\n\n						// Is there answer with this id?\n						$query_pun_poll = array(\n							''SELECT''	=>	''COUNT(*)'',\n							''FROM''		=>	''answers'',\n							''WHERE''		=>	''topic_id=''.$id.'' AND id=''.$answer_id\n						);\n						$result_pun_poll = $forum_db->query_build($query_pun_poll) or error(__FILE__, __LINE__);\n						if ($forum_db->result($result_pun_poll) < 1) {\n							message($lang_common[''Bad request'']);\n						}\n\n						// Have user voted?\n						$query_pun_poll = array(\n							''SELECT''	=>	''answer_id'',\n							''FROM''		=>	''voting'',\n							''WHERE''		=>	''topic_id=''.$id.'' AND user_id=''.$forum_user[''id'']\n						);\n						$result_pun_poll = $forum_db->query_build($query_pun_poll) or error(__FILE__, __LINE__);\n						$row = $forum_db->fetch_assoc($result_pun_poll);\n						$old_answer_id = FALSE;\n						if ($row) {\n							$old_answer_id = $row[''answer_id''];\n						}\n\n						// CAN revote?\n						if (!$pun_poll[''revote''] && $old_answer_id !== FALSE) {\n							message($lang_pun_poll[''User vote error'']);\n						}\n\n						// If user have voted we update table,\n						// if not - insert new record\n						if ($pun_poll[''revote''] && $old_answer_id !== FALSE) {\n							// Do we needed to update DB?\n							if ($old_answer_id != $answer_id) {\n								$query_pun_poll = array(\n									''UPDATE''	=>	''voting'',\n									''SET''		=>	''answer_id=''.$answer_id,\n									''WHERE''		=>	''topic_id=''.$id.'' AND user_id=''.$forum_user[''id'']\n								);\n								$forum_db->query_build($query_pun_poll) or error(__FILE__, __LINE__);\n\n								// Replace old answer id with new for correct output\n								$old_answer_id = $answer_id;\n							}\n						} else {\n							// Add new record\n							$query_pun_poll = array(\n								''INSERT''	=>	''topic_id, user_id, answer_id'',\n								''INTO''		=>	''voting'',\n								''VALUES''	=>	$id.'', ''.$forum_user[''id''].'', ''.$answer_id\n							);\n							$forum_db->query_build($query_pun_poll) or error(__FILE__, __LINE__);\n						}\n\n						redirect(forum_link($forum_url[''topic''], array($id, sef_friendly($cur_topic[''subject'']))), $lang_pun_poll[''Poll redirect'']);\n					} else {\n						// Determine user have voted or not\n						$query_pun_poll = array(\n							''SELECT''	=>	''COUNT(*)'',\n							''FROM''		=>	''voting'',\n							''WHERE''		=>	''user_id=''.$forum_user[''id''].'' AND topic_id=''.$id\n						);\n						$result_pun_poll = $forum_db->query_build($query_pun_poll) or error(__FILE__, __LINE__);\n						$is_voted_user = ($forum_db->result($result_pun_poll) > 0) ? true : false;\n					}\n				}\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('vt_pre_header_load', 'pun_poll', '// Is there something to show?\n			if (isset($pun_poll[''read_unvote_users'']) && !$forum_user[''is_guest'']) {\n				// If we don''t get count of votes\n				if (!isset($vote_count)) {\n					$query_pun_poll = array(\n						''SELECT''	=>	''COUNT(*) AS vote_count'',\n						''FROM''		=>	''voting'',\n						''WHERE''		=>	''topic_id=''.$id\n					);\n					$result_pun_poll = $forum_db->query_build($query_pun_poll) or error(__FILE__, __LINE__);\n					$row = $forum_db->fetch_assoc($result_pun_poll);\n					$vote_count = $row[''vote_count''];\n				}\n\n				// Showing of vote-form if users can revote or user don''t vote\n				if (!$end_voting && (($is_voted_user && $pun_poll[''revote'']) || $is_voted_user === false)) {\n					$query_pun_poll = array(\n						''SELECT''	=>	''id, answer'',\n						''FROM''		=>	''answers'',\n						''WHERE''		=>	''topic_id=''.$id,\n						''ORDER BY''	=>	''id ASC''\n					);\n					$result_pun_poll = $forum_db->query_build($query_pun_poll) or error(__FILE__, __LINE__);\n\n					$pun_poll_answers = array();\n					while ($row = $forum_db->fetch_assoc($result_pun_poll)) {\n						$pun_poll_answers[] = $row;\n					}\n\n					if (!empty($pun_poll_answers))\n					{\n						$vote_form = '''';\n						$link = forum_link($forum_url[''topic''], $id);\n\n						$vote_form = ''\n							<div class="pun_poll_item unvotted">\n								<div class="pun_poll_header">''.forum_htmlencode($pun_poll[''question'']).''</div>\n								<div class="main-frm">\n									<form class="frm-form" action="''.$link.''" accept-charset="utf-8" method="post">\n										<fieldset class="frm-group group1">\n											<div class="hidden">\n												<input type="hidden" name="csrf_token" value="''.generate_form_token($link).''" />\n											</div>\n											<fieldset class="mf-set set1">\n												<legend><span>''.$lang_pun_poll[''Options''].''</span></legend>\n												<div class="mf-box">'';\n\n						// Determine old answer of user\n						if (!isset($old_answer_id)) {\n							$query_pun_poll = array(\n								''SELECT''	=>	''answer_id'',\n								''FROM''		=>	''voting'',\n								''WHERE''		=>	''topic_id = ''.$id.'' AND user_id = ''.$forum_user[''id''],\n								''ORDER BY''	=>	''answer_id ASC''\n							);\n							$result_poll = $forum_db->query_build($query_pun_poll) or error(__FILE__, __LINE__);\n\n							// If there is something?\n							$row = $forum_db->fetch_assoc($result_poll);\n							if ($row) {\n								$old_answer_id = $row[''answer_id''];\n							}\n							unset($result_poll);\n						}\n\n\n						$num = 0;\n						foreach ($pun_poll_answers as $answer) {\n							$num++;\n							$vote_form .= ''\n								<div class="mf-item pun_poll_answer_block" data-num="''.$num.''">\n									<span class="fld-input">\n										<input id="fld''.$num.''" type="radio"''.((isset($old_answer_id) && $old_answer_id == $answer[''id'']) ? '' checked="checked"'' : '''').'' value="''.$answer[''id''].''" name="answer" />\n									</span>\n									<label for="fld''.$num.''">''.forum_htmlencode($answer[''answer'']).''</label>\n								</div>'';\n						}\n\n						$vote_form .= ''\n												</div>\n											</fieldset>\n										</fieldset>\n										<div class="frm-buttons">\n											<span class="submit">\n												<input type="submit" value="''.$lang_pun_poll[''But note''].''" name="vote" />\n											</span>\n										</div>\n									</form>\n								</div>\n							</div>'';\n					}\n				}\n\n				// Showing voting results if user have voted or unread user can see voting results\n				if ($end_voting || $is_voted_user || (!$is_voted_user && $pun_poll[''read_unvote_users''])) {\n					if (isset($vote_count) && $vote_count > 0) {\n						$query_pun_poll = array(\n							''SELECT''	=>	''answer, COUNT(v.id) as num_vote'',\n							''FROM''		=>	''answers as a'',\n							''JOINS''		=>	array(\n								array(\n									''LEFT JOIN''	=>	''voting AS v'',\n									''ON''		=>	''a.id=v.answer_id''\n								)\n							),\n							''WHERE''		=>	''a.topic_id=''.$id,\n							''GROUP BY''	=>	''a.id'',\n							''ORDER BY''	=>	''a.id''\n						);\n						$result_pun_poll = $forum_db->query_build($query_pun_poll) or error(__FILE__, __LINE__);\n\n						$vote_results = ''<div class="pun_poll_item votted"><div class="pun_poll_header">''.forum_htmlencode($pun_poll[''question'']).''</div>'';\n						$vote_results_raw = array();\n						$num = $winner_index = $cur_vote_index = 0;\n						$max_vote = $num_winner = 0;\n\n						while ($row = $forum_db->fetch_assoc($result_pun_poll)) {\n							$vote_results_raw[] = $row;\n							if ($row[''num_vote''] > $max_vote) {\n								$max_vote = $row[''num_vote''];\n								$winner_index = $cur_vote_index;\n							}\n\n							$cur_vote_index++;\n						}\n\n						// Case when winner is not one\n						foreach ($vote_results_raw as $vote) {\n							if ($vote[''num_vote''] == $max_vote) {\n								$num_winner++;\n							}\n						}\n\n						if ($num_winner !== 1) {\n							// No winner\n							$winner_index = -1;\n						}\n\n						foreach ($vote_results_raw as $vote) {\n							$pollResultWidth = ((float)/**/$vote[''num_vote''] / $vote_count * 100);\n							$vote_results .= ''\n								<dl>\n									<dt><strong>''.forum_number_format((float)/**/$vote[''num_vote''] / $vote_count * 100).''%</strong><br/>(''.$vote[''num_vote''].'')</dt>\n									<dd>''.forum_htmlencode($vote[''answer''])\n										.''<div class="''.(($winner_index == $num) ? ''winner'' : '''').(($pollResultWidth > 0) ? '''' : '' poll-empty'').''" style="width: ''.$pollResultWidth.''%;"></div>\n									</dd>\n								</dl>'';\n							$num++;\n						}\n\n						$num++;\n						$vote_results .= ''<p class="pun_poll_total">''.$lang_pun_poll[''Users count''].$vote_count.''</p>'';\n						$vote_results .= ''</div>'';\n					} else {\n						$vote_results = ''<div class="ct-box info-box"><p>''.$lang_pun_poll[''No votes''].''</p></div>'';\n					}\n				} else {\n					$vote_results = '' '';\n				}\n\n				unset($tmp_pagepost, $vote_count, $num, $result_pun_poll, $query_pun_poll, $count_v, $answer, $is_voted_user, $end_voting, $pun_poll);\n			}', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('vt_row_pre_display', 'pun_poll', 'if ((isset($vote_results) || isset($vote_form)) && ($cur_post[''id''] == $cur_topic[''first_post_id''])) {\n				$pun_poll_block = '''';\n				if (!empty($vote_form)) {\n					$pun_poll_block	.= $vote_form;\n				}\n				$pun_poll_block	.= $vote_results;\n\n				if (isset($forum_page[''message''][''edited''])) {\n					array_insert($forum_page[''message''], ''edited'', $pun_poll_block, ''pun_poll'');\n				} else if (isset($forum_page[''message''][''signature''])) {\n					array_insert($forum_page[''message''], ''signature'', $pun_poll_block, ''pun_poll'');\n				} else {\n					$forum_page[''message''][''pun_poll''] = $pun_poll_block;\n				}\n			}', 1358395341, 4);
INSERT INTO `x_extension_hooks` VALUES('aop_features_pre_header_load', 'pun_poll', 'if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n				include_once $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n			else\n				include_once $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('aop_features_validation', 'pun_poll', 'if ($forum_user[''language''] != ''English'' && file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n				include_once $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n			else\n				include_once $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n\n\n			if (!isset($form[''pun_poll_enable_read'']) || $form[''pun_poll_enable_read''] != ''1'') $form[''pun_poll_enable_read''] = ''0'';\n			if (!isset($form[''pun_poll_enable_revote'']) || $form[''pun_poll_enable_revote''] != ''1'') $form[''pun_poll_enable_revote''] = ''0'';\n\n			$form[''pun_poll_max_answers''] = intval($form[''pun_poll_max_answers'']);\n\n			if ($form[''pun_poll_max_answers''] > 100)\n				$form[''pun_poll_max_answers''] = 100;\n\n			if ($form[''pun_poll_max_answers''] < 2)\n				$form[''pun_poll_max_answers''] = 2;', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('aop_features_avatars_fieldset_end', 'pun_poll', '?>\n				<div class="content-head">\n					<h2 class="hn"><span><?php echo $lang_pun_poll[''Name plugin''] ?></span></h2>\n				</div>\n				<fieldset class="frm-group group1">\n					<div class="sf-set set<?php echo ++$forum_page[''item_count''] ?>">\n						<div class="sf-box checkbox">\n							<span class="fld-input">\n								<input id="fld<?php echo ++$forum_page[''fld_count''] ?>" type="checkbox" name="form[pun_poll_enable_revote]" value="1"<?php if ($forum_config[''p_pun_poll_enable_revote''] == ''1'') echo '' checked="checked"'' ?>/>\n							</span>\n							<label for="fld<?php echo ++$forum_page[''fld_count''] ?>">\n								<span><?php echo $lang_pun_poll[''Disable revoting info''] ?></span>\n								<?php echo $lang_pun_poll[''Disable revoting''] ?>\n							</label>\n						</div>\n					</div>\n					<div class="sf-set set<?php echo ++$forum_page[''item_count''] ?>">\n						<div class="sf-box checkbox">\n							<span class="fld-input">\n								<input id="fld<?php echo ++$forum_page[''fld_count''] ?>" type="checkbox" name="form[pun_poll_enable_read]" value="1"<?php if ($forum_config[''p_pun_poll_enable_read''] == ''1'') echo '' checked="checked"'' ?>/>\n							</span>\n							<label for="fld<?php echo ++$forum_page[''fld_count''] ?>">\n								<span><?php echo $lang_pun_poll[''Disable see results''] ?></span>\n								<?php echo $lang_pun_poll[''Disable see results info''] ?>\n							</label>\n						</div>\n					</div>\n					<div class="sf-set set<?php echo ++$forum_page[''item_count''] ?>">\n						<div class="sf-box text">\n							<label for="fld<?php echo ++$forum_page[''fld_count''] ?>">\n								<span><?php echo $lang_pun_poll[''Maximum answers info''] ?></span>\n								<small><?php echo $lang_pun_poll[''Maximum answers''] ?></small>\n							</label>\n							</br>\n							<span class="fld-input">\n								<input id="fld<?php echo $forum_page[''fld_count''] ?>" type="text" name="form[pun_poll_max_answers]" size="6" maxlength="6" value="<?php echo $forum_config[''p_pun_poll_max_answers''] ?>"/>\n							</span>\n						</div>\n					</div>\n				</fieldset>\n			<?php', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('agr_edit_end_qr_update_group', 'pun_poll', '$query[''SET''] .= '', g_poll_add=''.((isset($_POST[''poll_add'']) && $_POST[''poll_add''] == ''1'') ? 1 : 0);', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('agr_add_edit_group_user_permissions_fieldset_end', 'pun_poll', 'if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n				include_once $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n			else\n				include_once $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n			?>\n				<fieldset class="mf-set set<?php echo ++$forum_page[''item_count''] ?>">\n					<legend>\n						<span><?php echo $lang_pun_poll[''Permission''] ?></span>\n					</legend>\n					<div class="mf-box">\n						<div class="mf-item">\n							<span class="fld-input">\n								<input type="checkbox" id="fld<?php echo ++$forum_page[''fld_count''] ?>" name="poll_add" value="1"<?php if ($group[''g_poll_add''] == ''1'') echo '' checked="checked"'' ?>/>\n							</span>\n							<label for="fld<?php echo $forum_page[''fld_count''] ?>"><?php echo $lang_pun_poll[''Poll add''] ?></label>\n						</div>\n					</div>\n				</fieldset>\n			<?php', 1358395341, 5);
INSERT INTO `x_extension_hooks` VALUES('agr_start', 'pun_attachment', 'require $ext_info[''path''].''/include/attach_func.php'';\n			if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n				require $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n			else\n				require $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('agr_add_edit_group_flood_fieldset_end', 'pun_attachment', '?>\n\n	<div class="content-head">\n		<h3 class="hn"><span><?php echo $lang_attach[''Group attach part''] ?></span></h3>\n	</div>\n	<fieldset class="mf-set set<?php echo ++$forum_page[''item_count''] ?>">\n		<legend><span><?php echo $lang_attach[''Attachment rules''] ?></span></legend>\n		<div class="mf-box">\n			<div class="mf-item">\n				<span class="fld-input"><input type="checkbox" id="fld<?php echo ++$forum_page[''fld_count''] ?>" name="download" value="1"<?php if ($group[''g_pun_attachment_allow_download''] == ''1'') echo '' checked="checked"'' ?> /></span>\n				<label for="fld<?php echo $forum_page[''fld_count''] ?>"><?php echo $lang_attach[''Download'']?></label>\n			</div>\n			<div class="mf-item">\n				<span class="fld-input"><input type="checkbox" id="fld<?php echo ++$forum_page[''fld_count''] ?>" name="upload" value="1"<?php if ($group[''g_pun_attachment_allow_upload''] == ''1'') echo '' checked="checked"'' ?> /></span>\n				<label for="fld<?php echo $forum_page[''fld_count''] ?>"><?php echo $lang_attach[''Upload''] ?></label>\n			</div>\n			<div class="mf-item">\n				<span class="fld-input"><input type="checkbox" id="fld<?php echo ++$forum_page[''fld_count''] ?>" name="delete" value="1"<?php if ($group[''g_pun_attachment_allow_delete''] == ''1'') echo '' checked="checked"'' ?> /></span>\n				<label for="fld<?php echo $forum_page[''fld_count''] ?>"><?php echo $lang_attach[''Delete''] ?></label>\n			</div>\n			<div class="mf-item">\n				<span class="fld-input"><input type="checkbox" id="fld<?php echo ++$forum_page[''fld_count''] ?>" name="owner_delete" value="1"<?php if ($group[''g_pun_attachment_allow_delete_own''] == ''1'') echo '' checked="checked"'' ?> /></span>\n				<label for="fld<?php echo $forum_page[''fld_count''] ?>"><?php echo $lang_attach[''Owner delete''] ?></label>\n			</div>\n		</div>\n	</fieldset>\n	<div class="sf-set set<?php echo ++$forum_page[''item_count''] ?>">\n		<div class="sf-box text">\n			<label for="fld<?php echo ++$forum_page[''fld_count''] ?>"><span><?php echo $lang_attach[''Size''] ?></span> <small><?php echo $lang_attach[''Size comment''] ?></small></label><br />\n			<span class="fld-input"><input type="text" id="fld<?php echo $forum_page[''fld_count''] ?>" name="max_size" size="15" maxlength="15" value="<?php echo $group[''g_pun_attachment_upload_max_size''] ?>" /></span>\n		</div>\n		<div class="sf-box text">\n			<label for="fld<?php echo ++$forum_page[''fld_count''] ?>"><span><?php echo $lang_attach[''Per post''] ?></span></label><br />\n			<span class="fld-input"><input type="text" id="fld<?php echo $forum_page[''fld_count''] ?>" name="per_post" size="4" maxlength="5" value="<?php echo $group[''g_pun_attachment_files_per_post''] ?>" /></span>\n		</div>\n		<div class="sf-box text">\n			<label for="fld<?php echo ++$forum_page[''fld_count''] ?>"><span><?php echo $lang_attach[''Allowed files''] ?></span><small><?php echo $lang_attach[''Allowed comment''] ?></small></label><br />\n			<span class="fld-input"><input type="text" id="fld<?php echo $forum_page[''fld_count''] ?>" name="file_ext" size="80" maxlength="80" value="<?php echo $group[''g_pun_attachment_disallowed_extensions''] ?>" /></span>\n		</div>\n	</div>\n\n<?php', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('agr_add_edit_end_validation', 'pun_attachment', '$group_id = isset($_POST[''group_id'']) ? intval($_POST[''group_id'']) : '''';\n			if ($_POST[''mode''] == ''add'' || (!empty($group_id) && $group_id != FORUM_ADMIN))\n			{\n				$allow_down = isset($_POST[''download'']) && $_POST[''download''] == ''1'' ? ''1'' : ''0'';\n				$allow_upl = isset($_POST[''upload'']) && $_POST[''upload''] == ''1'' ? ''1'' : ''0'';\n				$allow_del = isset($_POST[''delete'']) && $_POST[''delete''] == ''1'' ? ''1'' : ''0'';\n				$allow_del_own = isset($_POST[''owner_delete'']) && $_POST[''owner_delete''] == ''1'' ? ''1'' : ''0'';\n\n				$size = isset($_POST[''max_size'']) ? intval($_POST[''max_size'']) : ''0'';\n				$upload_max_filesize = get_bytes(ini_get(''upload_max_filesize''));\n				$post_max_size = get_bytes(ini_get(''post_max_size''));\n				if ($size > $upload_max_filesize ||  $size > $post_max_size)\n					$size = min($upload_max_filesize, $post_max_size);\n\n				$per_post = isset($_POST[''per_post'']) ? intval($_POST[''per_post'']) : ''1'';\n				$file_ext = isset($_POST[''file_ext'']) ? trim($_POST[''file_ext'']) : '''';\n\n				if (!empty($file_ext))\n				{\n					$file_ext = preg_replace(''/\\s/'', '''', $file_ext);\n					$match = preg_match(''/(^[a-zA-Z0-9])+(([a-zA-Z0-9]+\\,)|([a-zA-Z0-9]))+([a-zA-Z0-9]+$)/'', $file_ext);\n\n					if (!$match)\n						message($lang_attach[''Wrong allowed'']);\n				}\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('agr_add_end_qr_add_group', 'pun_attachment', '$query[''INSERT''] .= '', g_pun_attachment_allow_download, g_pun_attachment_allow_upload, g_pun_attachment_allow_delete, g_pun_attachment_allow_delete_own, g_pun_attachment_upload_max_size, g_pun_attachment_files_per_post, g_pun_attachment_disallowed_extensions'';\n			$query[''VALUES''] .= '', ''.implode('','', array($allow_down, $allow_upl, $allow_del, $allow_del_own, $size, $per_post, ''\\''''.$forum_db->escape($file_ext).''\\''''));', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('agr_edit_end_qr_update_group', 'pun_attachment', 'if (isset($allow_down))\n				$query[''SET''] .= '', g_pun_attachment_allow_download = ''.$allow_down.'', g_pun_attachment_allow_upload = ''.$allow_upl.'', g_pun_attachment_allow_delete = ''.$allow_del.'', g_pun_attachment_allow_delete_own = ''.$allow_del_own.'', g_pun_attachment_upload_max_size = ''.$size.'', g_pun_attachment_files_per_post = ''.$per_post.'', g_pun_attachment_disallowed_extensions = \\''''.$forum_db->escape($file_ext).''\\'''';', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('hd_head', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''] && in_array(FORUM_PAGE, array(''viewtopic'', ''postedit'', ''attachment-preview'')))\n			{\n				if ($forum_user[''style''] != ''Oxygen'' && is_dir($ext_info[''path''].''/css/''.$forum_user[''style'']))\n					$forum_loader->add_css($ext_info[''url''].''/css/''.$forum_user[''style''].''/pun_attachment.min.css'', array(''type'' => ''url''));\n				else\n					$forum_loader->add_css($ext_info[''url''].''/css/Oxygen/pun_attachment.min.css'', array(''type'' => ''url''));\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('po_start', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				require $ext_info[''path''].''/include/attach_func.php'';\n				if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n					require $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n				else\n					require $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n				require $ext_info[''path''].''/url.php'';\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('po_qr_get_topic_forum_info', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$query[''SELECT''] .= '', g_pun_attachment_allow_upload, g_pun_attachment_upload_max_size, g_pun_attachment_files_per_post, g_pun_attachment_disallowed_extensions, g_pun_attachment_allow_delete_own'';\n				$query[''JOINS''][] = array(''LEFT JOIN'' => ''groups AS g'', ''ON'' => ''g.g_id = ''.$forum_user[''g_id'']);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('po_qr_get_forum_info', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$query[''SELECT''] .= '', g_pun_attachment_allow_upload, g_pun_attachment_upload_max_size, g_pun_attachment_files_per_post, g_pun_attachment_disallowed_extensions, g_pun_attachment_allow_delete_own'';\n				$query[''JOINS''][] = array(''LEFT JOIN'' => ''groups AS g'', ''ON'' => ''g.g_id = ''.$forum_user[''g_id'']);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('po_form_submitted', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$attach_secure_str = $forum_user[''id''].($tid ? ''t''.$tid : ''f''.$fid);\n				$attach_query = array(\n					''SELECT''	=>	''id, owner_id, post_id, topic_id, filename, file_ext, file_mime_type, file_path, size, download_counter, uploaded_at, secure_str'',\n					''FROM''		=>	''attach_files'',\n					''WHERE''		=>	''secure_str = \\''''.$forum_db->escape($attach_secure_str).''\\''''\n				);\n\n				$attach_result = $forum_db->query_build($attach_query) or error(__FILE__, __LINE__);\n\n				$uploaded_list = array();\n				while ($cur_attach = $forum_db->fetch_assoc($attach_result))\n				{\n					$uploaded_list[] = $cur_attach;\n				}\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('po_end_validation', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				foreach (array_keys($_POST) as $key)\n				{\n					if (preg_match(''~delete_(\\d+)~'', $key, $matches))\n					{\n						$attach_delete_id = $matches[1];\n						break;\n					}\n				}\n\n				if (isset($attach_delete_id))\n				{\n					foreach ($uploaded_list as $attach_index => $attach)\n					{\n						if ($attach[''id''] == $attach_delete_id)\n						{\n							$delete_attach = $attach;\n							$attach_delete_index = $attach_index;\n							break;\n						}\n					}\n\n					if (isset($delete_attach) && ($forum_user[''g_id''] == FORUM_ADMIN || $cur_posting[''g_pun_attachment_allow_delete_own'']))\n					{\n						$attach_query = array(\n							''DELETE''	=>	''attach_files'',\n							''WHERE''		=>	''id = ''.$delete_attach[''id'']\n						);\n						$forum_db->query_build($attach_query) or error(__FILE__, __LINE__);\n						unset($uploaded_list[$attach_delete_index]);\n						if ($forum_config[''attach_create_orphans''] == ''0'')\n							unlink($forum_config[''attach_basefolder''].$delete_attach[''file_path'']);\n					}\n					else\n						$errors[] = $lang_attach[''Del perm error''];\n\n					$_POST[''preview''] = 1;\n				}\n				else if (isset($_POST[''add_file'']))\n				{\n					attach_create_attachment($attach_secure_str, $cur_posting);\n					$_POST[''preview''] = 1;\n				}\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('po_pre_redirect', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''] && isset($_POST[''submit_button'']))\n			{\n				$attach_query = array(\n					''UPDATE''	=>	''attach_files'',\n					''SET''		=>	''owner_id = ''.$forum_user[''id''].'', topic_id = ''.(isset($new_tid) ? $new_tid : $tid).'', post_id = ''.$new_pid.'', secure_str = NULL'',\n					''WHERE''		=>	''secure_str = \\''''.$forum_db->escape($attach_secure_str).''\\''''\n				);\n				$forum_db->query_build($attach_query) or error(__FILE__, __LINE__);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('po_pre_header_load', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n				$forum_page[''form_attributes''][''enctype''] = ''enctype="multipart/form-data"'';', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('po_pre_req_info_fieldset_end', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n				show_attachments(isset($uploaded_list) ? $uploaded_list : array(), $cur_posting);', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('vt_start', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				require $ext_info[''path''].''/include/attach_func.php'';\n				if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n					require $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n				else\n					require $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n				require $ext_info[''path''].''/url.php'';\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('vt_qr_get_topic_info', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$query[''SELECT''] .= '', g_pun_attachment_allow_download'';\n				$query[''JOINS''][] = array(''LEFT JOIN'' => ''groups AS g'', ''ON'' => ''g.g_id = ''.$forum_user[''g_id'']);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('vt_main_output_start', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$attach_query = array(\n					''SELECT''	=>	''id, post_id, filename, file_ext, file_mime_type, size, download_counter, uploaded_at, file_path'',\n					''FROM''		=>	''attach_files'',\n					''WHERE''		=>	''topic_id = ''.$id,\n					''ORDER BY''	=>	''filename''\n				);\n				$attach_result = $forum_db->query_build($attach_query) or error(__FILE__, __LINE__);\n				$attach_list = array();\n				while ($cur_attach = $forum_db->fetch_assoc($attach_result))\n				{\n					if (!isset($attach_list[$cur_attach[''post_id'']]))\n						$attach_list[$cur_attach[''post_id'']] = array();\n					$attach_list[$cur_attach[''post_id'']][] = $cur_attach;\n				}\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('vt_row_pre_display', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''] && isset($attach_list[$cur_post[''id'']]))\n			{\n				if (isset($forum_page[''message''][''signature'']))\n					$forum_page[''message''][''signature''] = show_attachments_post($attach_list[$cur_post[''id'']], $cur_post[''id''], $cur_topic).$forum_page[''message''][''signature''];\n				else\n					$forum_page[''message''][''attachments''] = show_attachments_post($attach_list[$cur_post[''id'']], $cur_post[''id''], $cur_topic);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_start', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				require $ext_info[''path''].''/include/attach_func.php'';\n				if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n					require $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n				else\n					require $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n				require $ext_info[''path''].''/url.php'';\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_qr_get_post_info', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$query[''SELECT''] .= '', g_pun_attachment_allow_upload, g_pun_attachment_upload_max_size, g_pun_attachment_files_per_post, g_pun_attachment_disallowed_extensions, g_pun_attachment_allow_delete_own, g_pun_attachment_allow_delete'';\n				$query[''JOINS''][] = array(''LEFT JOIN'' => ''groups AS g'', ''ON'' => ''g.g_id = ''.$forum_user[''g_id'']);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_post_selected', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$attach_secure_str = $forum_user[''id''].''t''.$cur_post[''tid''];\n\n				$attach_query = array(\n					''SELECT''	=>	''id, owner_id, post_id, topic_id, filename, file_ext, file_mime_type, file_path, size, download_counter, uploaded_at, secure_str'',\n					''FROM''		=>	''attach_files'',\n					''WHERE''		=>	''post_id = ''.$id.'' OR secure_str = \\''''.$attach_secure_str.''\\'''',\n					''ORDER BY''	=>	''filename''\n				);\n\n				$attach_result = $forum_db->query_build($attach_query) or error(__FILE__, __LINE__);\n\n				$uploaded_list = array();\n				while ($cur_attach = $forum_db->fetch_assoc($attach_result))\n					$uploaded_list[] = $cur_attach;\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_end_validation', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				foreach (array_keys($_POST) as $key)\n				{\n					if (preg_match(''~delete_(\\d+)~'', $key, $matches))\n					{\n						$attach_delete_id = $matches[1];\n						break;\n					}\n				}\n				if (isset($attach_delete_id))\n				{\n					foreach ($uploaded_list as $attach_index => $attach)\n						if ($attach[''id''] == $attach_delete_id)\n						{\n							$delete_attach = $attach;\n							$attach_delete_index = $attach_index;\n							break;\n						}\n					if (isset($delete_attach) && ($forum_user[''g_id''] == FORUM_ADMIN || $cur_post[''g_pun_attachment_allow_delete''] || ($cur_post[''g_pun_attachment_allow_delete_own''] && $forum_user[''id''] == $delete_attach[''owner_id''])))\n					{\n						$attach_query = array(\n							''DELETE''	=>	''attach_files'',\n							''WHERE''		=>	''id = ''.$delete_attach[''id'']\n						);\n						$forum_db->query_build($attach_query) or error(__FILE__, __LINE__);\n						unset($uploaded_list[$attach_delete_index]);\n						if ($forum_config[''attach_create_orphans''] == ''0'')\n							unlink($forum_config[''attach_basefolder''].$delete_attach[''file_path'']);\n					}\n					else\n						$errors[] = $lang_attach[''Del perm error''];\n					$_POST[''preview''] = 1;\n				}\n				else if (isset($_POST[''add_file'']))\n				{\n					attach_create_attachment($attach_secure_str, $cur_post);\n					$_POST[''preview''] = 1;\n				}\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_pre_redirect', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''] && isset($_POST[''submit_button'']))\n			{\n				$attach_query = array(\n					''UPDATE''	=>	''attach_files'',\n					''SET''		=>	''owner_id = ''.$forum_user[''id''].'', topic_id = ''.$cur_post[''tid''].'', post_id = ''.$id.'', secure_str = NULL'',\n					''WHERE''		=>	''secure_str = \\''''.$forum_db->escape($attach_secure_str).''\\''''\n				);\n				$forum_db->query_build($attach_query) or error(__FILE__, __LINE__);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_pre_header_load', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n				$forum_page[''form_attributes''][''enctype''] = ''enctype="multipart/form-data"'';', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('ed_pre_main_fieldset_end', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n				show_attachments(isset($uploaded_list) ? $uploaded_list : array(), $cur_post);', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('aop_start', 'pun_attachment', 'require $ext_info[''path''].''/include/attach_func.php'';\n			if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n				require $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n			else\n				require $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n			require $ext_info[''path''].''/url.php'';\n\n			$section = isset($_GET[''section'']) ? $_GET[''section''] : null;\n\n			if (isset($_POST[''apply'']) && ($section == ''list_attach'') && isset($_POST[''form_sent'']))\n				unset($_POST[''form_sent'']);', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('aop_new_section', 'pun_attachment', 'if ($section == ''pun_attach'')\n				require $ext_info[''path''].''/pun_attach.php'';\n			else if ($section == ''pun_list_attach'')\n				require $ext_info[''path''].''/pun_list_attach.php'';', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('ca_fn_generate_admin_menu_new_sublink', 'pun_attachment', 'require $ext_info[''path''].''/url.php'';\n			if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n				require $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n			else\n				require $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n\n			if ((FORUM_PAGE_SECTION == ''management'') && ($forum_user[''g_id''] == FORUM_ADMIN))\n				$forum_page[''admin_submenu''][''pun_attachment_management''] = ''<li class="''.((FORUM_PAGE == ''admin-attachment-manage'') ? ''active'' : ''normal'').((empty($forum_page[''admin_menu''])) ? '' first-item'' : '''').''"><a href="''.forum_link($attach_url[''admin_attachment_manage'']).''">''.$lang_attach[''Attachment''].''</a></li>'';\n			if ((FORUM_PAGE_SECTION == ''settings'') && ($forum_user[''g_id''] == FORUM_ADMIN))\n				$forum_page[''admin_submenu''][''pun_attachment_settings''] = ''<li class="''.((FORUM_PAGE == ''admin-options-attach'') ? ''active'' : ''normal'').((empty($forum_page[''admin_menu''])) ? '' first-item'' : '''').''"><a href="''.forum_link($attach_url[''admin_options_attach'']).''">''.$lang_attach[''Attachment''].''</a></li>'';', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('aop_pre_update_configuration', 'pun_attachment', 'if ($section == ''pun_attach'')\n			{\n				while (list($key, $input) = @each($form))\n				{\n					if ($forum_config[''attach_''.$key] != $input)\n					{\n						if ($input != '''' || is_int($input))\n							$value = ''\\''''.$forum_db->escape($input).''\\'''';\n						else\n							$value = ''NULL'';\n\n						$query = array(\n							''UPDATE''	=> ''config'',\n							''SET''		=> ''conf_value=''.$value,\n							''WHERE''		=> ''conf_name=\\''attach_''.$key.''\\''''\n						);\n\n						$forum_db->query_build($query) or error(__FILE__,__LINE__);\n					}\n				}\n\n				require_once FORUM_ROOT.''include/cache.php'';\n				generate_config_cache();\n\n				redirect(forum_link($attach_url[''admin_options_attach'']), $lang_admin_settings[''Settings updated''].'' ''.$lang_admin_common[''Redirect'']);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('aop_pre_redirect', 'pun_attachment', 'if ($section == ''pun_attach'')\n			{\n				redirect(forum_link($attach_url[''admin_options_attach'']), $lang_admin_settings[''Settings updated''].'' ''.$lang_admin_common[''Redirect'']);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('aop_new_section_validation', 'pun_attachment', 'if ($section == ''pun_attach'')\n{\n	if (!isset($form[''use_icon'']) || $form[''use_icon''] != ''1'') $form[''use_icon''] = ''0'';\n	if (!isset($form[''create_orphans'']) || $form[''create_orphans''] != ''1'') $form[''create_orphans''] = ''0'';\n	if (!isset($form[''disable_attach'']) || $form[''disable_attach''] != ''1'') $form[''disable_attach''] = ''0'';\n	if (!isset($form[''disp_small'']) || $form[''disp_small''] != ''1'') $form[''disp_small''] = ''0'';\n\n	if ($form[''always_deny''])\n	{\n		$form[''always_deny''] = preg_replace(''/\\s/'','''',$form[''always_deny'']);\n		$match = preg_match(''/(^[a-zA-Z0-9])+(([a-zA-Z0-9]+\\,)|([a-zA-Z0-9]))+([a-zA-Z0-9]+$)/'',$form[''always_deny'']);\n\n		if (!$match)\n			message($lang_attach[''Wrong deny'']);\n	}\n\n	if (preg_match(''/^[0-9]+$/'', $form[''small_height'']))\n		$form[''small_height''] = intval($form[''small_height'']);\n	else\n		$form[''small_height''] = $forum_config[''attach_small_height''];\n\n	if (preg_match(''/^[0-9]+$/'',$form[''small_width'']))\n		$form[''small_width''] = intval($form[''small_width'']);\n	else\n		$form[''small_width''] = $forum_config[''attach_small_width''];\n\n	$names = explode('','', $forum_config[''attach_icon_name'']);\n	$icons = explode('','', $forum_config[''attach_icon_extension'']);\n\n	$num_icons = count($icons);\n	for ($i = 0; $i < $num_icons; $i++)\n	{\n		if (!empty($_POST[''attach_ext_''.$i]) && !empty($_POST[''attach_ico_''.$i]))\n		{\n			if (!preg_match("/^[a-zA-Z0-9]+$/", forum_trim($_POST[''attach_ext_''.$i])) && !preg_match("/^([a-zA-Z0-9]+\\.+(png|gif|jpeg|jpg|ico))+$/", forum_trim($_POST[''attach_ico_''.$i])))\n				message($lang_attach[''Wrong icon/name'']);\n\n			$icons[$i] = trim($_POST[''attach_ext_''.$i]);\n			$names[$i] = trim($_POST[''attach_ico_''.$i]);\n		}\n	}\n\n	if (isset($_POST[''add_field_icon'']) && isset($_POST[''add_field_file'']))\n	{\n		if (!empty($_POST[''add_field_icon'']) && !empty($_POST[''add_field_file'']))\n		{\n			if (!(preg_match("/^[a-zA-Z0-9]+$/",trim($_POST[''add_field_icon''])) && preg_match("/^([a-zA-Z0-9]+\\.+(png|gif|jpeg|jpg|ico))+$/",trim($_POST[''add_field_file'']))))\n				message ($lang_attach[''Wrong icon/name'']);\n\n			$icons[] = trim($_POST[''add_field_icon'']);\n			$names[] = trim($_POST[''add_field_file'']);\n		}\n	}\n\n	$icons = implode('','', $icons);\n	$icons = preg_replace(''/\\,{2,}/'','','',$icons);\n	$icons = preg_replace(''/\\,{1,}+$/'','''',$icons);\n\n	$names = implode('','', $names);\n	$names = preg_replace(''/\\,{2,}/'','','',$names);\n	$names = preg_replace(''/\\,{1,}+$/'','''',$names);\n\n	$query = array(\n		''UPDATE''	=> ''config'',\n		''SET''		=> ''conf_value=\\''''.$forum_db->escape($icons).''\\'''',\n		''WHERE''		=> ''conf_name = \\''attach_icon_extension\\''''\n	);\n	$result = $forum_db->query_build($query) or error (__FILE__, __LINE__);\n\n	$query = array(\n		''UPDATE''	=> ''config'',\n		''SET''		=> ''conf_value=\\''''.$forum_db->escape($names).''\\'''',\n		''WHERE''		=> ''conf_name=\\''attach_icon_name\\''''\n	);\n	$result = $forum_db->query_build($query) or error (__FILE__, __LINE__);\n	}\n\n	if ($section == ''list_attach'')\n	{\n	$query = array(\n		''SELECT''	=> ''COUNT(id) AS num_attach'',\n		''FROM''		=> ''attach_files''\n	);\n\n	$result = $forum_db->query_build($query) or error(__FILE__, __LINE__);\n	$num_attach = $forum_db->fetch_assoc($result);\n\n	if (!is_null($num_attach) && $num_attach !== false)\n	{\n		for ($i = 0; $i < $num_attach[''num_attach'']; $i++)\n		{\n			if (isset($_POST[''attach_''.$i]))\n			{\n				if (isset($_POST[''attach_to_post_''.$i]) && !empty($_POST[''attach_to_post_''.$i]))\n				{\n					$post_id = intval($_POST[''attach_to_post_''.$i]);\n					$attach_id = intval($_POST[''attachment_''.$i]);\n					$query = array(\n						''SELECT''	=> ''id, topic_id, poster_id'',\n						''FROM''		=> ''posts'',\n						''WHERE''		=> ''id=''.$post_id\n					);\n					$result = $forum_db->query_build($query) or error(__FILE__, __LINE__);\n\n					$info = $forum_db->fetch_assoc($result);\n					if (is_null($info) || $info === false)\n						message ($lang_attach[''Wrong post'']);\n\n					$query = array(\n						''UPDATE''	=> ''attach_files'',\n						''SET''		=> ''post_id=''.intval($info[''id'']).'', topic_id=''.intval($info[''topic_id'']).'', owner_id=''.intval($info[''poster_id'']),\n						''WHERE''		=> ''id=''.$attach_id\n					);\n					$result = $forum_db->query_build($query) or error(__FILE__, __LINE__);\n\n					redirect(forum_link($attach_url[''admin_attachment_manage'']), $lang_attach[''Attachment added'']);\n				}\n				else\n					message ($lang_attach[''Wrong post'']);\n			}\n		}\n	}\n}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('mi_new_action', 'pun_attachment', 'if ($action == ''pun_attachment'' && !$forum_config[''attach_disable_attach''] && isset($_GET[''item'']))\n			{\n				$attach_item = intval($_GET[''item'']);\n				if ($attach_item < 1)\n					message($lang_common[''Bad request'']);\n\n				if (isset($_GET[''secure_str'']))\n				{\n					preg_match(''~(\\d+)f(\\d+)~'', $_GET[''secure_str''], $match);\n					if (isset($match[0]))\n					{\n						$query = array(\n							''SELECT''	=>	''a.id, a.post_id, a.topic_id, a.owner_id, a.filename, a.file_ext, a.file_mime_type, a.size, a.file_path, a.secure_str'',\n							''FROM''		=>	''attach_files AS a'',\n							''JOINS''		=>	array(\n								array(\n									''INNER JOIN'' => ''forums AS f'',\n									''ON''		=> ''f.id = ''.$match[2]\n								),\n								array(\n									''LEFT JOIN''	=> ''forum_perms AS fp'',\n									''ON''		=> ''(fp.forum_id = f.id AND fp.group_id = ''.$forum_user[''g_id''].'')''\n								)\n							),\n							''WHERE''		=> ''a.id = ''.$attach_item.'' AND (fp.read_forum IS NULL OR fp.read_forum = 1) AND secure_str = \\''''.$match[0].''\\''''\n						);\n					}\n					else\n					{\n						preg_match(''~(\\d+)t(\\d+)~'', $_GET[''secure_str''], $match);\n						if (isset($match[0]))\n						{\n							$query = array(\n								''SELECT''	=>	''a.id, a.post_id, a.topic_id, a.owner_id, a.filename, a.file_ext, a.file_mime_type, a.size, a.file_path, a.secure_str'',\n								''FROM''		=>	''attach_files AS a'',\n								''JOINS''		=>	array(\n									array(\n										''INNER JOIN''	=> ''topics AS t'',\n										''ON''		=> ''t.id = ''.$match[2]\n									),\n									array(\n										''INNER JOIN''	=> ''forums AS f'',\n										''ON''		=> ''f.id = t.forum_id''\n									),\n									array(\n										''LEFT JOIN''		=> ''forum_perms AS fp'',\n										''ON''		=> ''(fp.forum_id = f.id AND fp.group_id = ''.$forum_user[''g_id''].'')''\n									)\n								),\n								''WHERE''		=> ''a.id = ''.$attach_item.'' AND (fp.read_forum IS NULL OR fp.read_forum = 1) AND secure_str = \\''''.$match[0].''\\''''\n							);\n						}\n						else\n							message($lang_common[''Bad request'']);\n					}\n					if ($forum_user[''id''] != $match[1])\n						message($lang_common[''Bad request'']);\n				} else {\n					$query = array(\n						''SELECT''	=> ''a.id, a.post_id, a.topic_id, a.owner_id, a.filename, a.file_ext, a.file_mime_type, a.size, a.file_path, a.secure_str'',\n						''FROM''		=> ''attach_files AS a'',\n						''JOINS''		=> array(\n							array(\n								''INNER JOIN''	=> ''topics AS t'',\n								''ON''			=> ''t.id = a.topic_id''\n							),\n							array(\n								''INNER JOIN''	=> ''forums AS f'',\n								''ON''			=> ''f.id = t.forum_id''\n							),\n							array(\n								''LEFT JOIN''		=> ''forum_perms AS fp'',\n								''ON''			=> ''(fp.forum_id = f.id AND fp.group_id = ''.$forum_user[''g_id''].'')''\n							)\n						),\n						''WHERE''		=> ''a.id = ''.$attach_item.'' AND (fp.read_forum IS NULL OR fp.read_forum = 1)''\n					);\n				}\n\n				$result = $forum_db->query_build($query) or error(__FILE__, __LINE__);\n				$attach_info = $forum_db->fetch_assoc($result);\n\n				if (!$attach_info)\n					message($lang_common[''Bad request'']);\n\n				$query = array(\n					''SELECT''	=> ''g_pun_attachment_allow_download'',\n					''FROM''		=> ''groups'',\n					''WHERE''		=> ''g_id = ''.$forum_user[''group_id'']\n				);\n				$result = $forum_db->query_build($query) or error(__FILE__, __LINE__);\n				$perms = $forum_db->fetch_assoc($result);\n\n				if (!$perms) {\n					message($lang_common[''No permission'']);\n				}\n\n				if ($forum_user[''g_id''] != FORUM_ADMIN && !$perms[''g_pun_attachment_allow_download'']) {\n					message($lang_common[''No permission'']);\n				}\n\n				if (isset($_GET[''preview'']) && in_array($attach_info[''file_ext''], array(''png'', ''jpg'', ''gif'', ''tiff'')))\n				{\n					if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n						require $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n					else\n						require $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';\n					require $ext_info[''path''].''/url.php'';\n\n					$forum_page = array();\n					$forum_page[''download_link''] = !empty($attach_info[''secure_str'']) ? forum_link($attach_url[''misc_download_secure''], array($attach_item, $attach_info[''secure_str''])) : forum_link($attach_url[''misc_download''], $attach_item);\n					$forum_page[''view_link''] = !empty($attach_info[''secure_str'']) ? forum_link($attach_url[''misc_view_secure''], array($attach_item, $attach_info[''secure_str''])) : forum_link($attach_url[''misc_view''], $attach_info[''id'']);\n\n					// Setup breadcrumbs\n					$forum_page[''crumbs''] = array(\n						array($forum_config[''o_board_title''], forum_link($forum_url[''index''])),\n						$lang_attach[''Image preview'']\n					);\n\n					define(''FORUM_PAGE'', ''attachment-preview'');\n					require FORUM_ROOT.''header.php'';\n\n					// START SUBST - <!-- forum_main -->\n					ob_start();\n\n					?>\n					<div class="main-head">\n						<h2 class="hn"><span><?php echo $lang_attach[''Image preview'']; ?></span></h2>\n					</div>\n\n					<div class="main-content main-frm">\n						<div class="content-head">\n							<h2 class="hn"><span><?php echo $attach_info[''filename'']; ?></span></h2>\n						</div>\n						<fieldset class="frm-group group1">\n							<span class="show-image"><img src="<?php echo $forum_page[''view_link'']; ?>" alt="<?php echo forum_htmlencode($attach_info[''filename'']); ?>" /></span>\n							<p><?php echo $lang_attach[''Download:'']; ?> <a href="<?php echo $forum_page[''download_link'']; ?>"><?php echo forum_htmlencode($attach_info[''filename'']); ?></a></p>\n						</fieldset>\n					</div>\n					<?php\n\n					$tpl_temp = trim(ob_get_contents());\n					$tpl_main = str_replace(''<!-- forum_main -->'', $tpl_temp, $tpl_main);\n					ob_end_clean();\n					// END SUBST - <!-- forum_main -->\n\n					require FORUM_ROOT.''footer.php'';\n				}\n				else\n				{\n					$fp = fopen($forum_config[''attach_basefolder''].$attach_info[''file_path''], ''rb'');\n\n					if (!$fp)\n						message($lang_common[''Bad request'']);\n					else\n					{\n						header(''Content-Disposition: attachment; filename="''.$attach_info[''filename''].''"'');\n						header(''Content-Type: ''.$attach_info[''file_mime_type'']);\n						header(''Pragma: no-cache'');\n						header(''Expires: 0'');\n						header(''Connection: close'');\n						header(''Content-Length: ''.$attach_info[''size'']);\n\n						fpassthru($fp);\n\n						if (isset($_GET[''download'']) && intval($_GET[''download'']) == 1) {\n							$query = array(\n								''UPDATE''	=> ''attach_files'',\n								''SET''		=> ''download_counter=download_counter+1'',\n								''WHERE''		=> ''id=''.$attach_item\n							);\n							$result = $forum_db->query_build($query) or error(__FILE__, __LINE__);\n						}\n\n\n						// End the transaction\n						$forum_db->end_transaction();\n\n						// Close the db connection (and free up any result data)\n						$forum_db->close();\n\n						exit();\n					}\n				}\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('dl_start', 'pun_attachment', 'require $ext_info[''path''].''/include/attach_func.php'';\n			if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n				require $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n			else\n				require $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('mr_start', 'pun_attachment', 'require $ext_info[''path''].''/include/attach_func.php'';\n			if (file_exists($ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php''))\n				require $ext_info[''path''].''/lang/''.$forum_user[''language''].''/''.$ext_info[''id''].''.php'';\n			else\n				require $ext_info[''path''].''/lang/English/''.$ext_info[''id''].''.php'';', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('dl_qr_get_post_info', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$query[''SELECT''] .= '', g_pun_attachment_allow_upload, g_pun_attachment_upload_max_size, g_pun_attachment_files_per_post, g_pun_attachment_disallowed_extensions, g_pun_attachment_allow_delete_own, g_pun_attachment_allow_delete'';\n				$query[''JOINS''][] = array(''LEFT JOIN'' => ''groups AS g'', ''ON'' => ''g.g_id = ''.$forum_user[''g_id'']);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('dl_form_submitted', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$attach_query = array(\n					''SELECT''	=>	''id, file_path, owner_id'',\n					''FROM''		=>	''attach_files''\n				);\n				$attach_query[''WHERE''] = $cur_post[''is_topic''] ? ''post_id != 0 AND topic_id = ''.$cur_post[''tid''] : ''post_id = ''.$id;\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('dl_topic_deleted_pre_redirect', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				remove_attachments($attach_query, $cur_post);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('dl_post_deleted_pre_redirect', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				remove_attachments($attach_query, $cur_post);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('mr_qr_get_forum_data', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$query[''SELECT''] .= '', g_pun_attachment_allow_upload, g_pun_attachment_upload_max_size, g_pun_attachment_files_per_post, g_pun_attachment_disallowed_extensions, g_pun_attachment_allow_delete_own, g_pun_attachment_allow_delete'';\n				$query[''JOINS''][] = array(''LEFT JOIN'' => ''groups AS g'', ''ON'' => ''g.g_id = ''.$forum_user[''g_id'']);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('mr_confirm_delete_posts_pre_redirect', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$attach_query = array(\n					''SELECT''	=>	''id, file_path, owner_id'',\n					''FROM''		=>	''attach_files'',\n					''WHERE''		=>	isset($posts) ? ''post_id IN(''.implode('','', $posts).'')'' : ''topic_id IN(''.implode('','', $topics).'')''\n				);\n				$forum_page[''is_admmod''] = true;\n				remove_attachments($attach_query, $cur_forum);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('mr_confirm_delete_topics_pre_redirect', 'pun_attachment', 'if (!$forum_config[''attach_disable_attach''])\n			{\n				$attach_query = array(\n					''SELECT''	=>	''id, file_path, owner_id'',\n					''FROM''		=>	''attach_files'',\n					''WHERE''		=>	isset($posts) ? ''post_id IN(''.implode('','', $posts).'')'' : ''topic_id IN(''.implode('','', $topics).'')''\n				);\n				$forum_page[''is_admmod''] = true;\n				remove_attachments($attach_query, $cur_forum);\n			}', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('mr_confirm_split_posts_pre_redirect', 'pun_attachment', '$attach_query = array(\n				''UPDATE''	=>	''attach_files'',\n				''SET''		=>	''topic_id=''.$new_tid,\n				''WHERE''		=>	''post_id IN (''.implode('','', $posts).'')''\n			);\n			$forum_db->query_build($attach_query) or error(__FILE__, __LINE__);', 1358395384, 5);
INSERT INTO `x_extension_hooks` VALUES('mr_confirm_merge_topics_pre_redirect', 'pun_attachment', '$attach_query = array(\n				''UPDATE''	=>	''attach_files'',\n				''SET''		=>	''topic_id=''.$merge_to_tid,\n				''WHERE''		=>	''topic_id IN(''.implode('','', $topics).'')''\n			);\n			$forum_db->query_build($attach_query) or error(__FILE__, __LINE__);', 1358395384, 5);

-- --------------------------------------------------------

--
-- Table structure for table `x_forums`
--

DROP TABLE IF EXISTS `x_forums`;
CREATE TABLE IF NOT EXISTS `x_forums` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `forum_name` varchar(80) NOT NULL default 'New forum',
  `forum_desc` text,
  `redirect_url` varchar(100) default NULL,
  `moderators` text,
  `num_topics` mediumint(8) unsigned NOT NULL default '0',
  `num_posts` mediumint(8) unsigned NOT NULL default '0',
  `last_post` int(10) unsigned default NULL,
  `last_post_id` int(10) unsigned default NULL,
  `last_poster` varchar(200) default NULL,
  `sort_by` tinyint(1) NOT NULL default '0',
  `disp_position` int(10) NOT NULL default '0',
  `cat_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `x_forums`
--

INSERT INTO `x_forums` VALUES(2, 'Bug Reports', NULL, NULL, NULL, 3, 8, 1358401230, 17, 'admin', 0, 1, 2);
INSERT INTO `x_forums` VALUES(3, 'Feature Suggestions', NULL, NULL, NULL, 1, 4, 1358401083, 16, 'Joe Smith', 0, 2, 2);
INSERT INTO `x_forums` VALUES(4, 'Installation Questions', NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, 0, 2, 5);
INSERT INTO `x_forums` VALUES(5, 'FAQ', NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, 0, 1, 5);
INSERT INTO `x_forums` VALUES(6, 'Announcements', NULL, NULL, NULL, 1, 2, 1358387941, 5, 'ikljo', 0, 1, 3);
INSERT INTO `x_forums` VALUES(7, 'Changelog', NULL, NULL, NULL, 1, 1, 1358402535, 18, 'gdm', 0, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `x_forum_perms`
--

DROP TABLE IF EXISTS `x_forum_perms`;
CREATE TABLE IF NOT EXISTS `x_forum_perms` (
  `group_id` int(10) NOT NULL default '0',
  `forum_id` int(10) NOT NULL default '0',
  `read_forum` tinyint(1) NOT NULL default '1',
  `post_replies` tinyint(1) NOT NULL default '1',
  `post_topics` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`group_id`,`forum_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_forum_perms`
--

INSERT INTO `x_forum_perms` VALUES(2, 1, 1, 1, 1);
INSERT INTO `x_forum_perms` VALUES(2, 6, 1, 1, 0);
INSERT INTO `x_forum_perms` VALUES(3, 6, 1, 1, 0);
INSERT INTO `x_forum_perms` VALUES(2, 5, 1, 1, 0);
INSERT INTO `x_forum_perms` VALUES(3, 5, 1, 1, 0);
INSERT INTO `x_forum_perms` VALUES(2, 7, 1, 1, 0);
INSERT INTO `x_forum_perms` VALUES(3, 7, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `x_forum_subscriptions`
--

DROP TABLE IF EXISTS `x_forum_subscriptions`;
CREATE TABLE IF NOT EXISTS `x_forum_subscriptions` (
  `user_id` int(10) unsigned NOT NULL default '0',
  `forum_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`user_id`,`forum_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_forum_subscriptions`
--


-- --------------------------------------------------------

--
-- Table structure for table `x_groups`
--

DROP TABLE IF EXISTS `x_groups`;
CREATE TABLE IF NOT EXISTS `x_groups` (
  `g_id` int(10) unsigned NOT NULL auto_increment,
  `g_title` varchar(50) NOT NULL default '',
  `g_user_title` varchar(50) default NULL,
  `g_moderator` tinyint(1) NOT NULL default '0',
  `g_mod_edit_users` tinyint(1) NOT NULL default '0',
  `g_mod_rename_users` tinyint(1) NOT NULL default '0',
  `g_mod_change_passwords` tinyint(1) NOT NULL default '0',
  `g_mod_ban_users` tinyint(1) NOT NULL default '0',
  `g_read_board` tinyint(1) NOT NULL default '1',
  `g_view_users` tinyint(1) NOT NULL default '1',
  `g_post_replies` tinyint(1) NOT NULL default '1',
  `g_post_topics` tinyint(1) NOT NULL default '1',
  `g_edit_posts` tinyint(1) NOT NULL default '1',
  `g_delete_posts` tinyint(1) NOT NULL default '1',
  `g_delete_topics` tinyint(1) NOT NULL default '1',
  `g_set_title` tinyint(1) NOT NULL default '1',
  `g_search` tinyint(1) NOT NULL default '1',
  `g_search_users` tinyint(1) NOT NULL default '1',
  `g_send_email` tinyint(1) NOT NULL default '1',
  `g_post_flood` smallint(6) NOT NULL default '30',
  `g_search_flood` smallint(6) NOT NULL default '30',
  `g_email_flood` smallint(6) NOT NULL default '60',
  `g_poll_add` tinyint(1) NOT NULL default '1',
  `g_pun_attachment_allow_download` tinyint(1) default '1',
  `g_pun_attachment_allow_upload` tinyint(1) default '1',
  `g_pun_attachment_allow_delete` tinyint(1) default '0',
  `g_pun_attachment_allow_delete_own` tinyint(1) default '1',
  `g_pun_attachment_upload_max_size` int(10) default '2000000',
  `g_pun_attachment_files_per_post` tinyint(3) default '1',
  `g_pun_attachment_disallowed_extensions` text,
  PRIMARY KEY  (`g_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `x_groups`
--

INSERT INTO `x_groups` VALUES(1, 'Administrators', 'Administrator', 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, -1, '');
INSERT INTO `x_groups` VALUES(2, 'Users', 'User', 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 10, 5, 0, 0, 1, 1, 0, 1, 500000, 1, 'txt');
INSERT INTO `x_groups` VALUES(3, 'Members', NULL, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 60, 30, 60, 1, 1, 1, 0, 1, 2000000, 1, NULL);
INSERT INTO `x_groups` VALUES(4, 'Moderators', 'Moderator', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 2000000, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `x_online`
--

DROP TABLE IF EXISTS `x_online`;
CREATE TABLE IF NOT EXISTS `x_online` (
  `user_id` int(10) unsigned NOT NULL default '1',
  `ident` varchar(200) NOT NULL default '',
  `logged` int(10) unsigned NOT NULL default '0',
  `idle` tinyint(1) NOT NULL default '0',
  `csrf_token` varchar(40) NOT NULL default '',
  `prev_url` varchar(255) default NULL,
  `last_post` int(10) unsigned default NULL,
  `last_search` int(10) unsigned default NULL,
  UNIQUE KEY `x_online_user_id_ident_idx` (`user_id`,`ident`(25)),
  KEY `x_online_ident_idx` (`ident`(25)),
  KEY `x_online_logged_idx` (`logged`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_online`
--

INSERT INTO `x_online` VALUES(2, 'gdm', 1358402564, 0, '291482e9eae36e1543401857c87698bd92e94e25', 'http://hype-clan.com/eyeofac/forum/admin/forums.php', NULL, NULL);
INSERT INTO `x_online` VALUES(1, '165.123.142.57', 1358402478, 0, '2c40ea48af86492fb8b897d2939d98cbecd3bd3d', 'http://hype-clan.com/eyeofac/forum/viewforum.php?id=7', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `x_posts`
--

DROP TABLE IF EXISTS `x_posts`;
CREATE TABLE IF NOT EXISTS `x_posts` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `poster` varchar(200) NOT NULL default '',
  `poster_id` int(10) unsigned NOT NULL default '1',
  `poster_ip` varchar(39) default NULL,
  `poster_email` varchar(80) default NULL,
  `message` text,
  `hide_smilies` tinyint(1) NOT NULL default '0',
  `posted` int(10) unsigned NOT NULL default '0',
  `edited` int(10) unsigned default NULL,
  `edited_by` varchar(200) default NULL,
  `topic_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `x_posts_topic_id_idx` (`topic_id`),
  KEY `x_posts_multi_idx` (`poster_id`,`topic_id`),
  KEY `x_posts_posted_idx` (`posted`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `x_posts`
--

INSERT INTO `x_posts` VALUES(4, 'gdm', 2, '165.123.142.57', NULL, 'Woooooo!', 0, 1358387417, NULL, NULL, 3);
INSERT INTO `x_posts` VALUES(5, 'ikljo', 1, '47.54.197.80', 'hype.ikljo@gmail.com', ':)', 0, 1358387941, NULL, NULL, 3);
INSERT INTO `x_posts` VALUES(6, 'ikljo', 1, '47.54.197.80', 'hype.ikljo@gmail.com', '[url]http://hype-clan.com/eyeofac/forum/profile.php?id=2[/url]\n\n"Posts and Topic" label appears to be falling off the page.', 0, 1358388273, NULL, NULL, 4);
INSERT INTO `x_posts` VALUES(3, 'JoeSmith', 1, '98.252.150.189', 'jtsjoe@gmail.com', 'Test CANDY!@!', 0, 1358384079, NULL, NULL, 2);
INSERT INTO `x_posts` VALUES(7, 'ikljo', 1, '47.54.197.80', 'hype.ikljo@gmail.com', '[url]http://hype-clan.com/eyeofac/index.php[/url]\n\nAppears as if you may not have finished this part or maybe it wasn''t suppose to be there, but it is just raw text and nonalignment happening there and doesn''t seem as though it was placed there on purpose.', 0, 1358388410, NULL, NULL, 5);
INSERT INTO `x_posts` VALUES(8, 'gdm', 2, '165.123.142.57', NULL, 'You''re right - I''m in the process of doing this right now.\n\nI don''t have a good way to test locally at the moment, since the forum database is on the hype server & it doesn''t allow remote access.', 0, 1358388652, NULL, NULL, 5);
INSERT INTO `x_posts` VALUES(9, 'ikljo', 1, '47.54.197.80', 'hype.ikljo@gmail.com', 'Email topic exactly as shown without quotes on email was: \n\n"<span class="application-name">Eye of AC</span> - activate your account"\n\nMessage:\n\n"Thanks for signing up for <span class="application-name">Eye of AC</span>''s beta!\n\nFollow the link below to activate your account and log in:\n\n[url=http://hype-clan.com/jerbo_a/activate.php?email=hype.ikljo................\\]http://hype-clan.com/jerbo_a/activate.php?email=hype.ikljo................\\"[/url]', 0, 1358388735, NULL, NULL, 6);
INSERT INTO `x_posts` VALUES(10, 'ikljo', 1, '47.54.197.80', 'hype.ikljo@gmail.com', 'When I clicked the link it brought me to the HyPE website home page.', 0, 1358388789, NULL, NULL, 6);
INSERT INTO `x_posts` VALUES(11, 'gdm', 2, '165.123.142.57', NULL, 'Thanks, I know why the first one happened & that''s a quick fix. I''ll look into the other.', 0, 1358389579, NULL, NULL, 6);
INSERT INTO `x_posts` VALUES(12, 'gdm', 2, '165.123.142.57', NULL, 'Fixed.', 0, 1358393097, NULL, NULL, 4);
INSERT INTO `x_posts` VALUES(14, 'ikljo', 1, '165.123.142.57', 'hype.gdm@gmail.com', 'test', 0, 1358398238, NULL, NULL, 2);
INSERT INTO `x_posts` VALUES(15, 'ikljo', 1, '165.123.142.57', 'hype.gdm@gmail.com', 'I am an imposter.', 0, 1358398703, NULL, NULL, 2);
INSERT INTO `x_posts` VALUES(16, 'Joe Smith', 1, '98.252.150.189', 'jtsjoe@gmail.com', '^^slut', 0, 1358401083, NULL, NULL, 2);
INSERT INTO `x_posts` VALUES(17, 'gdm', 2, '165.123.142.57', NULL, 'Fixed. I forgot to update file paths in the email when I moved jerboa to hype-clan.com/eyeofac\n\nPlease activate your account with the link you have, but with ''eyeofac'' swapped in for ''jerbo_a''\n\ne.g.\nhttp://hype-clan.com/eyeofac/activate.php?email=hype.ikljo...', 0, 1358401230, NULL, NULL, 6);
INSERT INTO `x_posts` VALUES(18, 'gdm', 2, '165.123.142.57', NULL, 'Still need to do some clean-up styling on the forum. Particularly the padding and spacing of various text elements.', 0, 1358402535, NULL, NULL, 7);

-- --------------------------------------------------------

--
-- Table structure for table `x_questions`
--

DROP TABLE IF EXISTS `x_questions`;
CREATE TABLE IF NOT EXISTS `x_questions` (
  `topic_id` int(10) NOT NULL,
  `question` varchar(200) NOT NULL,
  `read_unvote_users` tinyint(1) default NULL,
  `revote` tinyint(1) default NULL,
  `created` int(10) NOT NULL,
  `days_count` int(10) default NULL,
  `votes_count` int(10) default NULL,
  PRIMARY KEY  (`topic_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_questions`
--


-- --------------------------------------------------------

--
-- Table structure for table `x_ranks`
--

DROP TABLE IF EXISTS `x_ranks`;
CREATE TABLE IF NOT EXISTS `x_ranks` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `rank` varchar(50) NOT NULL default '',
  `min_posts` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `x_ranks`
--

INSERT INTO `x_ranks` VALUES(1, 'New member', 0);
INSERT INTO `x_ranks` VALUES(2, 'Member', 10);

-- --------------------------------------------------------

--
-- Table structure for table `x_reports`
--

DROP TABLE IF EXISTS `x_reports`;
CREATE TABLE IF NOT EXISTS `x_reports` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `post_id` int(10) unsigned NOT NULL default '0',
  `topic_id` int(10) unsigned NOT NULL default '0',
  `forum_id` int(10) unsigned NOT NULL default '0',
  `reported_by` int(10) unsigned NOT NULL default '0',
  `created` int(10) unsigned NOT NULL default '0',
  `message` text,
  `zapped` int(10) unsigned default NULL,
  `zapped_by` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  KEY `x_reports_zapped_idx` (`zapped`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `x_reports`
--


-- --------------------------------------------------------

--
-- Table structure for table `x_search_cache`
--

DROP TABLE IF EXISTS `x_search_cache`;
CREATE TABLE IF NOT EXISTS `x_search_cache` (
  `id` int(10) unsigned NOT NULL default '0',
  `ident` varchar(200) NOT NULL default '',
  `search_data` text,
  PRIMARY KEY  (`id`),
  KEY `x_search_cache_ident_idx` (`ident`(8))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_search_cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `x_search_matches`
--

DROP TABLE IF EXISTS `x_search_matches`;
CREATE TABLE IF NOT EXISTS `x_search_matches` (
  `post_id` int(10) unsigned NOT NULL default '0',
  `word_id` int(10) unsigned NOT NULL default '0',
  `subject_match` tinyint(1) NOT NULL default '0',
  KEY `x_search_matches_word_id_idx` (`word_id`),
  KEY `x_search_matches_post_id_idx` (`post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_search_matches`
--

INSERT INTO `x_search_matches` VALUES(7, 51, 0);
INSERT INTO `x_search_matches` VALUES(7, 52, 0);
INSERT INTO `x_search_matches` VALUES(7, 53, 0);
INSERT INTO `x_search_matches` VALUES(7, 54, 0);
INSERT INTO `x_search_matches` VALUES(7, 55, 0);
INSERT INTO `x_search_matches` VALUES(7, 56, 0);
INSERT INTO `x_search_matches` VALUES(7, 57, 0);
INSERT INTO `x_search_matches` VALUES(6, 48, 1);
INSERT INTO `x_search_matches` VALUES(6, 39, 1);
INSERT INTO `x_search_matches` VALUES(6, 49, 1);
INSERT INTO `x_search_matches` VALUES(6, 34, 0);
INSERT INTO `x_search_matches` VALUES(6, 35, 0);
INSERT INTO `x_search_matches` VALUES(6, 36, 0);
INSERT INTO `x_search_matches` VALUES(6, 37, 0);
INSERT INTO `x_search_matches` VALUES(6, 38, 0);
INSERT INTO `x_search_matches` VALUES(6, 39, 0);
INSERT INTO `x_search_matches` VALUES(6, 40, 0);
INSERT INTO `x_search_matches` VALUES(6, 41, 0);
INSERT INTO `x_search_matches` VALUES(6, 42, 0);
INSERT INTO `x_search_matches` VALUES(6, 43, 0);
INSERT INTO `x_search_matches` VALUES(6, 44, 0);
INSERT INTO `x_search_matches` VALUES(6, 45, 0);
INSERT INTO `x_search_matches` VALUES(6, 46, 0);
INSERT INTO `x_search_matches` VALUES(6, 47, 0);
INSERT INTO `x_search_matches` VALUES(4, 33, 1);
INSERT INTO `x_search_matches` VALUES(4, 32, 0);
INSERT INTO `x_search_matches` VALUES(3, 30, 1);
INSERT INTO `x_search_matches` VALUES(3, 30, 0);
INSERT INTO `x_search_matches` VALUES(3, 31, 0);
INSERT INTO `x_search_matches` VALUES(7, 50, 0);
INSERT INTO `x_search_matches` VALUES(7, 45, 0);
INSERT INTO `x_search_matches` VALUES(7, 42, 0);
INSERT INTO `x_search_matches` VALUES(7, 40, 0);
INSERT INTO `x_search_matches` VALUES(7, 37, 0);
INSERT INTO `x_search_matches` VALUES(7, 36, 0);
INSERT INTO `x_search_matches` VALUES(7, 35, 0);
INSERT INTO `x_search_matches` VALUES(7, 34, 0);
INSERT INTO `x_search_matches` VALUES(7, 58, 0);
INSERT INTO `x_search_matches` VALUES(7, 59, 0);
INSERT INTO `x_search_matches` VALUES(7, 60, 0);
INSERT INTO `x_search_matches` VALUES(7, 61, 0);
INSERT INTO `x_search_matches` VALUES(7, 62, 0);
INSERT INTO `x_search_matches` VALUES(7, 63, 0);
INSERT INTO `x_search_matches` VALUES(7, 64, 0);
INSERT INTO `x_search_matches` VALUES(7, 65, 1);
INSERT INTO `x_search_matches` VALUES(7, 66, 1);
INSERT INTO `x_search_matches` VALUES(7, 41, 1);
INSERT INTO `x_search_matches` VALUES(8, 38, 0);
INSERT INTO `x_search_matches` VALUES(8, 30, 0);
INSERT INTO `x_search_matches` VALUES(8, 61, 0);
INSERT INTO `x_search_matches` VALUES(8, 67, 0);
INSERT INTO `x_search_matches` VALUES(8, 68, 0);
INSERT INTO `x_search_matches` VALUES(8, 69, 0);
INSERT INTO `x_search_matches` VALUES(8, 70, 0);
INSERT INTO `x_search_matches` VALUES(8, 71, 0);
INSERT INTO `x_search_matches` VALUES(8, 72, 0);
INSERT INTO `x_search_matches` VALUES(8, 73, 0);
INSERT INTO `x_search_matches` VALUES(8, 74, 0);
INSERT INTO `x_search_matches` VALUES(8, 75, 0);
INSERT INTO `x_search_matches` VALUES(8, 76, 0);
INSERT INTO `x_search_matches` VALUES(8, 77, 0);
INSERT INTO `x_search_matches` VALUES(8, 78, 0);
INSERT INTO `x_search_matches` VALUES(8, 79, 0);
INSERT INTO `x_search_matches` VALUES(8, 80, 0);
INSERT INTO `x_search_matches` VALUES(8, 81, 0);
INSERT INTO `x_search_matches` VALUES(8, 82, 0);
INSERT INTO `x_search_matches` VALUES(9, 43, 0);
INSERT INTO `x_search_matches` VALUES(9, 42, 0);
INSERT INTO `x_search_matches` VALUES(9, 40, 0);
INSERT INTO `x_search_matches` VALUES(9, 36, 0);
INSERT INTO `x_search_matches` VALUES(9, 35, 0);
INSERT INTO `x_search_matches` VALUES(9, 34, 0);
INSERT INTO `x_search_matches` VALUES(9, 78, 0);
INSERT INTO `x_search_matches` VALUES(9, 83, 0);
INSERT INTO `x_search_matches` VALUES(9, 84, 0);
INSERT INTO `x_search_matches` VALUES(9, 85, 0);
INSERT INTO `x_search_matches` VALUES(9, 86, 0);
INSERT INTO `x_search_matches` VALUES(9, 87, 0);
INSERT INTO `x_search_matches` VALUES(9, 88, 0);
INSERT INTO `x_search_matches` VALUES(9, 89, 0);
INSERT INTO `x_search_matches` VALUES(9, 90, 0);
INSERT INTO `x_search_matches` VALUES(9, 91, 0);
INSERT INTO `x_search_matches` VALUES(9, 92, 0);
INSERT INTO `x_search_matches` VALUES(9, 93, 0);
INSERT INTO `x_search_matches` VALUES(9, 94, 0);
INSERT INTO `x_search_matches` VALUES(9, 95, 0);
INSERT INTO `x_search_matches` VALUES(9, 96, 0);
INSERT INTO `x_search_matches` VALUES(9, 97, 0);
INSERT INTO `x_search_matches` VALUES(9, 98, 0);
INSERT INTO `x_search_matches` VALUES(9, 99, 0);
INSERT INTO `x_search_matches` VALUES(9, 100, 0);
INSERT INTO `x_search_matches` VALUES(9, 101, 0);
INSERT INTO `x_search_matches` VALUES(9, 92, 1);
INSERT INTO `x_search_matches` VALUES(9, 49, 1);
INSERT INTO `x_search_matches` VALUES(9, 83, 1);
INSERT INTO `x_search_matches` VALUES(9, 102, 1);
INSERT INTO `x_search_matches` VALUES(10, 104, 0);
INSERT INTO `x_search_matches` VALUES(10, 103, 0);
INSERT INTO `x_search_matches` VALUES(10, 106, 0);
INSERT INTO `x_search_matches` VALUES(10, 78, 0);
INSERT INTO `x_search_matches` VALUES(10, 97, 0);
INSERT INTO `x_search_matches` VALUES(10, 47, 0);
INSERT INTO `x_search_matches` VALUES(10, 105, 0);
INSERT INTO `x_search_matches` VALUES(11, 107, 0);
INSERT INTO `x_search_matches` VALUES(11, 111, 0);
INSERT INTO `x_search_matches` VALUES(11, 108, 0);
INSERT INTO `x_search_matches` VALUES(11, 112, 0);
INSERT INTO `x_search_matches` VALUES(11, 113, 0);
INSERT INTO `x_search_matches` VALUES(11, 110, 0);
INSERT INTO `x_search_matches` VALUES(11, 109, 0);
INSERT INTO `x_search_matches` VALUES(17, 37, 0);
INSERT INTO `x_search_matches` VALUES(17, 36, 0);
INSERT INTO `x_search_matches` VALUES(17, 40, 0);
INSERT INTO `x_search_matches` VALUES(12, 117, 0);
INSERT INTO `x_search_matches` VALUES(15, 120, 0);
INSERT INTO `x_search_matches` VALUES(14, 30, 0);
INSERT INTO `x_search_matches` VALUES(16, 121, 0);
INSERT INTO `x_search_matches` VALUES(17, 35, 0);
INSERT INTO `x_search_matches` VALUES(17, 34, 0);
INSERT INTO `x_search_matches` VALUES(17, 78, 0);
INSERT INTO `x_search_matches` VALUES(17, 83, 0);
INSERT INTO `x_search_matches` VALUES(17, 91, 0);
INSERT INTO `x_search_matches` VALUES(17, 92, 0);
INSERT INTO `x_search_matches` VALUES(17, 97, 0);
INSERT INTO `x_search_matches` VALUES(17, 100, 0);
INSERT INTO `x_search_matches` VALUES(17, 101, 0);
INSERT INTO `x_search_matches` VALUES(17, 117, 0);
INSERT INTO `x_search_matches` VALUES(17, 122, 0);
INSERT INTO `x_search_matches` VALUES(17, 123, 0);
INSERT INTO `x_search_matches` VALUES(17, 124, 0);
INSERT INTO `x_search_matches` VALUES(17, 125, 0);
INSERT INTO `x_search_matches` VALUES(17, 126, 0);
INSERT INTO `x_search_matches` VALUES(17, 127, 0);
INSERT INTO `x_search_matches` VALUES(17, 128, 0);
INSERT INTO `x_search_matches` VALUES(18, 42, 0);
INSERT INTO `x_search_matches` VALUES(18, 131, 0);
INSERT INTO `x_search_matches` VALUES(18, 137, 0);
INSERT INTO `x_search_matches` VALUES(18, 38, 0);
INSERT INTO `x_search_matches` VALUES(18, 130, 0);
INSERT INTO `x_search_matches` VALUES(18, 134, 0);
INSERT INTO `x_search_matches` VALUES(18, 133, 0);
INSERT INTO `x_search_matches` VALUES(18, 135, 0);
INSERT INTO `x_search_matches` VALUES(18, 129, 0);
INSERT INTO `x_search_matches` VALUES(18, 132, 0);
INSERT INTO `x_search_matches` VALUES(18, 58, 0);
INSERT INTO `x_search_matches` VALUES(18, 136, 0);
INSERT INTO `x_search_matches` VALUES(18, 42, 1);
INSERT INTO `x_search_matches` VALUES(18, 38, 1);
INSERT INTO `x_search_matches` VALUES(18, 138, 1);
INSERT INTO `x_search_matches` VALUES(18, 139, 1);
INSERT INTO `x_search_matches` VALUES(18, 140, 1);

-- --------------------------------------------------------

--
-- Table structure for table `x_search_words`
--

DROP TABLE IF EXISTS `x_search_words`;
CREATE TABLE IF NOT EXISTS `x_search_words` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `word` varchar(20) character set utf8 collate utf8_bin NOT NULL default '',
  PRIMARY KEY  (`word`),
  KEY `x_search_words_id_idx` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=141 ;

--
-- Dumping data for table `x_search_words`
--

INSERT INTO `x_search_words` VALUES(57, 'raw');
INSERT INTO `x_search_words` VALUES(56, 'suppose');
INSERT INTO `x_search_words` VALUES(55, 'wasn''t');
INSERT INTO `x_search_words` VALUES(54, 'maybe');
INSERT INTO `x_search_words` VALUES(53, 'part');
INSERT INTO `x_search_words` VALUES(52, 'finished');
INSERT INTO `x_search_words` VALUES(51, 'not');
INSERT INTO `x_search_words` VALUES(50, 'index');
INSERT INTO `x_search_words` VALUES(49, 'bug');
INSERT INTO `x_search_words` VALUES(48, 'user');
INSERT INTO `x_search_words` VALUES(47, 'page');
INSERT INTO `x_search_words` VALUES(46, 'falling');
INSERT INTO `x_search_words` VALUES(45, 'appears');
INSERT INTO `x_search_words` VALUES(44, 'label');
INSERT INTO `x_search_words` VALUES(43, 'topic');
INSERT INTO `x_search_words` VALUES(42, 'and');
INSERT INTO `x_search_words` VALUES(41, 'posts');
INSERT INTO `x_search_words` VALUES(40, 'php');
INSERT INTO `x_search_words` VALUES(39, 'profile');
INSERT INTO `x_search_words` VALUES(38, 'forum');
INSERT INTO `x_search_words` VALUES(37, 'eyeofac');
INSERT INTO `x_search_words` VALUES(36, 'com');
INSERT INTO `x_search_words` VALUES(35, 'hype-clan');
INSERT INTO `x_search_words` VALUES(34, 'http');
INSERT INTO `x_search_words` VALUES(33, 'announcement');
INSERT INTO `x_search_words` VALUES(32, 'woooooo');
INSERT INTO `x_search_words` VALUES(31, 'candy');
INSERT INTO `x_search_words` VALUES(30, 'test');
INSERT INTO `x_search_words` VALUES(58, 'text');
INSERT INTO `x_search_words` VALUES(59, 'nonalignment');
INSERT INTO `x_search_words` VALUES(60, 'happening');
INSERT INTO `x_search_words` VALUES(61, 'doesn''t');
INSERT INTO `x_search_words` VALUES(62, 'seem');
INSERT INTO `x_search_words` VALUES(63, 'placed');
INSERT INTO `x_search_words` VALUES(64, 'purpose');
INSERT INTO `x_search_words` VALUES(65, 'homepage');
INSERT INTO `x_search_words` VALUES(66, 'latest');
INSERT INTO `x_search_words` VALUES(67, 'you''re');
INSERT INTO `x_search_words` VALUES(68, 'right');
INSERT INTO `x_search_words` VALUES(69, 'i''m');
INSERT INTO `x_search_words` VALUES(70, 'process');
INSERT INTO `x_search_words` VALUES(71, 'doing');
INSERT INTO `x_search_words` VALUES(72, 'don''t');
INSERT INTO `x_search_words` VALUES(73, 'good');
INSERT INTO `x_search_words` VALUES(74, 'locally');
INSERT INTO `x_search_words` VALUES(75, 'moment');
INSERT INTO `x_search_words` VALUES(76, 'since');
INSERT INTO `x_search_words` VALUES(77, 'database');
INSERT INTO `x_search_words` VALUES(78, 'hype');
INSERT INTO `x_search_words` VALUES(79, 'server');
INSERT INTO `x_search_words` VALUES(80, 'allow');
INSERT INTO `x_search_words` VALUES(81, 'remote');
INSERT INTO `x_search_words` VALUES(82, 'access');
INSERT INTO `x_search_words` VALUES(83, 'email');
INSERT INTO `x_search_words` VALUES(84, 'exactly');
INSERT INTO `x_search_words` VALUES(85, 'shown');
INSERT INTO `x_search_words` VALUES(86, 'quotes');
INSERT INTO `x_search_words` VALUES(87, 'span');
INSERT INTO `x_search_words` VALUES(88, 'class');
INSERT INTO `x_search_words` VALUES(89, 'application-name');
INSERT INTO `x_search_words` VALUES(90, 'eye');
INSERT INTO `x_search_words` VALUES(91, 'activate');
INSERT INTO `x_search_words` VALUES(92, 'account');
INSERT INTO `x_search_words` VALUES(93, 'message');
INSERT INTO `x_search_words` VALUES(94, 'signing');
INSERT INTO `x_search_words` VALUES(95, 'beta');
INSERT INTO `x_search_words` VALUES(96, 'follow');
INSERT INTO `x_search_words` VALUES(97, 'link');
INSERT INTO `x_search_words` VALUES(98, 'below');
INSERT INTO `x_search_words` VALUES(99, 'log');
INSERT INTO `x_search_words` VALUES(100, 'jerbo');
INSERT INTO `x_search_words` VALUES(101, 'ikljo');
INSERT INTO `x_search_words` VALUES(102, 'verification');
INSERT INTO `x_search_words` VALUES(103, 'clicked');
INSERT INTO `x_search_words` VALUES(104, 'brought');
INSERT INTO `x_search_words` VALUES(105, 'website');
INSERT INTO `x_search_words` VALUES(106, 'home');
INSERT INTO `x_search_words` VALUES(107, 'first');
INSERT INTO `x_search_words` VALUES(108, 'happened');
INSERT INTO `x_search_words` VALUES(109, 'that''s');
INSERT INTO `x_search_words` VALUES(110, 'quick');
INSERT INTO `x_search_words` VALUES(111, 'fix');
INSERT INTO `x_search_words` VALUES(112, 'i''ll');
INSERT INTO `x_search_words` VALUES(113, 'look');
INSERT INTO `x_search_words` VALUES(114, 'respond');
INSERT INTO `x_search_words` VALUES(115, 'full');
INSERT INTO `x_search_words` VALUES(116, 'url');
INSERT INTO `x_search_words` VALUES(117, 'fixed');
INSERT INTO `x_search_words` VALUES(121, 'slut');
INSERT INTO `x_search_words` VALUES(120, 'imposter');
INSERT INTO `x_search_words` VALUES(122, 'forgot');
INSERT INTO `x_search_words` VALUES(123, 'update');
INSERT INTO `x_search_words` VALUES(124, 'file');
INSERT INTO `x_search_words` VALUES(125, 'paths');
INSERT INTO `x_search_words` VALUES(126, 'moved');
INSERT INTO `x_search_words` VALUES(127, 'jerboa');
INSERT INTO `x_search_words` VALUES(128, 'swapped');
INSERT INTO `x_search_words` VALUES(129, 'still');
INSERT INTO `x_search_words` VALUES(130, 'need');
INSERT INTO `x_search_words` VALUES(131, 'clean-up');
INSERT INTO `x_search_words` VALUES(132, 'styling');
INSERT INTO `x_search_words` VALUES(133, 'particularly');
INSERT INTO `x_search_words` VALUES(134, 'padding');
INSERT INTO `x_search_words` VALUES(135, 'spacing');
INSERT INTO `x_search_words` VALUES(136, 'various');
INSERT INTO `x_search_words` VALUES(137, 'elements');
INSERT INTO `x_search_words` VALUES(138, 'installed');
INSERT INTO `x_search_words` VALUES(139, 'integrated');
INSERT INTO `x_search_words` VALUES(140, 'punbb');

-- --------------------------------------------------------

--
-- Table structure for table `x_subscriptions`
--

DROP TABLE IF EXISTS `x_subscriptions`;
CREATE TABLE IF NOT EXISTS `x_subscriptions` (
  `user_id` int(10) unsigned NOT NULL default '0',
  `topic_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`user_id`,`topic_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_subscriptions`
--


-- --------------------------------------------------------

--
-- Table structure for table `x_topics`
--

DROP TABLE IF EXISTS `x_topics`;
CREATE TABLE IF NOT EXISTS `x_topics` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `poster` varchar(200) NOT NULL default '',
  `subject` varchar(255) NOT NULL default '',
  `posted` int(10) unsigned NOT NULL default '0',
  `first_post_id` int(10) unsigned NOT NULL default '0',
  `last_post` int(10) unsigned NOT NULL default '0',
  `last_post_id` int(10) unsigned NOT NULL default '0',
  `last_poster` varchar(200) default NULL,
  `num_views` mediumint(8) unsigned NOT NULL default '0',
  `num_replies` mediumint(8) unsigned NOT NULL default '0',
  `closed` tinyint(1) NOT NULL default '0',
  `sticky` tinyint(1) NOT NULL default '0',
  `moved_to` int(10) unsigned default NULL,
  `forum_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `x_topics_forum_id_idx` (`forum_id`),
  KEY `x_topics_moved_to_idx` (`moved_to`),
  KEY `x_topics_last_post_idx` (`last_post`),
  KEY `x_topics_first_post_id_idx` (`first_post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `x_topics`
--

INSERT INTO `x_topics` VALUES(3, 'gdm', 'Announcement!', 1358387417, 4, 1358387941, 5, 'ikljo', 27, 1, 0, 0, NULL, 6);
INSERT INTO `x_topics` VALUES(2, 'JoeSmith', 'Test', 1358384079, 3, 1358401083, 16, 'Joe Smith', 69, 3, 0, 0, NULL, 3);
INSERT INTO `x_topics` VALUES(4, 'ikljo', 'User Profile Bug', 1358388273, 6, 1358393097, 12, 'gdm', 10, 1, 1, 0, NULL, 2);
INSERT INTO `x_topics` VALUES(5, 'ikljo', 'HomePage Latest Posts', 1358388410, 7, 1358388652, 8, 'gdm', 20, 1, 1, 0, NULL, 2);
INSERT INTO `x_topics` VALUES(6, 'ikljo', 'Account Verification Email Bug', 1358388735, 9, 1358401230, 17, 'admin', 29, 3, 1, 0, NULL, 2);
INSERT INTO `x_topics` VALUES(7, 'gdm', 'Installed and integrated PunBB forum.', 1358402535, 18, 1358402535, 18, 'gdm', 1, 0, 0, 0, NULL, 7);

-- --------------------------------------------------------

--
-- Table structure for table `x_users`
--

DROP TABLE IF EXISTS `x_users`;
CREATE TABLE IF NOT EXISTS `x_users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `group_id` int(10) unsigned NOT NULL default '3',
  `username` varchar(200) NOT NULL default '',
  `password` varchar(40) NOT NULL default '',
  `salt` varchar(12) default NULL,
  `email` varchar(80) NOT NULL default '',
  `title` varchar(50) default NULL,
  `realname` varchar(40) default NULL,
  `url` varchar(100) default NULL,
  `facebook` varchar(100) default NULL,
  `twitter` varchar(100) default NULL,
  `linkedin` varchar(100) default NULL,
  `skype` varchar(100) default NULL,
  `jabber` varchar(80) default NULL,
  `icq` varchar(12) default NULL,
  `msn` varchar(80) default NULL,
  `aim` varchar(30) default NULL,
  `yahoo` varchar(30) default NULL,
  `location` varchar(30) default NULL,
  `signature` text,
  `disp_topics` tinyint(3) unsigned default NULL,
  `disp_posts` tinyint(3) unsigned default NULL,
  `email_setting` tinyint(1) NOT NULL default '1',
  `notify_with_post` tinyint(1) NOT NULL default '0',
  `auto_notify` tinyint(1) NOT NULL default '0',
  `show_smilies` tinyint(1) NOT NULL default '1',
  `show_img` tinyint(1) NOT NULL default '1',
  `show_img_sig` tinyint(1) NOT NULL default '1',
  `show_avatars` tinyint(1) NOT NULL default '1',
  `show_sig` tinyint(1) NOT NULL default '1',
  `access_keys` tinyint(1) NOT NULL default '0',
  `timezone` float NOT NULL default '0',
  `dst` tinyint(1) NOT NULL default '0',
  `time_format` int(10) unsigned NOT NULL default '0',
  `date_format` int(10) unsigned NOT NULL default '0',
  `language` varchar(25) NOT NULL default 'English',
  `style` varchar(25) NOT NULL default 'Oxygen',
  `num_posts` int(10) unsigned NOT NULL default '0',
  `last_post` int(10) unsigned default NULL,
  `last_search` int(10) unsigned default NULL,
  `last_email_sent` int(10) unsigned default NULL,
  `registered` int(10) unsigned NOT NULL default '0',
  `registration_ip` varchar(39) NOT NULL default '0.0.0.0',
  `last_visit` int(10) unsigned NOT NULL default '0',
  `admin_note` varchar(30) default NULL,
  `activate_string` varchar(80) default NULL,
  `activate_key` varchar(8) default NULL,
  `avatar` tinyint(3) unsigned NOT NULL default '0',
  `avatar_width` tinyint(3) unsigned NOT NULL default '0',
  `avatar_height` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `x_users_registered_idx` (`registered`),
  KEY `x_users_username_idx` (`username`(8))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `x_users`
--

INSERT INTO `x_users` VALUES(1, 2, 'Guest', 'Guest', NULL, 'Guest', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 'English', 'Oxygen', 0, NULL, NULL, NULL, 0, '0.0.0.0', 0, NULL, NULL, NULL, 0, 0, 0);
INSERT INTO `x_users` VALUES(2, 1, 'gdm', '30662e43392e9fecdb348d56c516f50f71b609c8', 'O,Jy-W<D-G}0', 'eye.of.ac@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 'English', 'Oxygen', 8, 1358402535, NULL, NULL, 1358368312, '127.0.0.1', 1358381586, NULL, NULL, NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `x_voting`
--

DROP TABLE IF EXISTS `x_voting`;
CREATE TABLE IF NOT EXISTS `x_voting` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `topic_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `answer_id` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `x_voting`
--

